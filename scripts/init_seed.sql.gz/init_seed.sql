--
-- PostgreSQL database dump
--

-- Dumped from database version 16.2 (Debian 16.2-1.pgdg120+2)
-- Dumped by pg_dump version 16.2 (Debian 16.2-1.pgdg120+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pg_cron; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_cron WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION pg_cron; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_cron IS 'Job scheduler for PostgreSQL';


--
-- Name: topology; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA topology;


--
-- Name: SCHEMA topology; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA topology IS 'PostGIS Topology schema';


--
-- Name: hstore; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS hstore WITH SCHEMA public;


--
-- Name: EXTENSION hstore; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION hstore IS 'data type for storing sets of (key, value) pairs';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


--
-- Name: pgrouting; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgrouting WITH SCHEMA public;


--
-- Name: EXTENSION pgrouting; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgrouting IS 'pgRouting Extension';


--
-- Name: postgis_raster; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis_raster WITH SCHEMA public;


--
-- Name: EXTENSION postgis_raster; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION postgis_raster IS 'PostGIS raster types and functions';


--
-- Name: postgis_topology; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis_topology WITH SCHEMA topology;


--
-- Name: EXTENSION postgis_topology; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION postgis_topology IS 'PostGIS topology spatial types and functions';


--
-- Name: asbinary(public.geometry); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.asbinary(public.geometry) RETURNS bytea
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/postgis-3', 'LWGEOM_asBinary';


--
-- Name: asbinary(public.geometry, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.asbinary(public.geometry, text) RETURNS bytea
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/postgis-3', 'LWGEOM_asBinary';


--
-- Name: astext(public.geometry); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.astext(public.geometry) RETURNS text
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/postgis-3', 'LWGEOM_asText';


--
-- Name: estimated_extent(text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.estimated_extent(text, text) RETURNS public.box2d
    LANGUAGE c IMMUTABLE STRICT SECURITY DEFINER
    AS '$libdir/postgis-3', 'geometry_estimated_extent';


--
-- Name: estimated_extent(text, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.estimated_extent(text, text, text) RETURNS public.box2d
    LANGUAGE c IMMUTABLE STRICT SECURITY DEFINER
    AS '$libdir/postgis-3', 'geometry_estimated_extent';


--
-- Name: geomfromtext(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.geomfromtext(text) RETURNS public.geometry
    LANGUAGE sql IMMUTABLE STRICT
    AS $_$SELECT ST_GeomFromText($1)$_$;


--
-- Name: geomfromtext(text, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.geomfromtext(text, integer) RETURNS public.geometry
    LANGUAGE sql IMMUTABLE STRICT
    AS $_$SELECT ST_GeomFromText($1, $2)$_$;


--
-- Name: ndims(public.geometry); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.ndims(public.geometry) RETURNS smallint
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/postgis-3', 'LWGEOM_ndims';


--
-- Name: setsrid(public.geometry, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.setsrid(public.geometry, integer) RETURNS public.geometry
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/postgis-3', 'LWGEOM_set_srid';


--
-- Name: srid(public.geometry); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.srid(public.geometry) RETURNS integer
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/postgis-3', 'LWGEOM_get_srid';


--
-- Name: st_asbinary(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.st_asbinary(text) RETURNS bytea
    LANGUAGE sql IMMUTABLE STRICT
    AS $_$ SELECT ST_AsBinary($1::geometry);$_$;


--
-- Name: st_astext(bytea); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.st_astext(bytea) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $_$ SELECT ST_AsText($1::geometry);$_$;


--
-- Name: gist_geometry_ops; Type: OPERATOR FAMILY; Schema: public; Owner: -
--

CREATE OPERATOR FAMILY public.gist_geometry_ops USING gist;
ALTER OPERATOR FAMILY public.gist_geometry_ops USING gist ADD
    OPERATOR 1 public.<<(public.geometry,public.geometry) ,
    OPERATOR 2 public.&<(public.geometry,public.geometry) ,
    OPERATOR 3 public.&&(public.geometry,public.geometry) ,
    OPERATOR 4 public.&>(public.geometry,public.geometry) ,
    OPERATOR 5 public.>>(public.geometry,public.geometry) ,
    OPERATOR 6 public.~=(public.geometry,public.geometry) ,
    OPERATOR 7 public.~(public.geometry,public.geometry) ,
    OPERATOR 8 public.@(public.geometry,public.geometry) ,
    OPERATOR 9 public.&<|(public.geometry,public.geometry) ,
    OPERATOR 10 public.<<|(public.geometry,public.geometry) ,
    OPERATOR 11 public.|>>(public.geometry,public.geometry) ,
    OPERATOR 12 public.|&>(public.geometry,public.geometry) ,
    OPERATOR 13 public.<->(public.geometry,public.geometry) FOR ORDER BY pg_catalog.float_ops ,
    OPERATOR 14 public.<#>(public.geometry,public.geometry) FOR ORDER BY pg_catalog.float_ops ,
    FUNCTION 3 (public.geometry, public.geometry) public.geometry_gist_compress_2d(internal) ,
    FUNCTION 4 (public.geometry, public.geometry) public.geometry_gist_decompress_2d(internal) ,
    FUNCTION 8 (public.geometry, public.geometry) public.geometry_gist_distance_2d(internal,public.geometry,integer);


--
-- Name: gist_geometry_ops; Type: OPERATOR CLASS; Schema: public; Owner: -
--

CREATE OPERATOR CLASS public.gist_geometry_ops
    FOR TYPE public.geometry USING gist FAMILY public.gist_geometry_ops AS
    STORAGE public.box2df ,
    FUNCTION 1 (public.geometry, public.geometry) public.geometry_gist_consistent_2d(internal,public.geometry,integer) ,
    FUNCTION 2 (public.geometry, public.geometry) public.geometry_gist_union_2d(bytea,internal) ,
    FUNCTION 5 (public.geometry, public.geometry) public.geometry_gist_penalty_2d(internal,internal,internal) ,
    FUNCTION 6 (public.geometry, public.geometry) public.geometry_gist_picksplit_2d(internal,internal) ,
    FUNCTION 7 (public.geometry, public.geometry) public.geometry_gist_same_2d(public.geometry,public.geometry,internal);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: aod_aerosolopticaldepth; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.aod_aerosolopticaldepth (
    id integer NOT NULL,
    satellite_id integer,
    data json NOT NULL,
    date date NOT NULL
);


--
-- Name: aod_aerosolopticaldepth_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.aod_aerosolopticaldepth_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: aod_aerosolopticaldepth_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.aod_aerosolopticaldepth_id_seq OWNED BY public.aod_aerosolopticaldepth.id;


--
-- Name: aod_pm25estimate; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.aod_pm25estimate (
    id integer NOT NULL,
    aod_id integer NOT NULL,
    valuepm25 json NOT NULL,
    date date NOT NULL
);


--
-- Name: aod_pm25estimate_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.aod_pm25estimate_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: aod_pm25estimate_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.aod_pm25estimate_id_seq OWNED BY public.aod_pm25estimate.id;


--
-- Name: aod_pm25polygon; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.aod_pm25polygon (
    id integer NOT NULL,
    pm25_id integer NOT NULL,
    geom public.geometry(Polygon,4326) NOT NULL,
    pm25_value double precision NOT NULL,
    date date NOT NULL
);


--
-- Name: aod_pm25polygon_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.aod_pm25polygon_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: aod_pm25polygon_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.aod_pm25polygon_id_seq OWNED BY public.aod_pm25polygon.id;


--
-- Name: aod_polygon; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.aod_polygon (
    id integer NOT NULL,
    aod_id integer NOT NULL,
    geom public.geometry(Polygon,4326) NOT NULL,
    aod_value double precision NOT NULL,
    date date NOT NULL
);


--
-- Name: aod_polygon_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.aod_polygon_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: aod_polygon_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.aod_polygon_id_seq OWNED BY public.aod_polygon.id;


--
-- Name: aod_satellite; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.aod_satellite (
    id integer NOT NULL,
    satellite_name character varying(255) NOT NULL
);


--
-- Name: aod_satellite_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.aod_satellite_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: aod_satellite_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.aod_satellite_id_seq OWNED BY public.aod_satellite.id;


--
-- Name: weather_data; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.weather_data (
    id integer NOT NULL,
    station_id integer NOT NULL,
    date date NOT NULL,
    temperature double precision,
    temp_max double precision,
    temp_min double precision,
    feels_like double precision,
    feels_like_max double precision,
    feels_like_min double precision,
    dew_point double precision,
    humidity double precision,
    wind_speed double precision,
    wind_gust double precision,
    wind_dir double precision,
    precipitation double precision,
    precip_cover double precision,
    barometric_pressure double precision,
    sea_level_pressure double precision,
    cloud_cover double precision,
    visibility double precision,
    uv_index double precision,
    solar_radiation double precision,
    solar_energy double precision
);


--
-- Name: weather_data_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.weather_data_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: weather_data_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.weather_data_id_seq OWNED BY public.weather_data.id;


--
-- Name: weather_pm25actual; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.weather_pm25actual (
    id integer NOT NULL,
    station_id integer NOT NULL,
    date date,
    pm25_value double precision
);


--
-- Name: weather_pm25actual_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.weather_pm25actual_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: weather_pm25actual_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.weather_pm25actual_id_seq OWNED BY public.weather_pm25actual.id;


--
-- Name: weather_pm25prediction; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.weather_pm25prediction (
    id integer NOT NULL,
    station_id integer NOT NULL,
    date date NOT NULL,
    pm25_value double precision
);


--
-- Name: weather_pm25prediction_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.weather_pm25prediction_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: weather_pm25prediction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.weather_pm25prediction_id_seq OWNED BY public.weather_pm25prediction.id;


--
-- Name: weather_station; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.weather_station (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    location public.geometry(Point,4326) NOT NULL
);


--
-- Name: weather_station_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.weather_station_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: weather_station_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.weather_station_id_seq OWNED BY public.weather_station.id;


--
-- Name: aod_aerosolopticaldepth id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aod_aerosolopticaldepth ALTER COLUMN id SET DEFAULT nextval('public.aod_aerosolopticaldepth_id_seq'::regclass);


--
-- Name: aod_pm25estimate id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aod_pm25estimate ALTER COLUMN id SET DEFAULT nextval('public.aod_pm25estimate_id_seq'::regclass);


--
-- Name: aod_pm25polygon id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aod_pm25polygon ALTER COLUMN id SET DEFAULT nextval('public.aod_pm25polygon_id_seq'::regclass);


--
-- Name: aod_polygon id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aod_polygon ALTER COLUMN id SET DEFAULT nextval('public.aod_polygon_id_seq'::regclass);


--
-- Name: aod_satellite id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aod_satellite ALTER COLUMN id SET DEFAULT nextval('public.aod_satellite_id_seq'::regclass);


--
-- Name: weather_data id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.weather_data ALTER COLUMN id SET DEFAULT nextval('public.weather_data_id_seq'::regclass);


--
-- Name: weather_pm25actual id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.weather_pm25actual ALTER COLUMN id SET DEFAULT nextval('public.weather_pm25actual_id_seq'::regclass);


--
-- Name: weather_pm25prediction id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.weather_pm25prediction ALTER COLUMN id SET DEFAULT nextval('public.weather_pm25prediction_id_seq'::regclass);


--
-- Name: weather_station id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.weather_station ALTER COLUMN id SET DEFAULT nextval('public.weather_station_id_seq'::regclass);


--
-- Data for Name: job; Type: TABLE DATA; Schema: cron; Owner: -
--

COPY cron.job (jobid, schedule, command, nodename, nodeport, database, username, active, jobname) FROM stdin;
\.


--
-- Data for Name: job_run_details; Type: TABLE DATA; Schema: cron; Owner: -
--

COPY cron.job_run_details (jobid, runid, job_pid, database, username, command, status, return_message, start_time, end_time) FROM stdin;
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alembic_version (version_num) FROM stdin;
0001
\.


--
-- Data for Name: aod_aerosolopticaldepth; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.aod_aerosolopticaldepth (id, satellite_id, data, date) FROM stdin;
89	1	[{"latitude": -6.099998474121094, "longitude": 106.69999694824219, "aod_values": 0.9493999481201172}, {"latitude": -6.099998474121094, "longitude": 106.75, "aod_values": 0.7405999898910522}, {"latitude": -6.099998474121094, "longitude": 106.80000305175781, "aod_values": 0.6782000064849854}, {"latitude": -6.099998474121094, "longitude": 106.8499984741211, "aod_values": 0.5803999900817871}, {"latitude": -6.099998474121094, "longitude": 106.9000015258789, "aod_values": 0.8143999576568604}, {"latitude": -6.099998474121094, "longitude": 106.94999694824219, "aod_values": 0.8145999908447266}, {"latitude": -6.150001525878906, "longitude": 106.69999694824219, "aod_values": 0.8381999731063843}, {"latitude": -6.150001525878906, "longitude": 106.75, "aod_values": 0.9893999695777893}, {"latitude": -6.150001525878906, "longitude": 106.80000305175781, "aod_values": 0.962399959564209}, {"latitude": -6.150001525878906, "longitude": 106.8499984741211, "aod_values": 0.8319999575614929}, {"latitude": -6.150001525878906, "longitude": 106.9000015258789, "aod_values": 0.9495999813079834}, {"latitude": -6.150001525878906, "longitude": 106.94999694824219, "aod_values": 0.9175999760627747}, {"latitude": -6.200004577636719, "longitude": 106.69999694824219, "aod_values": 0.652999997138977}, {"latitude": -6.200004577636719, "longitude": 106.75, "aod_values": 0.6615999937057495}, {"latitude": -6.200004577636719, "longitude": 106.80000305175781, "aod_values": 0.6168000102043152}, {"latitude": -6.200004577636719, "longitude": 106.8499984741211, "aod_values": 0.5547999739646912}, {"latitude": -6.200004577636719, "longitude": 106.9000015258789, "aod_values": 0.6237999796867371}, {"latitude": -6.200004577636719, "longitude": 106.94999694824219, "aod_values": 0.8939999938011169}, {"latitude": -6.25, "longitude": 106.69999694824219, "aod_values": 0.6965999603271484}, {"latitude": -6.25, "longitude": 106.75, "aod_values": 0.6283999681472778}, {"latitude": -6.25, "longitude": 106.80000305175781, "aod_values": 0.6326000094413757}, {"latitude": -6.25, "longitude": 106.8499984741211, "aod_values": 0.4983999729156494}, {"latitude": -6.25, "longitude": 106.9000015258789, "aod_values": 0.6693999767303467}, {"latitude": -6.25, "longitude": 106.94999694824219, "aod_values": 0.9705999493598938}, {"latitude": -6.3000030517578125, "longitude": 106.69999694824219, "aod_values": 0.962399959564209}, {"latitude": -6.3000030517578125, "longitude": 106.75, "aod_values": 0.8965999484062195}, {"latitude": -6.3000030517578125, "longitude": 106.80000305175781, "aod_values": 0.788599967956543}, {"latitude": -6.3000030517578125, "longitude": 106.8499984741211, "aod_values": 0.5848000049591064}, {"latitude": -6.3000030517578125, "longitude": 106.9000015258789, "aod_values": 0.41839998960494995}, {"latitude": -6.3000030517578125, "longitude": 106.94999694824219, "aod_values": 0.736799955368042}, {"latitude": -6.349998474121094, "longitude": 106.69999694824219, "aod_values": 0.9275999665260315}, {"latitude": -6.349998474121094, "longitude": 106.75, "aod_values": 0.9629999995231628}, {"latitude": -6.349998474121094, "longitude": 106.80000305175781, "aod_values": 0.9101999998092651}, {"latitude": -6.349998474121094, "longitude": 106.8499984741211, "aod_values": 0.587399959564209}, {"latitude": -6.349998474121094, "longitude": 106.9000015258789, "aod_values": 0.6308000087738037}, {"latitude": -6.349998474121094, "longitude": 106.94999694824219, "aod_values": 0.7637999653816223}]	2026-06-09
59	1	[{"latitude": -6.1946, "longitude": 106.8235, "aod_values": 0.5222}, {"latitude": -6.3569, "longitude": 106.8036, "aod_values": 0.01}, {"latitude": -6.2155, "longitude": 106.803, "aod_values": 0.5222}, {"latitude": -6.2073, "longitude": 106.7531, "aod_values": 0.5822}, {"latitude": -6.1535, "longitude": 106.9108, "aod_values": 0.63199997}, {"latitude": -6.2888, "longitude": 106.9091, "aod_values": 0.01}, {"latitude": -6.1811, "longitude": 106.8279, "aod_values": 0.01}, {"latitude": -6.2366, "longitude": 106.7931, "aod_values": 0.55619997}]	2026-05-11
60	1	[{"latitude": -6.1946, "longitude": 106.8235, "aod_values": 0.01}, {"latitude": -6.3569, "longitude": 106.8036, "aod_values": 0.01}, {"latitude": -6.2155, "longitude": 106.803, "aod_values": 0.01}, {"latitude": -6.2073, "longitude": 106.7531, "aod_values": 0.01}, {"latitude": -6.1535, "longitude": 106.9108, "aod_values": 0.01}, {"latitude": -6.2888, "longitude": 106.9091, "aod_values": 0.01}, {"latitude": -6.1811, "longitude": 106.8279, "aod_values": 0.01}, {"latitude": -6.2366, "longitude": 106.7931, "aod_values": 0.01}]	2026-05-12
61	1	[{"latitude": -6.1946, "longitude": 106.8235, "aod_values": 0.01}, {"latitude": -6.3569, "longitude": 106.8036, "aod_values": 0.01}, {"latitude": -6.2155, "longitude": 106.803, "aod_values": 0.01}, {"latitude": -6.2073, "longitude": 106.7531, "aod_values": 0.01}, {"latitude": -6.1535, "longitude": 106.9108, "aod_values": 0.01}, {"latitude": -6.2888, "longitude": 106.9091, "aod_values": 0.01}, {"latitude": -6.1811, "longitude": 106.8279, "aod_values": 0.01}, {"latitude": -6.2366, "longitude": 106.7931, "aod_values": 0.01}]	2026-05-13
62	1	[{"latitude": -6.1946, "longitude": 106.8235, "aod_values": 0.9982}, {"latitude": -6.3569, "longitude": 106.8036, "aod_values": 0.01}, {"latitude": -6.2155, "longitude": 106.803, "aod_values": 0.9982}, {"latitude": -6.2073, "longitude": 106.7531, "aod_values": 0.01}, {"latitude": -6.1535, "longitude": 106.9108, "aod_values": 0.8454}, {"latitude": -6.2888, "longitude": 106.9091, "aod_values": 0.01}, {"latitude": -6.1811, "longitude": 106.8279, "aod_values": 0.01}, {"latitude": -6.2366, "longitude": 106.7931, "aod_values": 0.01}]	2026-05-14
63	1	[{"latitude": -6.1946, "longitude": 106.8235, "aod_values": 0.01}, {"latitude": -6.3569, "longitude": 106.8036, "aod_values": 0.01}, {"latitude": -6.2155, "longitude": 106.803, "aod_values": 0.01}, {"latitude": -6.2073, "longitude": 106.7531, "aod_values": 0.01}, {"latitude": -6.1535, "longitude": 106.9108, "aod_values": 0.01}, {"latitude": -6.2888, "longitude": 106.9091, "aod_values": 0.01}, {"latitude": -6.1811, "longitude": 106.8279, "aod_values": 0.01}, {"latitude": -6.2366, "longitude": 106.7931, "aod_values": 0.01}]	2026-05-15
64	1	[{"latitude": -6.1946, "longitude": 106.8235, "aod_values": 0.01}, {"latitude": -6.3569, "longitude": 106.8036, "aod_values": 0.01}, {"latitude": -6.2155, "longitude": 106.803, "aod_values": 0.01}, {"latitude": -6.2073, "longitude": 106.7531, "aod_values": 0.01}, {"latitude": -6.1535, "longitude": 106.9108, "aod_values": 0.01}, {"latitude": -6.2888, "longitude": 106.9091, "aod_values": 0.01}, {"latitude": -6.1811, "longitude": 106.8279, "aod_values": 0.01}, {"latitude": -6.2366, "longitude": 106.7931, "aod_values": 0.01}]	2026-05-16
65	1	[{"latitude": -6.1946, "longitude": 106.8235, "aod_values": 0.61579996}, {"latitude": -6.3569, "longitude": 106.8036, "aod_values": 0.01}, {"latitude": -6.2155, "longitude": 106.803, "aod_values": 0.61579996}, {"latitude": -6.2073, "longitude": 106.7531, "aod_values": 0.01}, {"latitude": -6.1535, "longitude": 106.9108, "aod_values": 0.5024}, {"latitude": -6.2888, "longitude": 106.9091, "aod_values": 0.01}, {"latitude": -6.1811, "longitude": 106.8279, "aod_values": 0.01}, {"latitude": -6.2366, "longitude": 106.7931, "aod_values": 0.6146}]	2026-05-17
66	1	[{"latitude": -6.1946, "longitude": 106.8235, "aod_values": 0.01}, {"latitude": -6.3569, "longitude": 106.8036, "aod_values": 0.01}, {"latitude": -6.2155, "longitude": 106.803, "aod_values": 0.01}, {"latitude": -6.2073, "longitude": 106.7531, "aod_values": 0.01}, {"latitude": -6.1535, "longitude": 106.9108, "aod_values": 0.01}, {"latitude": -6.2888, "longitude": 106.9091, "aod_values": 0.01}, {"latitude": -6.1811, "longitude": 106.8279, "aod_values": 0.01}, {"latitude": -6.2366, "longitude": 106.7931, "aod_values": 0.01}]	2026-05-18
67	1	[{"latitude": -6.1946, "longitude": 106.8235, "aod_values": 0.01}, {"latitude": -6.3569, "longitude": 106.8036, "aod_values": 0.01}, {"latitude": -6.2155, "longitude": 106.803, "aod_values": 0.01}, {"latitude": -6.2073, "longitude": 106.7531, "aod_values": 0.01}, {"latitude": -6.1535, "longitude": 106.9108, "aod_values": 0.01}, {"latitude": -6.2888, "longitude": 106.9091, "aod_values": 0.01}, {"latitude": -6.1811, "longitude": 106.8279, "aod_values": 0.8386}, {"latitude": -6.2366, "longitude": 106.7931, "aod_values": 0.01}]	2026-05-19
68	1	[{"latitude": -6.1946, "longitude": 106.8235, "aod_values": 0.01}, {"latitude": -6.3569, "longitude": 106.8036, "aod_values": 0.1638}, {"latitude": -6.2155, "longitude": 106.803, "aod_values": 0.01}, {"latitude": -6.2073, "longitude": 106.7531, "aod_values": 0.01}, {"latitude": -6.1535, "longitude": 106.9108, "aod_values": 0.01}, {"latitude": -6.2888, "longitude": 106.9091, "aod_values": 0.01}, {"latitude": -6.1811, "longitude": 106.8279, "aod_values": 0.487}, {"latitude": -6.2366, "longitude": 106.7931, "aod_values": 0.3696}]	2026-05-20
69	1	[{"latitude": -6.1946, "longitude": 106.8235, "aod_values": 0.01}, {"latitude": -6.3569, "longitude": 106.8036, "aod_values": 0.0486}, {"latitude": -6.2155, "longitude": 106.803, "aod_values": 0.01}, {"latitude": -6.2073, "longitude": 106.7531, "aod_values": 0.01}, {"latitude": -6.1535, "longitude": 106.9108, "aod_values": 0.3216}, {"latitude": -6.2888, "longitude": 106.9091, "aod_values": 1.0912}, {"latitude": -6.1811, "longitude": 106.8279, "aod_values": 0.6408}, {"latitude": -6.2366, "longitude": 106.7931, "aod_values": 0.871}]	2026-05-21
70	1	[{"latitude": -6.1946, "longitude": 106.8235, "aod_values": 0.1628}, {"latitude": -6.3569, "longitude": 106.8036, "aod_values": 0.0484}, {"latitude": -6.2155, "longitude": 106.803, "aod_values": 0.1628}, {"latitude": -6.2073, "longitude": 106.7531, "aod_values": 0.2232}, {"latitude": -6.1535, "longitude": 106.9108, "aod_values": 0.113}, {"latitude": -6.2888, "longitude": 106.9091, "aod_values": 0.121199995}, {"latitude": -6.1811, "longitude": 106.8279, "aod_values": 0.1024}, {"latitude": -6.2366, "longitude": 106.7931, "aod_values": 0.0828}]	2026-05-22
71	1	[{"latitude": -6.1946, "longitude": 106.8235, "aod_values": 0.01}, {"latitude": -6.3569, "longitude": 106.8036, "aod_values": 0.01}, {"latitude": -6.2155, "longitude": 106.803, "aod_values": 0.01}, {"latitude": -6.2073, "longitude": 106.7531, "aod_values": 0.01}, {"latitude": -6.1535, "longitude": 106.9108, "aod_values": 0.01}, {"latitude": -6.2888, "longitude": 106.9091, "aod_values": 0.01}, {"latitude": -6.1811, "longitude": 106.8279, "aod_values": 0.01}, {"latitude": -6.2366, "longitude": 106.7931, "aod_values": 0.01}]	2026-05-23
72	1	[{"latitude": -6.1946, "longitude": 106.8235, "aod_values": 0.01}, {"latitude": -6.3569, "longitude": 106.8036, "aod_values": 1.3856}, {"latitude": -6.2155, "longitude": 106.803, "aod_values": 0.01}, {"latitude": -6.2073, "longitude": 106.7531, "aod_values": 0.01}, {"latitude": -6.1535, "longitude": 106.9108, "aod_values": 0.01}, {"latitude": -6.2888, "longitude": 106.9091, "aod_values": 0.01}, {"latitude": -6.1811, "longitude": 106.8279, "aod_values": 0.01}, {"latitude": -6.2366, "longitude": 106.7931, "aod_values": 0.01}]	2026-05-24
73	1	[{"latitude": -6.1946, "longitude": 106.8235, "aod_values": 0.01}, {"latitude": -6.3569, "longitude": 106.8036, "aod_values": 0.01}, {"latitude": -6.2155, "longitude": 106.803, "aod_values": 0.01}, {"latitude": -6.2073, "longitude": 106.7531, "aod_values": 0.01}, {"latitude": -6.1535, "longitude": 106.9108, "aod_values": 0.01}, {"latitude": -6.2888, "longitude": 106.9091, "aod_values": 0.01}, {"latitude": -6.1811, "longitude": 106.8279, "aod_values": 0.01}, {"latitude": -6.2366, "longitude": 106.7931, "aod_values": 0.01}]	2026-05-25
74	1	[{"latitude": -6.1946, "longitude": 106.8235, "aod_values": 0.01}, {"latitude": -6.3569, "longitude": 106.8036, "aod_values": 0.01}, {"latitude": -6.2155, "longitude": 106.803, "aod_values": 0.01}, {"latitude": -6.2073, "longitude": 106.7531, "aod_values": 1.9482}, {"latitude": -6.1535, "longitude": 106.9108, "aod_values": 0.01}, {"latitude": -6.2888, "longitude": 106.9091, "aod_values": 0.01}, {"latitude": -6.1811, "longitude": 106.8279, "aod_values": 0.01}, {"latitude": -6.2366, "longitude": 106.7931, "aod_values": 0.01}]	2026-05-26
75	1	[{"latitude": -6.1946, "longitude": 106.8235, "aod_values": 0.119399995}, {"latitude": -6.3569, "longitude": 106.8036, "aod_values": 0.3928}, {"latitude": -6.2155, "longitude": 106.803, "aod_values": 0.119399995}, {"latitude": -6.2073, "longitude": 106.7531, "aod_values": 0.2136}, {"latitude": -6.1535, "longitude": 106.9108, "aod_values": 0.0462}, {"latitude": -6.2888, "longitude": 106.9091, "aod_values": 0.062}, {"latitude": -6.1811, "longitude": 106.8279, "aod_values": 0.008599999}, {"latitude": -6.2366, "longitude": 106.7931, "aod_values": 0.047799997}]	2026-05-27
76	1	[{"latitude": -6.1946, "longitude": 106.8235, "aod_values": 1.528}, {"latitude": -6.3569, "longitude": 106.8036, "aod_values": 0.01}, {"latitude": -6.2155, "longitude": 106.803, "aod_values": 1.528}, {"latitude": -6.2073, "longitude": 106.7531, "aod_values": 0.97959995}, {"latitude": -6.1535, "longitude": 106.9108, "aod_values": 0.01}, {"latitude": -6.2888, "longitude": 106.9091, "aod_values": 0.01}, {"latitude": -6.1811, "longitude": 106.8279, "aod_values": 0.6264}, {"latitude": -6.2366, "longitude": 106.7931, "aod_values": 0.4174}]	2026-05-28
77	1	[{"latitude": -6.1946, "longitude": 106.8235, "aod_values": 0.3082}, {"latitude": -6.3569, "longitude": 106.8036, "aod_values": 0.6232}, {"latitude": -6.2155, "longitude": 106.803, "aod_values": 0.3082}, {"latitude": -6.2073, "longitude": 106.7531, "aod_values": 0.2598}, {"latitude": -6.1535, "longitude": 106.9108, "aod_values": 0.1814}, {"latitude": -6.2888, "longitude": 106.9091, "aod_values": 0.3076}, {"latitude": -6.1811, "longitude": 106.8279, "aod_values": 0.14999999}, {"latitude": -6.2366, "longitude": 106.7931, "aod_values": 0.3342}]	2026-05-29
78	1	[{"latitude": -6.1946, "longitude": 106.8235, "aod_values": 0.01}, {"latitude": -6.3569, "longitude": 106.8036, "aod_values": 0.01}, {"latitude": -6.2155, "longitude": 106.803, "aod_values": 0.01}, {"latitude": -6.2073, "longitude": 106.7531, "aod_values": 0.01}, {"latitude": -6.1535, "longitude": 106.9108, "aod_values": 0.01}, {"latitude": -6.2888, "longitude": 106.9091, "aod_values": 0.01}, {"latitude": -6.1811, "longitude": 106.8279, "aod_values": 0.01}, {"latitude": -6.2366, "longitude": 106.7931, "aod_values": 0.01}]	2026-05-30
79	1	[{"latitude": -6.1946, "longitude": 106.8235, "aod_values": 0.01}, {"latitude": -6.3569, "longitude": 106.8036, "aod_values": 0.01}, {"latitude": -6.2155, "longitude": 106.803, "aod_values": 0.01}, {"latitude": -6.2073, "longitude": 106.7531, "aod_values": 0.01}, {"latitude": -6.1535, "longitude": 106.9108, "aod_values": 0.31239998}, {"latitude": -6.2888, "longitude": 106.9091, "aod_values": 0.01}, {"latitude": -6.1811, "longitude": 106.8279, "aod_values": 0.01}, {"latitude": -6.2366, "longitude": 106.7931, "aod_values": 0.01}]	2026-05-31
80	1	[{"latitude": -6.1946, "longitude": 106.8235, "aod_values": 0.01}, {"latitude": -6.3569, "longitude": 106.8036, "aod_values": 0.01}, {"latitude": -6.2155, "longitude": 106.803, "aod_values": 0.01}, {"latitude": -6.2073, "longitude": 106.7531, "aod_values": 0.01}, {"latitude": -6.1535, "longitude": 106.9108, "aod_values": 0.01}, {"latitude": -6.2888, "longitude": 106.9091, "aod_values": 0.01}, {"latitude": -6.1811, "longitude": 106.8279, "aod_values": 0.01}, {"latitude": -6.2366, "longitude": 106.7931, "aod_values": 0.01}]	2026-06-01
81	1	[{"latitude": -6.1946, "longitude": 106.8235, "aod_values": 0.01}, {"latitude": -6.3569, "longitude": 106.8036, "aod_values": 0.01}, {"latitude": -6.2155, "longitude": 106.803, "aod_values": 0.01}, {"latitude": -6.2073, "longitude": 106.7531, "aod_values": 0.01}, {"latitude": -6.1535, "longitude": 106.9108, "aod_values": 0.01}, {"latitude": -6.2888, "longitude": 106.9091, "aod_values": 0.01}, {"latitude": -6.1811, "longitude": 106.8279, "aod_values": 0.01}, {"latitude": -6.2366, "longitude": 106.7931, "aod_values": 0.01}]	2026-06-02
82	1	[{"latitude": -6.1946, "longitude": 106.8235, "aod_values": 0.01}, {"latitude": -6.3569, "longitude": 106.8036, "aod_values": 0.01}, {"latitude": -6.2155, "longitude": 106.803, "aod_values": 0.01}, {"latitude": -6.2073, "longitude": 106.7531, "aod_values": 0.01}, {"latitude": -6.1535, "longitude": 106.9108, "aod_values": 0.01}, {"latitude": -6.2888, "longitude": 106.9091, "aod_values": 0.01}, {"latitude": -6.1811, "longitude": 106.8279, "aod_values": 0.01}, {"latitude": -6.2366, "longitude": 106.7931, "aod_values": 0.01}]	2026-06-03
83	1	[{"latitude": -6.1946, "longitude": 106.8235, "aod_values": 0.01}, {"latitude": -6.3569, "longitude": 106.8036, "aod_values": 0.3242}, {"latitude": -6.2155, "longitude": 106.803, "aod_values": 0.01}, {"latitude": -6.2073, "longitude": 106.7531, "aod_values": 0.4206}, {"latitude": -6.1535, "longitude": 106.9108, "aod_values": 0.708}, {"latitude": -6.2888, "longitude": 106.9091, "aod_values": 0.583}, {"latitude": -6.1811, "longitude": 106.8279, "aod_values": 0.01}, {"latitude": -6.2366, "longitude": 106.7931, "aod_values": 1.0014}]	2026-06-04
84	1	[{"latitude": -6.1946, "longitude": 106.8235, "aod_values": 0.02}, {"latitude": -6.3569, "longitude": 106.8036, "aod_values": 0.0188}, {"latitude": -6.2155, "longitude": 106.803, "aod_values": 0.02}, {"latitude": -6.2073, "longitude": 106.7531, "aod_values": 0.3646}, {"latitude": -6.1535, "longitude": 106.9108, "aod_values": 0.5484}, {"latitude": -6.2888, "longitude": 106.9091, "aod_values": 0.0374}, {"latitude": -6.1811, "longitude": 106.8279, "aod_values": 0.01}, {"latitude": -6.2366, "longitude": 106.7931, "aod_values": 0.0962}]	2026-06-05
85	1	[{"latitude": -6.1946, "longitude": 106.8235, "aod_values": 1.8146}, {"latitude": -6.3569, "longitude": 106.8036, "aod_values": 0.003}, {"latitude": -6.2155, "longitude": 106.803, "aod_values": 1.8146}, {"latitude": -6.2073, "longitude": 106.7531, "aod_values": 0.49859998}, {"latitude": -6.1535, "longitude": 106.9108, "aod_values": 0.6132}, {"latitude": -6.2888, "longitude": 106.9091, "aod_values": 0.72179997}, {"latitude": -6.1811, "longitude": 106.8279, "aod_values": 0.41239998}, {"latitude": -6.2366, "longitude": 106.7931, "aod_values": 0.01}]	2026-06-06
86	1	[{"latitude": -6.1946, "longitude": 106.8235, "aod_values": 0.01}, {"latitude": -6.3569, "longitude": 106.8036, "aod_values": 0.01}, {"latitude": -6.2155, "longitude": 106.803, "aod_values": 0.01}, {"latitude": -6.2073, "longitude": 106.7531, "aod_values": 0.01}, {"latitude": -6.1535, "longitude": 106.9108, "aod_values": 0.6616}, {"latitude": -6.2888, "longitude": 106.9091, "aod_values": 0.01}, {"latitude": -6.1811, "longitude": 106.8279, "aod_values": 0.01}, {"latitude": -6.2366, "longitude": 106.7931, "aod_values": 0.01}]	2026-06-07
87	1	[{"latitude": -6.1946, "longitude": 106.8235, "aod_values": 0.718}, {"latitude": -6.3569, "longitude": 106.8036, "aod_values": 0.01}, {"latitude": -6.2155, "longitude": 106.803, "aod_values": 0.718}, {"latitude": -6.2073, "longitude": 106.7531, "aod_values": 0.2472}, {"latitude": -6.1535, "longitude": 106.9108, "aod_values": 0.01}, {"latitude": -6.2888, "longitude": 106.9091, "aod_values": 0.01}, {"latitude": -6.1811, "longitude": 106.8279, "aod_values": 0.2164}, {"latitude": -6.2366, "longitude": 106.7931, "aod_values": 0.01}]	2026-06-08
88	1	[{"latitude": -6.1946, "longitude": 106.8235, "aod_values": 0.01}, {"latitude": -6.3569, "longitude": 106.8036, "aod_values": 0.01}, {"latitude": -6.2155, "longitude": 106.803, "aod_values": 0.01}, {"latitude": -6.2073, "longitude": 106.7531, "aod_values": 0.01}, {"latitude": -6.1535, "longitude": 106.9108, "aod_values": 1.5144}, {"latitude": -6.2888, "longitude": 106.9091, "aod_values": 3.5014}, {"latitude": -6.1811, "longitude": 106.8279, "aod_values": 0.01}, {"latitude": -6.2366, "longitude": 106.7931, "aod_values": 0.01}]	2026-06-09
\.


--
-- Data for Name: aod_pm25estimate; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.aod_pm25estimate (id, aod_id, valuepm25, date) FROM stdin;
\.


--
-- Data for Name: aod_pm25polygon; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.aod_pm25polygon (id, pm25_id, geom, pm25_value, date) FROM stdin;
\.


--
-- Data for Name: aod_polygon; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.aod_polygon (id, aod_id, geom, aod_value, date) FROM stdin;
453	89	0103000020E6100000010000000E010000000000E0CCB45A4000000060CC4C19C0000000E0CCB45A409ECE0168A56C19C005C1E3DBBBB45A40403D6CD8A56C19C09BE5B2D1B9B45A4030F0DC7BB86C19C0DF1797AAB4B45A4056A1DC11A96C19C0244D17BDAEB45A401D22C907986C19C0CE6449CAA7B45A407BBE66B96C6C19C0F56F4D70A0B45A4059164CFC516C19C0E2D8695A98B45A40F4948BE7226C19C0601DC70F95B45A405475EA25216C19C08CD6F61B92B45A402B476D872B6C19C0FE3E88098FB45A40829774EF3C6C19C08ECEF9298EB45A4095826E2F696C19C08F1CE90C8CB45A402EC901BB9A6C19C0895FB1868BB45A4044317903CC6C19C03BC269C18BB45A408E3EE603026D19C02BA5677A89B45A4027A25F5B3F6D19C0CCB6D3D688B45A40C0AE264F596D19C0AE669DF17DB45A40E3175E49F26C19C09D6340F67AB45A40FF59F3E32F6D19C0861E317A6EB45A40C23577F4BF6C19C0778368AD68B45A40931D1B81786D19C0CD45329A4BB45A40E7B1C11D036D19C054E641D543B45A40865AD3BCE36C19C0FF76D9AF3BB45A4061C5A9D6C26C19C0E3A8DC442DB45A402FC1A90F246F19C0C879FF1F27B45A40AD6EF59CF46E19C0C43E011423B45A40228B34F10E7019C0AE2D3C2F15B45A40A5D8D138D46F19C0A8565F5D15B45A40CCF09F6EA07019C04F1F813FFCB35A40D05499733A7219C06FA0C03BF9B35A40DA756F45627219C04D158C4AEAB35A4033E197FA797319C0390B7BDAE1B35A402DB5DE6FB47319C03A3FC571E0B35A400E130D52F07419C002F4FBFECDB35A403CC1FEEBDC7419C087D569EEB2B35A40312999F7937419C02D9B94DDA7B35A40EF84A80C2D7419C0F2CC70A884B35A4088C73489307419C06B31D35169B35A406D1D1CEC4D7419C01B7FA2B261B35A40FB0626378A7419C01DF2857F47B35A40892E03290C7519C019AE0E8038B35A40BB9A3C65357519C05AB741ED37B35A40D9C1D20A1D7519C052C543CE31B35A408BC56F0A2B7519C01893A3A517B35A400247020D367519C089F260E616B35A40CA3E7E25467519C072CDD36F15B35A40ADCC4A49C57519C097981D9812B35A403ED8182AB57519C05825EC3603B35A400983D7D3B37519C0615C6045FCB25A40E204A6D3BA7519C085F0C39CFBB25A4031E82917CF7519C05CF80B87EFB25A40B9B94269B97519C0B2AC4555DDB25A4047F5E7ECAE7519C02B5FE16EDAB25A40BAD1110A5B7519C0C6DBEFF5DAB25A40ABD61DE6267519C0D2BA57F7D9B25A40E87EF3870B7519C07FD93D79D8B25A40C0536DDC077519C083C6A75BD1B25A40C66757C62B7519C0913BB6AFCDB25A4089F83DA0227519C06116DA39CDB25A40B785425FD57419C0EC7882B3CAB25A4001C864CCB87419C0DF991AB2CBB25A409EC02ACD9C7419C0274C18CDCAB25A402315C616827419C07F0F0302C2B25A407D4DC57C2F7419C00ECD8646C1B25A40CF520D56F77319C09C36E334C4B25A40E085ADD9CA7319C095D233BDC4B25A400927B38BB37319C0AEE98BCEC3B25A406A5DB411997319C0BA3885F0C3B25A4051EF4EE3837319C094F77134C7B25A409AF4ADC55D7319C09AE2BBDEC7B25A402F09617F237319C07B67B455C9B25A40403C0103F77219C0FE00B562C9B25A408C811A63CC7219C01189E711C8B25A40CF8F75278E7219C0277A2AF1CAB25A403F28DEB7107219C010E26F20C9B25A404CD2EB05557119C044A74297CBB25A406C393C29387119C0FD811722CCB25A40DA3E3FE7C97019C0CEA78E55CAB25A40DFBAACD3927019C0B2DC2D24BBB25A40A45D3B07856F19C08330B77BB9B25A4053E34AE2516F19C0BA49B148B8B25A407888354BB86E19C036DB2626B9B25A4030B88BD58B6E19C0EE0E84BFBAB25A402D3E05C0786E19C0E656ADF1BEB25A40581CCEFC6A6E19C0399787F1BFB25A4007DCA96F4F6E19C0B03DB324C0B25A4059D9E32ABB6D19C05B4D8D86C2B25A409D7BB4DDA96D19C090E7E912C4B25A40A1A17F828B6D19C01941BEDFC3B25A404128942AF66C19C08BD761F1C0B25A40BDCEE1B5A66C19C07924B957C1B25A4026FDBD141E6C19C09D8A0A8BC0B25A401D8535DFD26B19C0CC649357C2B25A40D23A0554936B19C0E2AE5E45C6B25A400E4C6E14596B19C068D94933CCB25A402AF97DA42D6B19C0FB2DF0CBCFB25A401E424B0D236B19C0480A1B54D1B25A40CD012780076B19C05ABDC3EDD0B25A4008139040CD6A19C0FB720B02D0B25A4098512CB7B46A19C0C138B874CCB25A4083B6E6D88B6A19C034D2F7BFC8B25A40FA505898746A19C0DD81959EC4B25A40FFD0CC936B6A19C0788E1205C4B25A400C6E10525C6A19C0B37279BDC5B25A408B6CE7FBA96919C07F40B15FC1B25A40A20914B1886919C0C4FF67DEBBB25A40CE93217D496919C0EFD23C36B8B25A40B12DA814E06819C066D58CB1B8B25A401367A08DB76819C0D13538B6C3B25A4017DBFF5B246819C0E91E23EACFB25A407A30CE84CB6719C05473B9C1D0B25A402C6D2700B56719C0D6DB0B71D1B25A402A77FA9C166719C072A36DA1D0B25A4008CFDFDFFB6619C04AC09E65CCB25A4018FF8870DD6619C0B573F5BECCB25A4001EABC7CA16619C015DE8A69CBB25A4096E1896A5B6619C0810DE3C9C9B25A40E5338FB2346619C0A55C2BEBC8B25A4079495288366619C0BDE6B056C8B25A40657C4E30526619C0A14CA3C9C5B25A40CC56A87F5A6619C01941BEDFC3B25A40B7161C14836619C085701640C2B25A40B20639398D6619C0A9BF5E61C1B25A40E9EEDF617F6619C056D80C70C1B25A4096E1896A5B6619C039807EDFBFB25A406919A9F7546619C08D2551D4BEB25A40DB8651103C6619C0F21B70A7BEB25A408D1656E01A6619C06E6292DBC0B25A40922639BB106619C04A134ABAC1B25A4009313C9BFA6519C0D915E934C1B25A4071F1A611E96519C09E769DB2BFB25A40AC76A801DE6519C0C9BC9F64BCB25A404DE3CDD02E6519C085814298B6B25A4076F05D94EA6419C09088844AB7B25A409AED0A7DB06419C018946934B9B25A40501A6A14926419C0C4EE963FBAB25A40A5EFDA4A546419C01821E120C6B25A4012D5004AE86319C0B46A2112CFB25A40DA869B9D566319C0DB4A5414D4B25A40F616C5611F6319C0E72620DCD3B25A40356FE6A1006319C034D8D479D4B25A403DBF83FAF16219C0562F1A8DD7B25A40D7E7209EDB6219C073E3CC65D9B25A40643DB5FAEA6219C018D75306E9B25A4095CF9783456219C05861E932EBB25A40372FF3C2426219C04A62A472EEB25A409B73F04C686219C044882B67EFB25A4093077D44A76219C02C9FE579F0B25A40D4C045DDBD6219C07198C349F5B25A4007BDEDF8E56219C0E5E72BEDF9B25A403485CE6BEC6219C0D150ED1DFFB25A40DB807456B06219C081BBA24A03B35A4004711E4E606219C0152D8A6805B35A4056CD188B4B6219C0856C6AEA06B35A40286ECB36266219C09173AC9C07B35A406E861BF0F96119C062DBA2CC06B35A402CCD5257E36119C04A511D6107B35A400C7ACAC5736119C0429CE2CC0AB35A4084D95FD1086119C0B2DBC24E0CB35A40230FE95CF66019C0A2540CA114B35A401148D3EAF56019C096D1C8E715B35A40E0E297B0EC6019C0B976FDDD16B35A404B3558DD8F6019C0770E0AEF17B35A4054A5D2F47E6019C04BC56B031CB35A408DEA1967786019C0C64D0D341FB35A40F22D07D5616019C0074BD0BA21B35A4001B15BBA386019C01252126D22B35A4034524A630F6019C02A38BC2022B35A40253A7073CF5F19C0896E073422B35A40DC9F8B868C5F19C01294916923B35A40FC766DCA705F19C0EBED85B828B35A40BDAAB35A605F19C0AF14B82B2AB35A4044094499575F19C0C6F4296C2BB35A40AC394030475F19C0674BB1FE2AB35A4071CC0DE1F35E19C0064E113B2EB35A400C9EF820BA5E19C0192197932BB35A4013B0C2D2655E19C06DDD729A2AB35A40BA17F3CEFC5D19C0891288322FB35A4065187783685D19C0B1F8F2A732B35A4044E7EBE86E5D19C0A327C00B36B35A4038F6ECB94C5D19C038FE9F1E36B35A40C49A255C235D19C01C53C1F231B35A40A66F88A70D5D19C0D55E44DB31B35A40035FD1ADD75C19C02D9ED55D34B35A407BDF5394A65C19C0FFF7962831B35A40E91E23EA4F5C19C01D9E149C30B35A40A1C10188165C19C011DCED1F30B35A40592A148EC55B19C0A6423C122FB35A40A0D2D226985B19C0B00683C627B35A40B8A4B448245B19C0B937BF6122B35A4022670696C85A19C0DE301BAE1FB35A40411A040C815A19C04413CDA81EB35A4028FF4932615A19C0BBEAA6391EB35A405B4D8D86425A19C0376277CB1FB35A403FD532631B5A19C0DDCEBEF220B35A405F398C930C5A19C01252126D22B35A4009162C7A4C5919C0721B689920B35A40F40A557B225919C0AF8108CC1EB35A40D02280400C5919C032384A5E1DB35A40FF7CB669C75819C00915C1A41DB35A408274B169A55819C0D32C75351EB35A406CD674988A5819C03DEE00F420B35A40982ABDDB615819C095EB127A22B35A409B8246FAFE5719C0F374AE2825B35A406E707DB3285719C0E1DBAADA24B35A40017F42870A5719C00481DFD025B35A4076824765D45619C0E0A4C40927B35A405299620E825619C06943B40C27B35A402D8DA905405619C04A7D59DA29B35A408896E1E4235619C0FC975AA52AB35A408B451D67E45519C0FCDC75DB2AB35A40CAF0E9FBBA5519C0D3D9C9E028B35A40E84D452A8C5519C0E572CD2E29B35A403033C74D685519C09B24F14D2EB35A4073B9C150875519C0A62897C62FB35A40E98601A6675519C0CEFA946332B35A40017ED7B15B5519C02C84301235B35A405FE8B6E9745519C0B8825C983BB35A405DE2C803915519C0C826F9113FB35A40460BD0B69A5519C00DC1166044B35A40756D14FEB15519C0F83D45694AB35A40A3C85A43A95519C03DB088064EB35A40F33746578E5519C0951D2CAD50B35A407582ECAB615519C0E29A96B352B35A4031D7FDBEDA5419C0FADF00E951B35A401A52A0AA9D5419C0E846FD9A51B35A406C1A25F95B5419C0F45377C050B35A406E2013DF3F5419C0F2214D614AB35A4029931ADA005419C076F2333F48B35A40130EBDC5C35319C04097BA7548B35A40B54C2B2A875319C01AAF2FC84CB35A40FE4D83FD325319C0F01241414EB35A40D472B1B3325319C06B98463852B35A40AB611AE1485319C0F38C221054B35A406A55A6F33C5319C0B6DB2E3457B35A400AAE03311A5319C0DEB0C80A59B35A40AD6301B8FE5219C0A71BCD365CB35A40F44185D9BA5219C0DC5669415EB35A40697F564F9C5219C0BD4BF3D860B35A4039CA66B38F5219C0A89DABF765B35A403A73B44F6C5219C0943AB7BF69B35A40154D0C6E105219C0CF914BD26BB35A4023E6481DD35119C0CF914BD26BB35A40238F96B9AF5119C094AA48E06AB35A40CAD5D9DA0C5119C08802C7AF69B35A40115C9B7C695019C01D07B9E669B35A405836188FF74F19C04139C0826AB35A4041ADB36B8C4F19C0F9B4D48B6BB35A408688409A564F19C0AA3F67776DB35A409FB8D221264F19C06802EA726FB35A40FECBFFF51B4F19C0D298FF4671B35A4089377C1C174F19C08E661B6E76B35A4016FC917DEB4E19C0F98C9F2177B35A405AD427B9C34E19C0FE18294A78B35A405B7D7555A04E19C0B198220A77B35A403CB94B87F34D19C08159A14877B35A40D2B71677CD4D19C046E22F7777B35A4017E64EFA8C4D19C00BFB2C8576B35A408E290E56524D19C06A3414D275B35A40188E8C7A2D4D19C07095271076B35A40D4049B841C4D19C0FF7D213F76B35A40D50792770E4D19C0040AAB6777B35A4031BE1E02FD4C19C09E0AB8E779B35A404895174FF34C19C00D2D57E47CB35A40EC342D0CEC4C19C07E6FD39F7DB35A40D3533FCAE34C19C0E3795F4B7EB35A401AE31EA6D84C19C00A49FF797EB35A4000000060CC4C19C0000000E0CCB45A4000000060CC4C19C0	0.9101999998092651	2026-06-09
467	89	0103000020E610000001000000A70000000000000000B85A40000000A0991919C00000000000B85A400000006066E618C00000004033BB5A400000006066E618C00000004033BB5A4019AFF409DD0419C05E143DF031BB5A40E02A4F20EC0419C0A8AAD0402CBB5A40E02A4F20EC0419C04DF4F92823BB5A40FDF84B8BFA0419C0228E75711BBB5A40B9FFC874E80419C0793A579412BB5A404C4F58E2010519C0A296E65608BB5A402524D236FE0419C0E92807B309BB5A40467A51BB5F0519C05F0839EFFFBA5A40E5266A696E0519C048E00F3FFFBA5A4085EB51B81E0519C0BABBCE86FCBA5A40300DC347C40419C0AA9ECC3FFABA5A40A306D3307C0419C0967A1684F2BA5A40D192C7D3F20319C0D905836BEEBA5A405A1135D1E70319C0EE26F8A6E9BA5A40234E27D9EA0219C07B1D273BECBA5A40079C001EAC0219C0C8CEDBD8ECBA5A40C9E7154F3D0219C064C7EB66EBBA5A4090CB6E1C670119C056F0DB10E3BA5A40B08971A36D0119C08264F0E6DFBA5A402F8095E8D10119C027C522E1D6BA5A402465E65D500219C0106FE70CD6BA5A4095CCFB49C60319C0F8A57EDED4BA5A40B20D81C8C70319C05E8BCC12D3BA5A4017388F79D30319C0055A70F5D2BA5A40EE26F8A6E90319C035DBCB6CC6BA5A4096D3F94BE60319C03FCD2445BFBA5A401FA80991C20319C0D430D7FDBEBA5A407CFB2944760419C0A40BFB87BEBA5A40608033E7CF0519C0FB3BDBA3B7BA5A406AF7AB00DF0519C007019E59B7BA5A40A2EB67565B0619C0D1F8CFE4ACBA5A40A34511AD700619C09D1F9095A9BA5A409FE57970770619C0A69883A0A3BA5A4001EABC7CA10619C0D40AD3F79ABA5A4061CA1BBB9F0619C030C104C996BA5A4068C81DDBD70619C083BCC39297BA5A40B95FF4CB160719C09873DF2090BA5A401F8DF96F140719C05979B8D38CBA5A4014138A63130719C077363F598CBA5A406919A9F7540619C043F8BC8770BA5A4062C50490350619C0C044172F71BA5A408DDC8948030619C02F2D8FDA69BA5A40E13B7B78E00519C0EA1CA8F864BA5A40C6E3FD13B70519C0650C62565EBA5A40CC6262F3710519C0A80D98D159BA5A4075D88EF3480519C06FBFD76B55BA5A4010093AB58E0519C0730866964EBA5A40D5D6E3198F0519C028DC86AC49BA5A407689EAAD810519C0BF373C7345BA5A40B4C12E2F650519C07E737FF538BA5A403C07E0B07E0519C035D252793BBA5A4048927B15740619C09E6230DA3EBA5A4047C5A464DE0719C0B0404F5E3FBA5A4045C3BD8D280819C06812ABF534BA5A40590861246A0819C073E261902ABA5A408A1EF818AC0819C0D3E759FF1DBA5A4001BE8003FF0819C0B842B34618BA5A404CEEC1B5240919C04D8F5CED17BA5A40BDE5EAC7260919C00695021C0CBA5A40F585EBAC710919C0A9CF1FE406BA5A40A9030FC2920919C0ECE4C23703BA5A4032699D02AA0919C0CAFD0E4501BA5A40C7BB2363B50919C00D72721AFDB95A40394AB956D60919C045C88A2BF8B95A400E164ED2FC0919C0124E0B5EF4B95A40F69507E9290A19C0E98F7A99F2B95A40AECD6B91590A19C0012E6DDDF2B95A400E3F49CB920A19C0F5DBD781F3B95A4024383F0FFF0A19C0CEE737A7EDB95A40DE3CD521370B19C040081225EBB95A4073E60DE6650B19C014CA671EE5B95A406C150ECEF10B19C08DB04DCFE0B95A40F648DE944D0C19C0A431FF8DE2B95A405D273FF3830C19C0988CBEDDEDB95A40487C3892150D19C096F37B51F1B95A4014F131B32A0D19C08F6FEF1AF4B95A40041C42959A0D19C00D0A39A5F2B95A40BB698E07B60D19C080EECB99EDB95A405C525A24920D19C0FE881524ECB95A4020240B98C00D19C03914F4CDECB95A4036898BEDFF0D19C0FE881524ECB95A408DFD76233D0E19C0C3FD367AEBB95A40FA980F08740E19C02C2CB81FF0B95A40934F34B4A60E19C032906797EFB95A406E15C440D70E19C0988CBEDDEDB95A40A8B4B409E60E19C0F4D25E8EE8B95A40D4CF40D1E10E19C037E2C96EE6B95A40E934C126210F19C0661EAFF6E6B95A400C1EA67D730F19C080EECB99EDB95A408E1EBFB7E90F19C094C151F2EAB95A40782AE09EE70F19C0B57C13F9E4B95A409B13C5F5391019C079F1344FE4B95A40B078454B791019C01F44D72AE6B95A4058800063C71019C0D1E57228E8B95A40EA5509BBCD1019C07C235FAEEAB95A40428C214AC51019C02276018AECB95A4024F5F983DC1019C00AD80E46ECB95A40395A7AD91B1119C059367348EAB95A40BDE9F1D6541119C0DB9B29BEEBB95A4064247B849A1119C0AB5F4436EBB95A40EE563B2FBA1119C03BAD365AE9B95A40C1AC50A4FB1119C01DAB949EE9B95A400A9DD7D8251219C0AB5F4436EBB95A40AAF644323F1219C00354820FEFB95A408C5F1D6C561219C04F19A485F0B95A4027A5A0DB4B1219C0AE916E95F1B95A40544F8B660A1219C04895174FF3B95A40EDC7DC6BF71119C011D5A590F5B95A40806A172E061219C0E91C4D3FF2B95A4092B1DAFCBF1219C001BB3F83F2B95A409992F650EC1219C0EEE7B92AF5B95A4032491BFD1E1319C011D5A590F5B95A409EE4B3E1551319C0BAE067B7F1B95A40CA3D1350971319C0887258D0EAB95A40ADA6EB89AE1319C04DE77926EAB95A40C20B6CDFED1319C01B796A3FE3B95A40946181542F1419C0EDD5C743DFB95A406984C833791419C09AACF655DEB95A402D5679A7A71419C0B24AE999DEB95A40F2272A1BD61419C0AAC65C63E1B95A40F2272A1BD61419C0560449E9E3B95A40013BEDDFAB1419C0B94780E4E7B95A40427D2656A11419C0A4DBB7FFEDB95A407579CE71C91419C03EDF60B9EFB95A408C6DAD8ACB1419C001BB3F83F2B95A40013BEDDFAB1419C08F6FEF1AF4B95A408C6DAD8ACB1419C00586AC6EF5B95A4033A83638111519C0BEABD4A2F4B95A4099A0866F611519C08DD6AC8EF7B95A40C36A871AE01519C04F92AE99FCB95A40191241E6141619C05BE1A7BBFCB95A40351A0AE93A1619C01EBD8685FFB95A40DEE3F159431619C07B9C0E0904BA5A40873C388E0E1619C02D3EAA0606BA5A40126FF8382E1619C0388DA32806BA5A40FBB8ECC6711619C0AD0A1EF00ABA5A4018C1B5C9971619C0A68691B90DBA5A40A2F37574B71619C092B30B6110BA5A404ABD5DE5BF1619C0911AC9D413BA5A4043DC4191931619C0ABEAE5771ABA5A40C72DE6E7861619C0DFF137EB1DBA5A4043DC4191931619C02433CD2A22BA5A40617369577C1619C0DBBFB2D224BA5A4086EBAC71911619C06B0DA5F622BA5A4092E0B2AFE11619C0775C9E1823BA5A40A8453305211719C0B2E77CC223BA5A40983270404B1719C08D614ED026BA5A4039590F046D1719C049B9A0632CBA5A40D49E9273621719C0FF25A94C31BA5A40AF264F594D1719C03818456A35BA5A40EA549EE51E1719C067542AF235BA5A40EA16CB3ED91619C00DA7CCCD37BA5A4008AEF204C21619C0D082AB973ABA5A4067C526E8E51619C0A51133FB3CBA5A407C2AA73D251719C0F83A04E93DBA5A40830BC391511719C04832AB7738BA5A409F138C94771719C042CEFBFF38BA5A402A841FE6DC1719C07FF21C3636BA5A4072A774B0FE1719C04BEBCAC232BA5A4028F5C0221A1819C012F92EA52EBA5A4017CF45E80C1919C01CAFE53A32BA5A40F8A8BF5E611919C0D374E0B033BA5A40000000A0991919C00000000000B85A40000000A0991919C0	0.6693999767303467	2026-06-09
468	89	0103000020E61000000100000005000000000000C0CCB45A40000000A0991919C0000000C0CCB45A400000006066E618C00000000000B85A400000006066E618C00000000000B85A40000000A0991919C0000000C0CCB45A40000000A0991919C0	0.4983999729156494	2026-06-09
469	89	0103000020E610000001000000050000000000000000B85A40000000A067E618C00000000000B85A400000006034B318C00000004033BB5A400000006034B318C00000004033BB5A40000000A067E618C00000000000B85A40000000A067E618C0	0.6237999796867371	2026-06-09
470	89	0103000020E610000001000000180000000000006066AE5A400000006034B318C0000000A099B15A400000006034B318C0000000A099B15A40000000A067E618C0338516D836AF5A40000000A067E618C0090A720635AF5A408DA2BDB0EBE518C07B13437232AF5A40526342CC25E518C03D2828452BAF5A407AC8940F41E518C051DEC7D11CAF5A4068AED3484BE518C0C9737D1F0EAF5A4068AED3484BE518C0BF2A172AFFAE5A407FA2B2614DE518C0A8E507AEF2AE5A407FA2B2614DE518C0293FA9F6E9AE5A407FA2B2614DE518C0DB5031CEDFAE5A4068AED3484BE518C08D7C5EF1D4AE5A4051F4C0C760E518C046B3B27DC8AE5A40A18499B67FE518C044149337C0AE5A40132C0E677EE518C02C64AE0CAAAE5A40404E98309AE518C0813D26529AAE5A407E8AE3C0ABE518C095F3C5DE8BAE5A409B75C6F7C5E518C0F0A65B7688AE5A405C7347FFCBE518C01C075E2D77AE5A406D8D08C6C1E518C0E20511A969AE5A40AC8F87BEBBE518C00000006066AE5A40F85678CEB8E518C00000006066AE5A400000006034B318C0	0.6615999937057495	2026-06-09
454	89	0103000020E61000000100000013010000000000A099B15A40000000609A1919C0000000E0CCB45A40000000609A1919C0000000E0CCB45A40000000A0CD4C19C0D3B73F757EB35A40000000A0CD4C19C0BFB7E9CF7EB35A40794CEEC1B54C19C04209336D7FB35A4020F2F164924C19C0959460167FB35A408F728B54734C19C0C04758AF7DB35A407841E9B0674C19C06DD6CF517DB35A407A47D7964B4C19C0D0EBF42881B35A40BE721827194C19C0577BD80B85B35A400455A357034C19C0FD18CE9085B35A4052312999F74B19C01B77949485B35A407345CE67E54B19C0F22895F084B35A40D30847DAD74B19C0DA73999A84B35A40749B70AFCC4B19C03F0E942584B35A40AE9003C0C24B19C093C7D3F283B35A407FDB1324B64B19C02E7590D783B35A409862580FA94B19C093C7D3F283B35A405EC367469A4B19C05D6C5A2984B35A4072AD516A8A4B19C0F2118CDE84B35A407440B73C7B4B19C0EB7992CF86B35A403AA1C6736C4B19C014C5F53988B35A406F6990DD604B19C0EE10B5238BB35A4004824AA6544B19C0EDD9CE528DB35A40A5315A47554B19C0AB9C514E8FB35A40A2F19FC9594B19C0D354AA9F92B35A40D5D06119764B19C0EFA600BD95B35A4008B02369924B19C0053C1F5498B35A40D767CEFA944B19C0B1378CDD99B35A400D309864894B19C0E64416C49BB35A400619B787734B19C06999FB9A9BB35A400002D6AA5D4B19C076EE2C309AB35A4038B3A72E2A4B19C088484DBB98B35A404A40F108134B19C0E2ADF36F97B35A40E618DA4AF94A19C0E945ED7E95B35A404852D2C3D04A19C05BD3BCE394B35A405E5F9099B04A19C0785CF9D195B35A409610621D7D4A19C0C435882098B35A4029CC7B9C694A19C0F25190E99AB35A407E326BCE664A19C0625D26D49DB35A40DE825B2D664A19C03659A31EA2B35A408FBCBDB55D4A19C00B8C063AA4B35A404CC631923D4A19C0E6C3584BA6B35A40FDE2AD4E294A19C0863C821BA9B35A4042BE3A7DF34919C0A9F8BF23AAB35A40B4BB5175D94919C0863C821BA9B35A40CD5B751DAA4919C004F40C2BA6B35A401E0B1BAF8A4919C0A04BDD3AA4B35A400CCD751A694919C08324FD07A2B35A40B1FCF9B6604919C0BBE70A009FB35A4007301B53664919C0EBE40CC59DB35A40C3537E08604919C0FCD9345B9EB35A40C5A810340B4919C06D301EEF9FB35A40DDF58887E64819C03054B428A2B35A40A8D60CBACE4819C0BE33DAAAA4B35A40254B9CCBC34819C074BD2319A8B35A404FB6DCF4C24819C0327D0ADBAAB35A4090DB2F9FAC4819C0E96B4C3EACB35A4013807F4A954819C0729472ADACB35A4073EC4559644819C0AE6AA400ACB35A40C03456AC2B4819C0C6C61748ABB35A409F724C16F74719C0C0EF3A76ABB35A40779A71BFE84719C02ADFD858AEB35A407606FCD0BB4719C047F5E7ECAEB35A40A39410ACAA4719C0836C59BEAEB35A4027593D16914719C0E8AA2F01AEB35A405477C0D07E4719C0B9FB1C1FADB35A404D60DFF3684719C043A3E0CEAAB35A403D7FDAA84E4719C0140BD7FEA9B35A40DCB75A272E4719C0497ABDA0AAB35A40EBC726F9114719C0423EE8D9ACB35A4063F20698F94619C0411E0B1BAFB35A40D21BEE23B74619C02907B309B0B35A4071E1E58EA34619C02E7997E6B1B35A40F95F538C984619C0A416EF6CB4B35A40894B44AE8A4619C0E4897B87B6B35A40C033EBD67C4619C0C69B46A4B7B35A40399B8E006E4619C0C69B46A4B7B35A4010F97832494619C00278B06AB5B35A4027E9503C1D4619C0C8DB0022B3B35A408E322C90EA4519C040B91226B1B35A40EC0786BD9A4519C088687407B1B35A40A7B45950734519C0C324010FB1B35A40AFCA2A114D4519C03F993567B3B35A40B64C86E3F94419C032CB9E04B6B35A404DA5FA29E94419C0E8DB82A5BAB35A409A5C8C81754419C041AB8207BCB35A40BBFDA83C704419C0C2F69331BEB35A4033F2C3526E4419C0F70082DEC0B35A40023ADDC36F4419C04FD08140C2B35A40F22213F06B4419C0B4082010C3B35A400A1AE9FB5F4419C06C9ED964C3B35A4089B14CBF444419C01F189BB1C3B35A4001DC2C5E2C4419C0253493B9C3B35A40C9EC87331A4419C0E9EDCF45C3B35A4040A4DFBE0E4419C032022A1CC1B35A4088539C59014419C00F5DF525C0B35A4048BAB07FE84319C00F18DAEFBFB35A401F189BB1C34319C0B528FDCEC0B35A401E4E603AAD4319C08BD1297EC2B35A40465C001AA54319C0849554B7C4B35A406F34DB70B34319C0C408E1D1C6B35A40AF038CD3B54319C0A61AACEEC7B35A40465C001AA54319C016461F98C8B35A40DE27FD73874319C03AA63858C9B35A405DBF60376C4319C0341477BCC9B35A40147C2EAE4C4319C063676556CAB35A40243C461E2D4319C0E68D3809CAB35A40BBCA7FED054319C03AEB538EC9B35A40B3C986DADB4219C02EF87EB4C9B35A40A2ABBE04B84219C0931CB0ABC9B35A4031033A387D4219C0B7515381C9B35A40D4658C6A6C4219C0C9491751C9B35A40B36AC6585C4219C099F628B7C8B35A4048669A55444219C02EFEB627C8B35A405436ACA92C4219C0F463DD89A3B35A40DE825B2D664219C05F03C70AA3B35A40BF21F9EF664219C0C00303089FB35A40100874266D4219C098A432C59CB35A40024E4A9C704219C0754419059CB35A40A8BA91C3714219C0F881F5C99BB35A4071D2EA9A7F4219C0B011D26490B35A40D81CD60A894219C04E86996C72B35A406CDFED8B954219C010165FFE54B35A40DA26CBFF9A4219C06B9BE27151B35A40C9EF236D994219C0B378567751B35A40E7DDFD96A54219C0F485353A0CB35A408F8E064BD04219C00742B28009B35A402D5107C3CA4219C0942CCCE701B35A40F2CB05D3D54219C00FC69970F9B25A405EB642FDD34219C0CC063EABF1B25A4037FE4465C34219C09214A28DEDB25A4001892650C44219C0FE43FAEDEBB25A40942B6112D34219C0D66E6017EAB25A40AAFF626CD74219C0E852B70EE9B25A4037C87FDCD94219C05DB34B0AE2B25A4001E0D8B3E74219C07DF20B0ADEB25A4037C87FDCD94219C04479D5B9D8B25A40FF12A749DF4219C05083B3A5D8B25A40F7329B11EF4219C035D82F33C7B25A40209BE447FC4219C00E993CAFC2B25A40C5E74EB0FF4219C0375D05E7C2B25A407085668D304319C02BDD5D67C3B25A400122B3695B4319C0286618D2BCB25A40EE3AC0385D4319C0C6CCF401B7B25A40E90DF7915B4319C0574E31BDB3B25A40C5D27602504319C03A3E5A9CB1B25A40637891AE3E4319C09A1EB9DAAFB25A40FA4097152F4319C08CBAD6DEA7B25A402096CD1C924219C0A6817A8EA3B25A406EFEBA2E574219C0D2B0732EA0B25A4003FA8E2B3F4219C0B0E600C19CB25A407B415596324219C0ABEAE5779AB25A40250E34FA2C4219C0A6EECA2E98B25A40D0A744C82F4219C06C6CC03195B25A40ADC66D8F394219C0E59189A592B25A40C93EC8B2604219C03F6DF9ED90B25A40B948EBB9964219C0757286E28EB25A407BC102F3EB4219C0A12BB6EE8BB25A40F2F0F9BC3D4319C01ACAE42F88B25A409AA2128DA44319C0D4F8E01085B25A400BC336983C4419C04716D5C768B25A4094B42CA9244419C0B78B1F1961B25A40A33B889D294419C03D88539C59B25A402B476D872B4419C0940E7B4647B25A40BD6E1118EB4319C0511ECCDC32B25A40C61858C7F14319C0FB63100E2CB25A4046274BADF74319C039B69E211CB25A40B87F1B182F4419C0D7A6B1BD16B25A4074B7465F9C4319C0BFAF366B15B25A407BAD3A61784319C0573C9A8F10B25A40E9F417D57D4319C01A8B016D06B25A4000B33165964319C0ED2C7AA702B25A40048761D1BE4319C0303F81C1FFB15A4096438B6CE74319C0F663EEB5FBB15A4018E9EA330C4419C073BED87BF1B15A4037C1DC932C4419C075FBF6BFEDB15A407927FAD74D4419C011B5238BEAB15A40567CE827414419C093ECC7DCEBB15A405D024B091C4419C0BD3D63BAEBB15A409CAD179EF24319C0823CBB7CEBB15A40DA92B0CAE04319C00BC73DA7EAB15A400434B67CC94319C0B29B19FDE8B15A4077DE2120BA4319C0FB39AA3FE7B15A40AAD6C22CB44319C06DCDB117E5B15A409BC2EF4BA24319C08CAA155CE2B15A40392E3E60794319C0E19DD733DFB15A401CB3EC49604319C0E3C3EC65DBB15A400C7F3CAA504319C0C9F08E42C8B15A40BD0743780F4319C0942243D8BAB15A409C0F7459F14219C0C50BD8C4B8B15A40440F2153E34219C06D25CF50B7B15A40114D45CFD24219C04F57772CB6B15A404D987A27B04219C05015F82FB5B15A40B691A1197A4219C0B04EDF7CB4B15A40A10F3BF82E4219C0B04EDF7CB4B15A40F451465C004219C0EB6690CCB4B15A40721B6899A04119C09E6D24BFB4B15A4057506221844119C045285BC9B3B15A4002AC9F48414119C057C7968AB2B15A405E08837C1A4119C0E19634EBB1B15A407C2F1922024119C05885178EB1B15A40415365CEE94019C0648FF579B1B15A4050F39F7FCC4019C05885178EB1B15A40671C34057C4019C0BD337FF1B1B15A407D42D197394019C01CAFE53AB2B15A40D02E3AB4234019C05768D608B3B15A40FEDC2B4E104019C00F5AB4A5B3B15A400A3DAC81F73F19C04BD12577B3B15A40179D2CB5DE3F19C0F22C9CFFB2B15A40FDBB3E73D63F19C09AA5530DB1B15A40F88E75CCD43F19C0C971A774B0B15A40200DA7CCCD3F19C017CAD303B0B15A4017B60B72BC3F19C0DB526232B0B15A4066B56565A03F19C0F97F7AD8B0B15A409DD3D1167C3F19C05283C4D1B0B15A40C0273163653F19C08E59F624B0B15A40F82FB54A553F19C071EA5E82AEB15A407484679D4C3F19C0A3F034F4AAB15A403A92CB7F483F19C02132F66FA8B15A40CA9AA26D463F19C01C785A23A7B15A403398D06E3E3F19C046706DF2A5B15A406313F472333F19C0B271B32EA4B15A40F31BCB60313F19C0B9DB9A19A2B15A40151A8865333F19C09C9A159BA0B15A40B82638503B3F19C06D7B71989EB15A403D7FDAA84E3F19C07A185A9D9CB15A4099A9FF626C3F19C0A5411BCA9AB15A4052E45AFE8D3F19C0FF5E0A0F9AB15A4042075DC2A13F19C0000000A099B15A406365A16AAB3F19C0000000A099B15A40A47BEDAF4B3E19C099D87C5C9BB15A408E8DE5023C3E19C0D3742CA59DB15A40ACB47BA8233E19C0CC800E4E9FB15A40FCB3D59B073E19C0671426E79FB15A4063546353F83D19C090AADCFA9FB15A406CC4DD6AE73D19C0FCEDA1339FB15A406DC7D45DD93D19C0B5D14A6B9DB15A40D2B71677CD3D19C0000000A099B15A4043DBDD16C23D19C0000000A099B15A40A844D5AC0A3C19C01CBDD0129AB15A40DF162CD5053C19C0A5106D6C9BB15A406E35EB8CEF3B19C0C23D85129CB15A4023D2DB44D23B19C0B05CCA549CB15A40CCD47F31B63B19C05759805B9CB15A405BF33EE99F3B19C0BC523B689BB15A405A290472893B19C0C3B986199AB15A40B1225976773B19C0000000A099B15A4059C337A4713B19C0000000A099B15A40910181097E3919C0960BF038A0B15A40FACF9A1F7F3919C04E3CB198A2B15A401DB17158753919C01DCC8179A3B15A40409248916B3919C05352712DA4B15A400C40FE2D5C3919C0A090F870A4B15A40D45059034A3919C00514EAE9A3B15A40F1C7A30A353919C0E8D2646BA2B15A4003380719123919C0DAC46E449CB15A4038883144A93819C0D5AEAEAF9AB15A404AF89452863819C03ABF72CE99B15A4085B35BCB643819C03ABF72CE99B15A40A22AA6D24F3819C02207DB3E9AB15A40BEA1F0D93A3819C022ED35F39AB15A4004649E4B273819C0CB773AA1A1B15A40BC0276DABF3719C01D3FAFD3A3B15A40F5F00AE9953719C0EDCE7FB4A4B15A400DCBFA287E3719C0884B8E3BA5B15A4029424530693719C0884B8E3BA5B15A40699A66704A3719C0EDCE7FB4A4B15A40D6DA45E22F3719C01D3FAFD3A3B15A40421B2554153719C049CD68F59FB15A4066FBEB70CF3619C0F705F4C29DB15A402305604DAF3619C0A4B1ACEA9BB15A4095E29986973619C0000000A099B15A405E66F4028B3619C0000000A099B15A40000000609A1919C0	0.788599967956543	2026-06-09
455	89	0103000020E61000000100000013000000000000A099B15A406365A16AAB3F19C0AC35392199B15A40FCB44071B63F19C0FA4BE6B397B15A40B0F897EEBF3F19C060764F1E96B15A40DA63D817BF3F19C0FB8568BE94B15A409B447353B93F19C0A3CD716E93B15A40D6C97443AE3F19C0DF477F7992B15A40B6EE8BF09B3F19C068452FFE91B15A4039036DBC853F19C01B4CC3F091B15A40F18C6C9D6E3F19C098B2C2E391B15A40373234434F3F19C00FA1A58691B15A40E9A45247223F19C07A85AA3D91B15A407A06C36FF93E19C0F114CD5E91B15A40412D060FD33E19C0FD602A4792B15A403B191C25AF3E19C037FDD98F94B15A4067DDF588873E19C0777066AA96B15A40F95B4C7D6A3E19C08E08217B98B15A4075931804563E19C0000000A099B15A40A47BEDAF4B3E19C0000000A099B15A406365A16AAB3F19C0	0.8965999484062195	2026-06-09
456	89	0103000020E61000000100000016000000000000A099B15A4043DBDD16C23D19C0283D789299B15A4055794CEEC13D19C0C5F6A45D96B15A409F48E647B23D19C0DAAA24B28FB15A40B842B346983D19C003AB8F2C85B15A407ED98706733D19C02E8F352383B15A406E354646623D19C065389ECF80B15A40693E42284A3D19C08AA427767EB15A4034924E6E253D19C0E31D3B037EB15A40422F922C163D19C043F861CE7DB15A406D9DC948073D19C02B40CA3E7EB15A40784DFEDDF13C19C0A15687927FB15A40AAEBF593D63C19C0539CFE4781B15A40FE87AA4EBD3C19C04C60298183B15A40E6A9B3FFA63C19C0D3DE3BC585B15A40D6750360973C19C049F25CDF87B15A4098E60C7B903C19C018AA07718AB15A4022D8028C783C19C05650076891B15A4038E5C061583C19C0DE72F56393B15A4057B9ABB24A3C19C0DD6921B795B15A409D9B36E3343C19C0000000A099B15A40A844D5AC0A3C19C0000000A099B15A4043DBDD16C23D19C0	0.8965999484062195	2026-06-09
457	89	0103000020E61000000100000015000000000000A099B15A4059C337A4713B19C0CA0C65F297B15A40064F7C105D3B19C0B9066CBD95B15A4006685BCD3A3B19C0741E5F8C92B15A40FF6959AD023B19C057F77E5990B15A400F0D8B51D73A19C011853BBC8CB15A40A4B1ACEA9B3A19C0420F10278BB15A402EA3A2FB833A19C048A46DFC89B15A407F8C14257C3A19C055CB8C6D88B15A40753282D7783A19C0738BAF2C87B15A407FA5F3E1593A19C032B6C65686B15A40A7093609393A19C0F1C6383586B15A40D40AD3F71A3A19C0C1E3DBBB86B15A40CBE9FC25F33919C0F64F262488B15A4086263F98CA3919C0AD0DBA298AB15A40C1E10511A93919C0E8A969728CB15A40B07092E68F3919C0EDA584BB8EB15A40FACF9A1F7F3919C0D976DA1A91B15A40CDE7DCED7A3919C08301DFC897B15A407881EDBB7D3919C0000000A099B15A40910181097E3919C0000000A099B15A4059C337A4713B19C0	0.8965999484062195	2026-06-09
471	89	0103000020E61000000400000013000000000000A099B15A40000000A067E618C0000000A099B15A400000006034B318C0000000E0CCB45A400000006034B318C0000000E0CCB45A40000000A067E618C03B30F90E86B35A40000000A067E618C0BCC96FD1C9B35A4077DA1A118CE318C0C51B9947FEB35A403D258C0BACE018C0167EBACB0FB45A4057321180C9DF18C074FC61951CB45A407CBA151D24DF18C0D0436D1B46B45A40931804560EDD18C01581FB4B1CB45A406EC328081EDF18C0DA4E006A0FB45A4013C60556C4DF18C0605628D2FDB35A40A0658286A3E018C0FC896FCDC2B35A40CB93B5977EE318C0C6CCF401B7B35A4081E6183504E418C0F3188AE0A4B35A404AD1CABDC0E418C033D6485C91B35A40B9B53B5A8BE518C066DB4E317FB35A40000000A067E618C0000000A099B15A40000000A067E618C00F000000F8C264AA60B45A40B85A272EC7DB18C07B93F0CE6BB45A40BE9AA84A00DB18C0F4C1323674B45A40FF9600FC53DA18C03480B74082B45A40EBABAB02B5D818C00CDF0C488CB45A40A69DF58480D718C0BCED9D2C90B45A40291D514601D718C04F6DBAAF94B45A40DF3D9BB058D618C0578451FF8FB45A40291D514601D718C0656F29E78BB45A40E2CF4B2080D718C0A60D87A581B45A40EBABAB02B5D818C06B8203B573B45A40C19778F64BDA18C01CBC653D6BB45A40236B0DA5F6DA18C0998C199760B45A4003F7F2F1BFDB18C0D0436D1B46B45A40931804560EDD18C0F8C264AA60B45A40B85A272EC7DB18C00400000064C235EFCFB15A403A40FFE19ADA18C0AA2DD049CAB15A403CB775DC95DA18C0CBC05CE6CFB15A40E630A9EB9ADA18C064C235EFCFB15A403A40FFE19ADA18C0050000001A660D839EB45A40FA0AD28C45D318C015504DEE9CB45A406EC9607B1CD418C071C4FFC297B45A40CD508138B4D518C0FD97B55E9DB45A40E59D9ED21CD418C01A660D839EB45A40FA0AD28C45D318C0	0.6168000102043152	2026-06-09
472	89	0103000020E610000001000000050000000000006066AE5A40000000A033B318C00000006066AE5A4000000060008018C0000000A099B15A4000000060008018C0000000A099B15A40000000A033B318C00000006066AE5A40000000A033B318C0	0.9893999695777893	2026-06-09
473	89	0103000020E610000001000000370000000000006066AE5A4000000060008018C00000006066AE5A40000000A033B318C023CAA32255AC5A40000000A033B318C06919A9F754AC5A4022FC8BA031B318C0772FF7C951AC5A406C21C84109B318C055DB4DF04DAC5A40A06F0B96EAB218C0FE2B2B4D4AAC5A40AB92C83EC8B218C003E962D34AAC5A4056629E95B4B218C0C7681D554DAC5A40FCA9F1D24DB218C00281CEA44DAC5A40C32ADEC83CB218C0433C122F4FAC5A408BFD65F7E4B118C08272DBBE47AC5A40E0F3C308E1B118C0335019FF3EAC5A40E61F7D93A6B118C0C32ADEC83CAC5A40CA8B4CC0AFB118C01A5245F12AAC5A405ED6C4025FB118C044300E2E1DAC5A40A9DE1AD82AB118C0DAAD65321CAC5A40CB9E0436E7B018C0E2033BFE0BAC5A40DD274701A2B018C07D24253D0CAC5A40B952CF8250AE18C0D655815A0CAC5A400C5BB39597AC18C0D655815A0CAC5A40670E492D94AC18C09A99F4520CAC5A407160CD5C3BAC18C01650A8A70FAC5A405A4B0169FFAB18C0F0366F9C14AC5A40B96DDFA3FEAA18C0F7AC6BB41CAC5A400F81238106AB18C0EF02250516AC5A40397B67B455A918C009FEB7921DAC5A4041118B1876A818C00FD594641DAC5A40DB6FED4449A818C0F91400E319AC5A408735954561A718C0035B25581CAC5A40D72FD80DDBA618C009FEB7921DAC5A40C823B891B2A518C01BD47E6B27AC5A401FB935E9B6A418C014950D6B2AAC5A40540262122EA418C091B6F1272AAC5A40931CB0ABC9A318C01A4F04711EAC5A40605AD427B9A318C0325A475513AC5A40FFE9060ABCA318C013D6C6D809AC5A40E338F06AB9A318C0915F3FC406AC5A40537765170C9E18C0FA0E7EE200AC5A404E469561DC9D18C046787B1002AC5A40FE98D6A6B19D18C0406D54A703AC5A40D102B4AD669D18C0C1FD800706AC5A40F488D1730B9D18C04AB3791C06AC5A4050C8CEDBD89C18C068E6C93505AC5A4035423F53AF9B18C0D76CE525FFAB5A404E42E90B219718C0C91F0C3CF7AB5A40F41ABB44F59618C0F6D03E56F0AB5A40D6027B4CA49418C0810871E5ECAB5A403E5B07077B9318C003B34291EEAB5A40AA9A20EA3E9018C09D9FE238F0AB5A401B9C887E6D8D18C097C80567F0AB5A40E811A3E7168A18C087C5A86BEDAB5A407A51BB5F058818C09E077767EDAB5A4068E503A7E38618C014DBE0DCE5AB5A4000000060008018C00000006066AE5A4000000060008018C0	0.8381999731063843	2026-06-09
458	89	0103000020E61000000100000005010000000000A099B15A40000000609A1919C0000000A099B15A405E66F4028B3619C00539831A99B15A40088D052A883619C04D7BEF1497B15A40B159E48D823619C00F70F72892B15A4052EC0D63773619C0BC1BB05090B15A40D43ABBC6783619C03A71DEA48EB15A40B159E48D823619C06A6EE0698DB15A40E5AB2EF1913619C09ADE0F898CB15A409FE9807FA53619C026DAFA8E86B15A40DFE23CF7793719C052DBE10A83B15A4021DAD836D63719C04D52F41B81B15A40E281B7F6F43719C060819EBC7EB15A401A715C21073819C043CDEBE37CB15A40CAA7C7B60C3819C0D94DDF217BB15A401A715C21073819C0BC7F87FD79B15A403D52335AFD3719C087866AEF78B15A4087B13B93EC3719C05173A89578B15A404FC29668DA3719C09F3E027F78B15A4099219FA1C93719C0EC7C89C278B15A405AC86D45AC3719C03ED1D09A7AB15A40D978B0C56E3719C07DC2233B80B15A404A84A169E43619C0359A5C8C81B15A40D33BCBE2B43619C0CF166B1382B15A40173147EA983619C0CF166B1382B15A40ADBC89C67F3619C0E7CE02A381B15A40CED02E956D3619C000146DD880B15A401393DC065A3619C030849CF77FB15A40E04092A34A3619C060819EBC7EB15A40D539ABAA3C3619C043CDEBE37CB15A40F81A82E3323619C0D9C00C7C7BB15A404D817115303619C087866AEF78B15A4076CCD47F313619C03EF669CB6FB15A40DBA337DC473619C02A5F86B567B15A40CED02E956D3619C06E1805C163B15A408471265C7E3619C08147AF6161B15A4029A1AAF8753619C0FF9CDDB55FB15A4030F14751673619C042C9891B5CB15A402B86AB03203619C02515D7425AB15A40B53DD57CF03519C08682082758B15A403EF5FEF5C03519C003BE912F57B15A4079B0C56E9F3519C003BE912F57B15A40E08618AF793519C050FC187357B15A403B5684F6453519C0D3C08F6A58B15A4020DE29D31E3519C0F08EE78E59B15A408881AE7D013519C02588049D5AB15A40D2E0B6B6F03419C0F5FD2F325CB15A409F8E6C53E13419C047C5A4645EB15A40BB05B75ACC3419C0CE8536A561B15A40D94933CCBF3419C060C0DC3873B15A4001C864CCB83419C0B7836CB477B15A407E79B768B73419C0A4C7EF6D7AB15A40CD751A69A93419C00E47FC2F7CB15A409586753E973419C00EBA298A7CB15A40DFE57D77863419C0F178A40B7BB15A4036188FF74F3419C02B0CDB6072B15A4055DF54FF7B3319C06D776A8970B15A40191989754F3319C0F1BA7EC16EB15A40DABF5719323319C010C6F4296CB15A40BED474E2173319C04A6D985764B15A4003B00111E23219C080E552A662B15A4060668E9BD03219C063A4CD2761B15A401CFD7964BD3219C0814A4B9B60B15A40F4249F0DAF3219C0220093AF5FB15A4089563893803219C08E5DFD335EB15A40C921E2E6543219C0E3923E085CB15A40C1B057B3293219C0EF2C8BD35AB15A4002D6AA5D133219C02B7986BA59B15A409D71D014F03119C057D6917E56B15A40289B7285773119C01574D60256B15A408EFE3CB25E3119C0C8354FBF55B15A40D9D0CDFE403119C009980A3B56B15A40CB2B7C22F43019C063B25D4656B15A4059F38876BA3019C0BC5983F755B15A407D47E8C2A33019C0CEB0074955B15A40B0B211E3903019C0468B7D1354B15A401C806841833019C0D503E62153B15A40FA111A1C803019C04D51894652B15A404A682673873019C0B3614D6551B15A4000091E3A983019C09593F54050B15A40F3A89D06B13019C07FB61F3A4EB15A40FF999C35D33019C0808E45894CB15A40ABE001AFE03019C021020EA14AB15A4025A24E2FE73019C0528CE20B49B15A40158B845BE33019C0E77F03A447B15A40B3DDF3B2DC3019C0CA3E7E2546B15A40B3507CC6CF3019C0A782401D45B15A4087DB46A8BE3019C0A1AEFF8444B15A40BA4670C8AB3019C0CBA3761A44B15A4060E97C78963019C0BF547DF843B15A4038842A357B3019C0C5B5903644B15A40F51906E22B3019C060BF716344B15A401304D9FC093019C054E3A59B44B15A4020D7E143E42F19C018B14F0045B15A4009FCE1E7BF2F19C08FCAA88D45B15A40383D39549D2F19C0BE62B25D46B15A40663ED6427F2F19C0E70CD64947B15A401D386744692F19C0B70FD48448B15A403AAFB14B542F19C04C112A8249B15A406D1ADB6B412F19C033CCBF4C4AB15A40016663CA2C2F19C06952AF004BB15A4080FDC68D112F19C0F7F2F1BF4BB15A40749C363EEE2E19C0500D45CB4BB15A4025B9B2FAD92E19C0454B1E4F4BB15A40E24F9EC3C62E19C0394778D649B15A40A383E453B62E19C088EAF70E48B15A405A0AED41AD2E19C00C2E0C4746B15A40162E50F7A62E19C0FBF900EE43B15A40CF818A4FA62E19C07969D48D41B15A405A0AED41AD2E19C08CAF87403FB15A40DD05EF50B92E19C06308008E3DB15A40D6D52EB7C52E19C0956AFA473AB15A40FE3A81FAE02E19C0EF7618EE37B15A40ED3DA6FFF62E19C03EA76ACC35B15A400E396C11072F19C0CEE0EF1733B15A4080FDC68D112F19C0D67E219A2FB15A40622CD32F112F19C078B306EF2BB15A40A77BF88D0A2F19C033B4F0AB28B15A4094E7B0B1012F19C039D6202727B15A407279628CFE2E19C046FD3F9825B15A4041142752F52E19C0BFDDEDD522B15A408C039E6AE32E19C072045F8720B15A406F18BB33C92E19C06D7B71981EB15A404F907D35AC2E19C0B0CFF7AE1CB15A401CB1BBE58F2E19C0AB460AC01AB15A40399B8E006E2E19C0DB430C8519B15A40C8BC44AB492E19C094F36A2519B15A402A83B4102E2E19C08E05854119B15A400E98D1D9132E19C0D55526A119B15A406F5E413FF82D19C06AFB57561AB15A40A50925DDE02D19C0634FF16E1BB15A4021D15F43CB2D19C0B04225091DB15A40158DB5BFB32D19C06DEE9EF21EB15A40041C42959A2D19C0A2FEC41220B15A407FC39F3C872D19C0ED5B525A24B15A40027DC7951F2D19C08D92FC2D26B15A402A34B511F42C19C02294522B27B15A40D4731C89E12C19C098EF2AB528B15A40E1D39CBCC82C19C043BAE9E02AB15A40E27FE14B972C19C0D25A2CA02BB15A40EFDF617F7E2C19C0258799C72BB15A404AC9BC9F642C19C0D215116A2BB15A40279133034B2C19C04F96B5A82AB15A4073A087DA362C19C03974C46B28B15A40F627F1B9132C19C0112F997425B15A40DFBF7971E22B19C0830DF4F521B15A403188FEBFA02B19C0728E95F320B15A404DFF48C78B2B19C0256AB3FB1FB15A4028F796CD772B19C031467FC31FB15A4034E48EED6B2B19C07923F3C81FB15A4040D1860D602B19C0D2B0732E20B15A40108C2892542B19C06051B6ED20B15A40B5BBAC2E4C2B19C026906D7429B15A4072DEFFC7092B19C024534F302DB15A40ACB3B519022B19C0717731282EB15A4079D4F3C9E52A19C02F3D505D2FB15A40A7A2C222D02A19C076734C7130B15A40E1777874C82A19C0ED5BF7A031B15A40E1777874C82A19C038EA324635B15A4096A5E727E62A19C08E90813C3BB15A4054B76922222B19C0F882BB583DB15A408CA60E4D342B19C0C224A6553EB15A40ED33C2363D2B19C0FE987BED3EB15A400328A14F3F2B19C04B4A308B3FB15A40D63FE31D3B2B19C008837C1A41B15A406F0ED76A0F2B19C09D9E776341B15A406407F071012B19C00295963641B15A40EEA53A2EF42A19C06E066E9340B15A40BB53F0CAE42A19C015C440D73EB15A409461269BBC2A19C06F6E02C23DB15A40E35C797F722A19C0D57EC6E03CB15A403358CC63282A19C011CBC1C73BB15A40B9E4130DAD2919C017D34CF73AB15A405326906D742919C0D8930A7437B15A4089CD6CFC2E2919C032B7312C35B15A402BD615D8082919C06E90FFB833B15A40DCF29194F42819C0F834272F32B15A4020CF2EDFFA2819C0A66DB2FC2FB15A4091AD78341F2919C0CD727E2F2AB15A407E3E25427E2919C0D4388A6228B15A40F0E9A001AB2919C0109F2A9526B15A40F4FA93F8DC2919C0FF3971DE24B15A40803859B44A2A19C0F35DA51625B15A4041E03774692A19C0B2FBE99A24B15A40A7B79AD07F2A19C0E2F8EB5F23B15A405D589297902A19C0CCC28D4A20B15A40315AEC9BA02A19C0B5E21B0A1FB15A40BA85AE44A02A19C0F736A2201DB15A407A466CC19C2A19C08151932A1BB15A40F4EAD275972A19C0D56C2FB319B15A408296091A8E2A19C0056A317818B15A4059BE2EC37F2A19C0A103818417B15A40D902E7316F2A19C05AFB969416B15A4049C043AC592A19C0CBE7267B15B15A40F0D5D86F372A19C0F53B5E9214B15A40747D1F0E122A19C0F683150214B15A40E55A5947FA2919C0C1E61C3C13B15A40F3DAB639DF2919C08042E2C311B15A4043A04495AB2919C0817C64CE0EB15A40C2DCEEE53E2919C0E78C28ED0DB15A405EB1D018F72819C08E5BCCCF0DB15A403205C655C02819C01CB7F3580EB15A40519BDDFF6C2819C09FF4CF1D0EB15A40FD8A9015572819C005EE8A2A0DB15A40608EC305452819C077082D350CB15A409436B0B03B2819C0D8C0B1C208B15A401D458C8D2F2819C00E36D0D707B15A405FA7A2C2222819C05BD3179D07B15A409D4F7864072819C06DF6515708B15A40AD7F21F5E82719C0B4B684D709B15A40E34AE251CF2719C0DA70FD6005B15A400DECE703B82719C0063065E000B15A406252D735B52719C0AC0F351BF5B05A409E149CB0B32719C0E7EA7D99DEB05A40DE36F867AB2719C06EB99FF8D6B05A402C504134A92719C0270DDA50D6B05A40EEE9EA8EC52619C02D12C946D6B05A40EFE8DA72892619C06F4CAA11D5B05A400EA0DFF76F2619C02EE7525CD5B05A40BF9360BBC52519C0A8041FDECEB05A401C34057CC82519C0F64201DBC1B05A4079245E9ECE2519C03860FCD9B4B05A40DFC0E446912519C03A94A12AA6B05A4013B875374F2519C0DDA05115AEB05A40B5334C6DA92319C0B6CC3340B3B05A403B072A3E992219C0723E2B1FB8B05A404B8050CD9B2119C00537AD6FBBB05A4055078A69F02019C0CF62CED8BCB05A40663623DE952019C0395508F5BEB05A408A8164F0E61F19C01442075DC2B05A4038BD8BF7E31E19C0724408D9C3B05A40BBCC5598631E19C060A5CC17C5B05A40141B3DC8FC1D19C0A67C08AAC6B05A406EDFA3FE7A1D19C0478BD8CCC6B05A40B16197F26B1D19C0C436F3F5C6B05A403136BE405A1D19C075D88EF3C8B05A40E5A2B5FD861C19C0514F1F81BFB05A40FAC962AC801C19C0F6DAC765B7B05A401CE5057D8E1C19C076E3DD91B1B05A40BBE4C97F921C19C0553948E3ABB05A403F00A94D9C1C19C0983446EBA8B05A401542BDCFA71C19C04645F707A5B05A40B2CB01CCC61C19C0D0D2156CA3B05A403317B83CD61C19C072FE2614A2B05A40EC87D860E11C19C01CB4571F8FB05A40F30D3B42BC1C19C008BB174E88B05A4013020352AC1C19C0E772DE5A81B05A40AC7A5457991C19C0A3DB5C467BB05A4013C42FAB661C19C0846B49A272B05A40FF9B72E0301C19C00619B78773B05A407859B851091C19C018810C7874B05A4017AB178DC61B19C018810C7874B05A408ECEF9298E1B19C0424871E973B05A4051CE61084A1B19C0E359DD4573B05A40BBE35EAAE31A19C0FA6761AA74B05A40FC784375CE1A19C0D6D6998C74B05A40565E9786861A19C0DBEC592176B05A40DCB529C35D1A19C02F75EB9076B05A40D2736616FC1919C0F961293776B05A404537B176CA1919C0184780A075B05A40000000609A1919C0000000A099B15A40000000609A1919C0	0.8965999484062195	2026-06-09
459	89	0103000020E6100000020000000A000000000000E0CCB45A400000006066E618C0000000E0CCB45A40000000A0991919C0000000A099B15A40000000A0991919C0000000A099B15A400000006066E618C0398BB34B7FB35A400000006066E618C091A630A564B35A40562B137EA9E718C08599B67F65B35A40481B47ACC5E718C0175EEE386AB35A4055D1692794E718C0E7EB9C2C86B35A400000006066E618C0000000E0CCB45A400000006066E618C005000000EFC110DE43B35A400CCD751A69E918C04D28E9062FB35A401CBB9FAE49EA18C04AC5104A29B35A40648B492476EA18C08F1777282FB35A4033AF7EC74BEA18C0EFC110DE43B35A400CCD751A69E918C0	0.6326000094413757	2026-06-09
474	89	0103000020E6100000010000001C000000000000E0CCB45A4000000060008018C0000000E0CCB45A40000000A033B318C0000000A099B15A40000000A033B318C0000000A099B15A4000000060008018C0E409D63BC8B35A4000000060008018C02E88ED93C8B35A40B3486EA8738018C04CCC0E4CC9B35A40156E9E8FD78018C01643835EC9B35A40E3B2C00DE78018C05D31C802CBB35A40257090B52B8118C0AF12E280CCB35A40ECA2E8818F8118C0E481C822CDB35A40C7855EDACB8118C044E9C193CCB35A4057389380E28118C09E205624CBB35A4056C50A6DEF8118C0633CEF6BC9B35A4042DB2049FF8118C017010462C8B35A40F898FEDB1B8218C0049376FEC8B35A40D4EEFC474B8218C0A96CB30CCCB35A4068CEFA94638218C0A3A94313CDB35A4052729879BC8218C01267EA1AD2B35A400D761E70B88218C000CEE6CCD1B35A40C248D4B0848218C08E6B8D52D3B35A40B87EB042808218C0A51DED6ED4B35A404D07FC2B758218C0BD00FBE8D4B35A40ED09B7216B8218C0A5315A47D5B35A40161B4EF4548218C0E11E95ACD4B35A40EF5E494D168218C0888043A8D2B35A40E28222CCA38118C0575C35A1CEB35A4000000060008018C0000000E0CCB45A4000000060008018C0	0.962399959564209	2026-06-09
481	89	0103000020E610000001000000970000000000002033BB5A40000000A067E618C00000002033BB5A400000006034B318C06AFFDB3833BE5A400000006034B318C0A4A65D4C33BE5A4028D6A9F23DB318C0C8CD70033EBE5A40D82D02637DB318C0D3F9F02C41BE5A40AD50A4FB39B518C06877483140BE5A40096B63EC84B718C0CFA44DD53DBE5A406D382C0DFCB818C04609FA0B3DBE5A40E2AB1DC539BA18C0F3C81F0C3CBE5A401EFCC401F4BB18C0267156444DBE5A4037DE1D19ABBD18C0C8073D9B55BE5A40AB9509BFD4BF18C071581AF851BE5A40C0B0FCF9B6C018C09C6D6E4C4FBE5A402B8881AE7DC118C093C6681D55BE5A404609FA0B3DC218C0D17AF83251BE5A4034A2B437F8C218C086ADD9CA4BBE5A404983DBDAC2C318C0EC89AE0B3FBE5A40098B8A389DC418C0FA9CBB5D2FBE5A401EE0490B97C518C0E8DD585018BE5A4046D3D9C9E0C818C033C51C041DBE5A40ABD0402C9BC918C07A71E2AB1DBE5A40BFBB95253ACB18C0DF6A9DB81CBE5A40C2D9AD6532CC18C0F1845E7F12BE5A4062BB7B80EECB18C0E8F4BC1B0BBE5A405776C1E09ACB18C03B18B14F00BE5A40309DD66D50CB18C013B69F8CF1BD5A40BE2F2E5569CB18C05E6397A8DEBD5A40B88FDC9A74CB18C0950C0055DCBD5A4090696D1ADBCB18C0AE9CBD33DABD5A409BCB0D863ACC18C039EE940ED6BD5A40EFAEB321FFCC18C08EB0A888D3BD5A4043C70E2A71CD18C095D5743DD1BD5A40643A747ADECD18C01211FE45D0BD5A400FB8AE9811CE18C0F4C308E1D1BD5A400FD594641DCE18C0FEEF880AD5BD5A40F25D4A5D32CE18C02D26361FD7BD5A407B336ABE4ACE18C015CAC2D7D7BD5A404DA25EF069CE18C0C16F438CD7BD5A40081D740987CE18C0683EE76ED7BD5A40F17F4754A8CE18C032E36DA5D7BD5A40191F662FDBCE18C0376C5B94D9BD5A40A1116C5CFFCE18C05AF44E05DCBD5A40514CDE0033CF18C0BFD364C6DBBD5A408A05BEA25BCF18C02BA4FCA4DABD5A404B94BDA59CCF18C0431A1538D9BD5A40CD5A0A48FBCF18C0CB811E6ADBBD5A40FA5FAE450BD018C0FAB7CB7EDDBD5A401171732A19D018C053E9279CDDBD5A408352B4722FD018C0EE23B726DDBD5A4093E00D6954D018C0C5909C4CDCBD5A40C102983270D018C060E5D022DBBD5A4038BEF6CC92D018C0DE3AFF76D9BD5A40168A743FA7D018C0D9976C3CD8BD5A40A9BC1DE1B4D018C0DF6E490ED8BD5A401024EF1CCAD018C04A253CA1D7BD5A4026A94C3107D118C02635B401D8BD5A405F28603B18D118C073B8567BD8BD5A40971B0C7558D118C038BA4A77D7BD5A402B8881AE7DD118C00F27309DD6BD5A40CA51802898D118C07C45B75ED3BD5A409CA38E8EABD118C018B49080D1BD5A40800F5EBBB4D118C05AF10D85CFBD5A401F4DF564FED118C0DC813AE5D1BD5A4068942EFD4BD218C07097FDBAD3BD5A40A6D0798D5DD218C08C14CAC2D7BD5A40075E2D7766D218C03D433866D9BD5A40B267CF656AD218C0A208A9DBD9BD5A40F660527C7CD218C0ABAFAE0AD4BD5A406116DA39CDD218C0DC813AE5D1BD5A40D9D138D4EFD218C0DB19A6B6D4BD5A4055849B8C2AD318C091D10149D8BD5A40B0E595EB6DD318C06DAD2F12DABD5A407D5D86FF74D318C097749483D9BD5A40DD5ED218ADD318C04434BA83D8BD5A40325A475513D418C0D960E124CDBD5A40253CA1D79FD418C0990D32C9C8BD5A40471E882CD2D418C0EBFCDB65BFBD5A40F0315871AAD518C08D0E48C2BEBD5A4001FA7DFFE6D518C0DE921CB0ABBD5A4037C7B94DB8D718C0DE228B8FAABD5A4097E1E423CED718C00C789961A3BD5A4025CFF57D38D818C04FCFBBB1A0BD5A403410CB660ED918C07711A62897BD5A408FAB915D69D918C04D13B69F8CBD5A40C8258E3C10D918C03196E99788BD5A407978CF81E5D818C092205C0185BD5A40FBAD9D2809D918C07EFCA5457DBD5A403410CB660ED918C0C3BB5CC477BD5A40FBAD9D2809D918C09351651877BD5A405649641F64D918C0DECA129D65BD5A408FAB915D69D918C09701672959BD5A40F209D9791BDB18C0E49EAEEE58BD5A40E694809884DB18C0925ED4EE57BD5A40732CEFAA07DC18C04BCCB39256BD5A402E3D9AEAC9DC18C068CBB91457BD5A409EB4705985DD18C0B66801DA56BD5A40A31F0DA7CCDD18C09AEB34D252BD5A40F2D1E28C61DE18C0EFAD484C50BD5A40A19DD32CD0DE18C02C62D8614CBD5A40DF6A9DB81CDF18C08124ECDB49BD5A40DA0418963FDF18C059130B7C45BD5A40E5D5390664DF18C0BA69334E43BD5A4056B77A4E7ADF18C0FC8C0B0742BD5A40D3D85E0B7ADF18C09F20B1DD3DBD5A40DF35E84B6FDF18C06C95607138BD5A40239EEC6646DF18C0B5C35F9335BD5A40E561A1D634DF18C0151A886533BD5A401EFE9AAC51DF18C05DFA97A432BD5A40B76114048FDF18C0B745990D32BD5A403F8EE6C8CADF18C0361D01DC2CBD5A408FC70C54C6DF18C08F17D2E121BD5A40287D21E4BCDF18C05AF0A2AF20BD5A4000C63368E8DF18C09D47C5FF1DBD5A404F2157EA59E018C039B69E211CBD5A401B649291B3E018C0ADF6B0170ABD5A40DDED7A698AE018C0ADA580B4FFBC5A408D7A884677E018C00C74ED0BE8BC5A405587DC0C37E018C007B7B585E7BC5A403370404B57E018C0FDBE7FF3E2BC5A4082A966D652E018C02499D53BDCBC5A4054A9D903ADE018C06C5F402FDCBC5A406B9DB81CAFE018C083A10E2BDCBC5A40F3380CE6AFE018C0E98024ECDBBC5A405F402FDCB9E018C01805C1E3DBBC5A40E8DB82A5BAE018C0F6622827DABC5A4087191A4F04E118C08BFA2477D8BC5A4059A5F44C2FE118C0360186E5CFBC5A40C53D963E74E118C049BA66F2CDBC5A408B321B6492E118C0399D64ABCBBC5A405D328E91ECE118C01BB80375CABC5A40522CB7B41AE218C0A5BBEB6CC8BC5A409B73F04C68E218C07094BC3AC7BC5A4073BC02D193E218C03DBB7CEBC3BC5A40A583F57F0EE318C0CDAFE600C1BC5A401DCBBBEA01E318C027158DB5BFBC5A4000AB23473AE318C0A5846055BDBC5A40E90DF7915BE318C0ADC3D155BABC5A4055BE672442E318C012A3E716BABC5A40EE9579ABAEE318C0C51F459DB9BC5A40384C3448C1E318C0B3B45373B9BC5A40F949B54FC7E318C03C84F1D3B8BC5A4087DC0C37E0E318C013D731AEB8BC5A4049DA8D3EE6E318C0A27DACE0B7BC5A402C80290307E418C025766D6FB7BC5A407079AC1919E418C0D926158DB5BC5A40815EB87361E418C01CB28174B1BC5A40365B79C9FFE418C02AE27492ADBC5A401283C0CAA1E518C07444BE4BA9BC5A40DECA129D65E618C075783340A9BC5A40000000A067E618C00000002033BB5A40000000A067E618C0	0.8939999938011169	2026-06-09
482	89	0103000020E61000000100000005000000000000C0CCB45A40000000A067E618C0000000C0CCB45A400000006034B318C00000000000B85A400000006034B318C00000000000B85A40000000A067E618C0000000C0CCB45A40000000A067E618C0	0.5547999739646912	2026-06-09
483	89	0103000020E610000001000000050000000000000000B85A40000000A033B318C00000000000B85A4000000060008018C00000004033BB5A4000000060008018C00000004033BB5A40000000A033B318C00000000000B85A40000000A033B318C0	0.9495999813079834	2026-06-09
460	89	0103000020E610000001000000F1000000000000A099B15A400000006066E618C0000000A099B15A40000000A0991919C00DBF269E75B05A40000000A0991919C01DF68C8E75B05A408A123EA5941919C042A4953174B05A40A8887890431919C07214C55073B05A40053EF5FEF51819C0D85537CD71B05A4000BA79F4D01819C05C3D27BD6FB05A40646E089FF71819C0A13028D368B05A4010B8640BF71819C0A9EB9ADA63B05A4037A6272CF11819C0583E26AD53B05A4092031B7C061919C00E1B1B704CB05A4026A94C31071919C0E107E75347B05A40AF44A0FA071919C0B5CCD88640B05A4048179B560A1919C0FF28458630B05A40F69DBA4D131919C09B7DD41522B05A40349D42531B1919C0BDB7335D19B05A4003E55BC41C1919C0658FABEC16B05A4051B4BCBC4A1819C02ABC15D316B05A4033F389E18F1719C06605758016B05A40028640892A1719C0663387A416B05A40507E9C7AEE1619C0B343FCC316B05A40CDB051D66F1619C08647D1B911B05A4007681140201619C08F64A07C0BB05A4077476BB1801619C05644F23A07B05A4068695D59581619C04D486B0C3AB05A405D9A6C4D041319C060A527D137B05A40AD293520E71219C09E42AED433B05A40498B8E3FAC1219C017128B732FB05A40A5CD829A6B1219C0A2BCEA5C2CB05A40FD8F02FA331219C02B757FAB2BB05A4012D08E650B1219C0EAF81EE42BB05A40E819564C001119C0281884A831B05A40556EFD4F591019C024ACD73E2EB05A4034FF9E0E1A1019C08ABC9B5D2DB05A400DD30847DA0F19C0687FFB9529B05A403DB9A640660F19C0980634C728B05A40B1B9B42B3E0F19C027AA12C028B05A4088179F5D190F19C0745BC75D29B05A40CE4CD5E2F80E19C09D7818A42AB05A40FC6D4F90D80E19C07012393330B05A402478E860A20E19C08104C58F31B05A405E4D9EB29A0E19C0E0A7058A33B05A40037D224F920E19C09765998F35B05A403065E080960E19C0027278F736B05A4009E7AE809D0E19C0376B950538B05A4074417DCB9C0E19C012BD8C6239B05A40AE16331D950E19C0670FB40243B05A406272593B400E19C01EA2766451B05A4060B6F86FB90D19C0E2444F255EB05A4055BFD2F9F00C19C01B7FA2B261B05A407E40FBECDB0C19C04F3BA17C66B05A4069DF81A6CA0C19C011B287516BB05A4072DF6A9DB80C19C0C9BD0A3A6BB05A4090060143A00C19C07CDE43786AB05A40CF7701405F0C19C0364FBF5568B05A404BFD61F0D50B19C015EDE01662B05A403F671C34050C19C0FDE6B45D57B05A40F8DB43673E0C19C011EE844D53B05A40521C51EB470C19C01791724147B05A4022F4D83B480C19C05A89D40F45B05A40E3D17C84500C19C09977E62F3EB05A403EA6FFF6860C19C0DCE511923BB05A4080D250A3900C19C0C598AA6A38B05A4092996615910C19C0AF4B434335B05A40593739D78B0C19C07595496826B05A40E074DC3A490C19C0D06ADCF618B05A40F98788F60C0C19C0357BA01518B05A409A1AB2CB010C19C041576CDD17B05A4094B0259AF60B19C0CF392E9919B05A40CE4AFF379B0B19C02321808A19B05A4068E32DFC850B19C0171A3ED818B05A40AD156D8E730B19C0BF05234017B05A404161F5EC5E0B19C0E1455F411AB05A407DA7131AD20A19C0DEAF5D352AB05A405E6F511CF60919C0F0A1E9912BB05A409BA49EAAE70919C018607A562DB05A4085402E71E40919C02F8507CD2EB05A40F2D7BF46ED0919C081E7830A33B05A406C0C95DAE60919C096766A2E37B05A402170C916EE0919C0C20765D03FB05A4013D38558FD0919C005DB2D6E48B05A40A572C9271A0A19C0D525E31849B05A406B73AD07DD0719C09191FD3D42B05A408D1656E01A0619C0CC61F71D43B05A4050BC1468C10519C006291D5146B05A40781C5080720519C005B0B78347B05A40EB41F79B3F0419C0E1CDBF023DB05A400DFE7E315B0219C0BBE5345541B05A40FAD0AA3BBB0119C06E90FFB833B05A40D67C4BEFD10119C0473767E92FB05A40ABD4473BC90119C084BA48A12CB05A4020DC5328C10119C0D27135B22BB05A40040E57BDB20119C0EACDA8F92AB05A40A1061DBE960119C0D996016729B05A405BCDDF29890119C0339DE79928B05A40BE439B2D6A0119C09249FC4028B05A40F9FE61A6480119C07505DB8827B05A40D2F3B8B9420119C087BB1F5C26B05A4057128F7A3E0119C0DCD9571E24B05A40FD97B55E1D0119C09C6C037720B05A400F5FCBD01D0119C06129DC3C1FB05A40EF9FB82DDB0019C0EA268CC11EB05A402C7A4C497B0019C0028063CF1EB05A40D2A4B9BA080019C00E87003B12B05A40EF022505160019C04E8FB7A60AB05A4087B542A21A0019C0253E7782FDAF5A40D41E40D01B0019C0AD742D10F3AF5A40B52D6FB31D0019C06FDCBD37E1AF5A40DB183BE1250019C0B05582C5E1AF5A405D63E135F9FF18C0AA1FE571E2AF5A40D960E124CDFF18C05061B6AEE2AF5A401A4C68379FFF18C0632B685AE2AF5A407705ECB47FFF18C04501ECEDE0AF5A409D7C1FB358FF18C0647CF376DFAF5A408341881A3BFF18C0AD4B3217DDAF5A400F03A7881DFF18C05BE37D66DAAF5A40A2BEC0070AFF18C00376DABFD7AF5A400CBFE5FBF3FE18C0CF54E300D5AF5A405211024DDFFE18C0B2A03028D3AF5A4064F1F67BBDFE18C0296101A7D2AF5A40A17CE65196FE18C0B832F2C3D2AF5A409791D50858FE18C04D3A8034D2AF5A408E53196B24FE18C0F5F75278D0AF5A4074C1CF6EE3FD18C01F6393A1CFAF5A40B19F6A99B1FD18C0D9D6AAB8CCAF5A402446CF2D74FD18C045060319CBAF5A4096B377465BFD18C098497952CBAF5A40D4CACEEC04FD18C0F8B072C3CAAF5A402A4C84B295FC18C0DA69B5D1CAAF5A407A64BD6257FC18C0EB8CEF8BCBAF5A4067E84427F0FB18C092B7B7B6CBAF5A409C35785F95FB18C0D38F3CC6CBAF5A400328A14F3FFB18C05682C5E1CCAF5A409C5E189FB8FA18C07FB61F3ACEAF5A407005B93077FA18C05B67D718CFAF5A409DAFA3BB35FA18C0664007A7CFAF5A40CED60B4FF9F918C0664007A7CFAF5A40B7A4598FB1F918C0C0FE356ACFAF5A40546353F87DF918C0A7B9CB34D0AF5A4048A8195245F918C012989878D1AF5A40EFDD8BD420F918C0A094FF7FD2AF5A40A18A76700BF918C0B8A8BB57D2AF5A402A7C6C81F3F818C047D6D0BCD2AF5A409BC937DBDCF818C0884F954AD3AF5A4087DB46A8BEF818C0881EE7ECD3AF5A40871403249AF818C0B183EFA2D4AF5A40E7F05A536AF818C0B1524145D5AF5A40D67FE72851F818C068B4B002D7AF5A409D537F7335F818C044937A05D8AF5A40D698C6E52EF818C0EBD44B42D8AF5A40FC0FFAE307F818C0CB3967FADBAF5A401F436C55B7F718C0D9D1938DE2AF5A4041A9AC5C5EF718C0D27B197BE5AF5A407197587446F718C02B099AE0E5AF5A40A87FFF9C38F718C0BA36AF45E6AF5A40D76DABB420F718C0EF74E789E7AF5A40E69A5D5210F718C0BEEA121FE9AF5A400F8F0E59EEF618C0A6A5A8E9E9AF5A40C86EB081BEF618C0F459F9C0E9AF5A4062B02CE285F618C0716770A5E8AF5A4063E9E85D61F618C013F5DD08E6AF5A4007A2DDD737F618C0B5824B6CE3AF5A40792865ADFCF518C07526C863E1AF5A40449550B0B5F518C05E32E94ADFAF5A40EF80FCB671F518C0B927FEDEDCAF5A409A2FE53224F518C0B33CB434DCAF5A40E7CEA7E90EF518C008477F1ED9AF5A40A03AB1E2AFF418C0571BADB4D6AF5A401CC418A254F418C0462CBD91D4AF5A408B06DFEAEFF318C077E73F5AD2AF5A40A4C2D84290F318C0B37BF2B0D0AF5A40380A5A924DF318C0968224A2CEAF5A405734E72A27F318C015B07845CBAF5A404A40F10813F318C081DFD0A5C9AF5A409CD5A7C1D9F218C099243BDBC8AF5A4093EA96789BF218C0D5873FD4C7AF5A4094AFBAC447F218C07CFABE6EC7AF5A400C303DAB16F218C035A781D5C7AF5A4010392284ECF118C05960D916AFAF5A404E3CB19822F218C0DE1C531CACAF5A40589643E625F218C087CF8C34A7AF5A404A2FC5B01EF218C0EADED4519FAF5A404FB2309F07F218C06C2AE67BA1AF5A40E29AF16C45F118C0651FBF12A3AF5A40EDD286C3D2F018C08E39741FA5AF5A40F7EA3E5B62F018C0B608D682A8AF5A40FC28D9A0E5EF18C02015B5EAA9AF5A4047510C35AFEF18C0252B757FABAF5A40A136604667EF18C0DE921CB0ABAF5A40597F958D18EF18C019C5724BABAF5A40B5A4A31CCCEE18C002582E65AAAF5A40A6FC5A4D8DEE18C0F1AABD3EA9AF5A40B11B11E73CEE18C063867C86A6AF5A4029EF3E2201EE18C0E6087481A6AF5A403C9C65BBE7ED18C03A63F3CCA6AF5A40A57CADF0D3ED18C0F13A2C1EA8AF5A408871EDFABBED18C0F51906E2ABAF5A40E5D4CE30B5ED18C095ACD4FDADAF5A40DEBDED539FED18C04DB21F73AFAF5A40D399208F85ED18C02E4E21FCB0AF5A40CFDFDFFB76ED18C0F80379D1B2AF5A40CD823FB26FED18C04A552470B5AF5A4054E1CFF066ED18C097900F7AB6AF5A4072C284D1ACEC18C0DEAF027CB7AF5A409DF2E84658EC18C04A6650C8A9AF5A4078CD508138EC18C009B99C5C9DAF5A407A26EABB11EC18C04FB8B29FA0AF5A407CB031546AEB18C0A1269FC3A1AF5A40FB0DC97F37EB18C0D048DFFFA2AF5A40F47F588000EB18C0F2B62D25A6AF5A404CB159E48DEA18C035F74663A3AF5A40A53D14BB6CEA18C0A920F58D9EAF5A404B00FE2955EA18C052746E249AAF5A409E094D124BEA18C03592A92798AF5A406704C01D4DEA18C01321BFC895AF5A4008D1B58A59EA18C06711E56693AF5A40933C32B154EA18C098C9CBF591AF5A4052499D8026EA18C008AD872F93AF5A4077B8C260A3E918C0FCCD1F2E94AF5A40E70187AB5EE918C01F03C30394AF5A4013DF3FCC14E918C045FFBA8990AF5A40E69FCF36EDE818C08E44C3BD8DAF5A401041D5E8D5E818C0838B70EE8AAF5A4017917241C7E818C0C10E52A687AF5A4071242B1AC6E818C0FE63213A84AF5A40B6AD1C10D7E818C02EBD474783AF5A40C4A40925DDE818C082FD7C0077AF5A406F09658632E918C0221ADD416CAF5A40E7FD7F9C30E918C074AD629662AF5A40AEEEFDB220E918C05C0CD41863AF5A404981053065E818C03200547163AF5A403C670B08ADE718C01F47736465AF5A4034304D6C99E718C08F7DDAF25BAF5A407B4CA4349BE718C05CBBA3B558AF5A403E7AC37DE4E618C0AB538AC253AF5A405F549CB4BAE618C06556EF703BAF5A40223C35F2D4E618C0BABF7ADC37AF5A404183A856BAE618C0BA9404F236AF5A403F58C6866EE618C06A3A64D336AF5A400000006066E618C0000000A099B15A400000006066E618C0	0.6283999681472778	2026-06-09
461	89	0103000020E610000001000000760000000000006066AE5A400000006034B318C00000006066AE5A40F85678CEB8E518C02426A8E15BAE5A40A6B5696CAFE518C06490BB0853AE5A40FCABC77DABE518C06C21C84109AE5A403A747ADE8DE518C0A52F849CF7AD5A404C8E3BA583E518C03A799109F8AD5A4015E3FC4D28E418C0041E1840F8AD5A404F75C8CD70E318C02ECBD765F8AD5A407218CC5F21E318C02237C30DF8AD5A40D845D1031FE318C0E886A6ECF4AD5A40BC77D49810E318C07E384888F2AD5A400DC4B29943E218C048C32973F3AD5A40581EA4A7C8E118C0E2AFC91AF5AD5A401024EF1CCAE018C082734694F6AD5A40D7135D177EE018C0D46531B1F9AD5A401D5A643BDFDF18C05CE7DF2EFBAD5A4084BC1E4C8ADF18C05B99F04BFDAD5A401310937021DF18C069FD2D01F8AD5A40A7EB89AE0BDF18C08716D9CEF7AD5A40744694F606DF18C0AA9ECC3FFAAD5A40A7C98CB795DE18C0E9F17B9BFEAD5A40AEF02E17F1DD18C02AE109BDFEAD5A400490DAC4C9DD18C00CAEB9A3FFAD5A40B03DB32440DD18C065C5707500AE5A400BB77C2425DD18C0CDBFA78306AE5A40E6006663CADC18C0E36BCF2C09AE5A403BFF76D9AFDB18C00B9755D80CAE5A4047AE9B525EDB18C0B0AF75A911AE5A40309DD66D50DB18C051F52B9D0FAE5A40EC12D55B03DB18C02B357BA015AE5A40601F9DBAF2D918C0D36BB3B112AE5A40221807978ED918C020D5B0DF13AE5A402EC72B103DD918C094895B0531AE5A40FB3E1C2444D918C04A5E9D6340AE5A40616C21C841D918C0EAB12D034EAE5A409B41D7193AD918C0191C25AF4EAE5A4041DBC58F8CD818C06CA4B61E4FAE5A40319F07D220D818C04E12A68350AE5A40EC2C1FEE8FD418C0C00413245BAE5A40251FBB0B94D418C0001C7BF65CAE5A40135BE619A0D118C0D40E7F4D56AE5A405CB3F0506FD118C003232F6B62AE5A400135B56CADCF18C06902452C62AE5A4013B9E00CFECE18C0C51D6FF25BAE5A4090662C9ACECE18C00B7C45B75EAE5A402B1213D4F0CD18C0C4B2994352AE5A406687F8872DCD18C00B42791F47AE5A40FAEE5696E8CC18C07FA2B2614DAE5A40FB230C0396CC18C0A52E19C748AE5A404B92E7FA3ECC18C0A0A52BD846AE5A40E60819C8B3CB18C087156EF948AE5A4064EB19C231CB18C0BD8DCD8E54AE5A4043739D465ACA18C0B77F65A549AE5A406B990CC7F3C918C03F52448655AE5A4018080264E8C818C0C8073D9B55AE5A40A1A3552DE9C818C0199293895BAE5A4025CFF57D38C818C0C39B35785FAE5A40A9DDAF027CC718C086014BAE62AE5A40BB270F0BB5C618C08B53AD8559AE5A403D2B69C537C418C09869FB5756AE5A4000E5EFDE51C318C0809C306134AE5A4043C6A354C2C318C0E19BA6CF0EAE5A4020459DB987C418C00F4757E9EEAD5A401FDB32E02CC518C09BAF928FDDAD5A407A37161406C518C09EA4AFD6BFAD5A4092CF2B9E7AC418C0BB2A508BC1AD5A40828E56B5A4C318C0C6BE64E3C1AD5A40D40FEA2285C218C0E4A3C519C3AD5A409B90D61874C218C0C53C2B69C5AD5A40469A780778C218C0D3BD4EEACBAD5A404548DDCEBEC218C00C06D7DCD1AD5A40344B02D4D4C218C0AFD007CBD8AD5A4045D4449F8FC218C045B9347EE1AD5A409B3924B550C218C0D175E107E7AD5A402A70B20DDCC118C0A06F0B96EAAD5A4009A69A594BC118C0B77D8FFAEBAD5A403D29931ADAC018C02F4D11E0F4AD5A40771211FE45C018C087191A4F04AE5A40FFCA4A9352C018C0F5F3A62215AE5A4034DAAA24B2BF18C08CDCD3D51DAE5A4045D7851F9CBF18C039D384ED27AE5A4079CE16105ABF18C0F69507E929AE5A40346612F582BF18C0ED0BE8853BAE5A40BDC282FB01BF18C0B7627FD93DAE5A406F675F7990BE18C0501BD5E940AE5A4037001B1021BE18C0EA58A5F44CAE5A401558005306BE18C09DD843FB58AE5A401AC39CA04DBE18C0A11342075DAE5A40D6A71C93C5BD18C0A704C4245CAE5A40AAD72D0263BD18C014200A664CAE5A4038BC202235BD18C0825BD2AC47AE5A40CDB7F41E1DBD18C0AFC623021FAE5A407F051F3988BC18C05A65A6B4FEAD5A4062122EE411BC18C00CE47E2CE9AD5A40E3A7716F7EBB18C062307F85CCAD5A4053927538BABA18C066A4DE53B9AD5A40EB596B836EBA18C0F3E49A0299AD5A4038F4160FEFB918C043FE99417CAD5A40D34D621058B918C0FD6838656EAD5A40B1A547533DB918C02C346B8459AD5A40DD611399B9B818C0AADF3B203FAD5A40AC634B4519B818C07E8CB96B09AD5A40992D5915E1B618C01D8EAED2DDAC5A4064B2B8FFC8B418C0E35295B6B8AC5A40DC4B1AA375B418C04963B48EAAAC5A4026FDBD141EB418C0C630276893AC5A406BB75D68AEB318C0EA002D0288AC5A40CF49EF1B5FB318C09D66817687AC5A40662FDB4E5BB318C07825C9737DAC5A406B9A779CA2B318C0763579CA6AAC5A40F357C85C19B418C0CEFBFF3861AC5A40CC96AC8A70B318C04359F8FA5AAC5A402D93E1783EB318C0074147AB5AAC5A40FA449E245DB318C0DEC7D11C59AC5A40DE9387855AB318C086CABF9657AC5A40F46A80D250B318C0B435C63255AC5A400000006034B318C00000006066AE5A400000006034B318C0	0.652999997138977	2026-06-09
480	89	0103000020E6100000010000005C0000000000006066AE5A40000000A0FF7F18C046A30EDCE5AB5A40000000A0FF7F18C0D45FAFB0E0AB5A407C597FF0467B18C0753DD175E1AB5A40DADE13909B7618C0823CBB7CEBAB5A4081046AD6BE7518C0F14A92E7FAAB5A405FCBD01D697518C02CBAF59A1EAC5A401036E103E07418C0A94C310741AC5A40AB8F2C05497418C0848252B472AC5A401E4A592B7F7318C07E198C1189AC5A402FD8B221A47318C0D87E32C687AC5A400303AD65D77218C0E0DA899290AC5A401587D805287218C094DC611399AC5A4044BC1A457B7118C07558E1968FAC5A40A417B5FB557018C00937195586AC5A405B61FA5E437018C0BD18CA8976AC5A406BEF5355687018C0778368AD68AC5A407D04FEF0F36F18C0CD936B0A64AC5A4079B130444E6F18C0F183F3A963AC5A40C9C859D8D36E18C012D89C8367AC5A4063B323D5776E18C08CF50D4C6EAC5A4070E998F38C6D18C0299831056BAC5A406687F8872D6D18C02B4B749659AC5A40111D0247026D18C08C4D2B8540AC5A4081B1BE81C96D18C03A75E5B33CAC5A40785F950B956F18C0E08442041CAC5A406DFDF49F356F18C0FE80070610AC5A402C47C8409E6D18C0ECFB709010AC5A402F336C94F56B18C0A13193A817AC5A40D5CC5A0A486B18C0D850C5E814AC5A40EC9B4539E26A18C09D2ADF3312AC5A4043E73576896A18C0EF02250516AC5A40F5BEF1B5676618C041C758B70BAC5A408B87F71C586618C0AE3E688709AC5A40E9972DFE5B6618C0B262B83A00AC5A405A63D009A16318C0520C906802AC5A40725298F7386318C0E0D8B3E732AC5A40F03499F1B66218C06B4AB20E47AC5A40F75B3B51126218C0A73E90BC73AC5A40FDC1C073EF6118C04435255987AC5A403A3DEFC6826218C0D4601A868FAC5A40906802452C6218C09561DC0DA2AC5A4000FDBE7FF36218C0F65FE7A6CDAC5A404CC631923D6218C0B459F5B9DAAC5A40A13028D3686218C0755AB741EDAC5A4079793A57946218C076DC9502F7AC5A409B90D618746218C0BEF6CC9200AD5A40DF4B8688406218C004F97E0F03AD5A409B5A11908A6218C02123A0C211AD5A406E179AEB346218C072FBE59315AD5A401286014BAE6218C0EEEE01BA2FAD5A40E5D2F885576218C091F3FE3F4EAD5A40E5D2F885576218C0488787307EAD5A40CEE33098BF6218C00BED9C6681AD5A40AB5D13D21A6318C0083A5AD592AD5A40E59D4319AA6218C0ED444948A4AD5A40EA03C93B876218C0DFA46950B4AD5A40041B7C06796218C0E49DE85FB7AD5A40B00A2F1C636218C0C358F0ECBCAD5A4043E21E4B1F6218C0EF062C14C4AD5A40291609B7C66118C026097888B5AD5A4044584398916018C0C03B9E3BE6AD5A40E6AA1ED5555E18C09C1A683EE7AD5A409994CCFB495E18C0178C005DEAAD5A40FFDAB05C255E18C0FA70DA9DFFAD5A402B48D85CDA5D18C0DE4FD72409AE5A4009089C5BD75E18C0F0598DDB1EAE5A40A5260BA9EC5D18C0BFC6E4C322AE5A40F18B01C8BF5D18C0F8A177CF26AE5A40FBE18C06955D18C0CF8A034331AE5A40EFF89BF5CE5D18C0F1F8516834AE5A4011F46107DF5D18C00C45701239AE5A406FCED25FF95D18C0B840DD9B3AAE5A40D85B6F40F05D18C0C949720A3CAE5A4013C19371E75D18C0E5C63E1240AE5A403C629923D05D18C0600729D343AE5A40C6DFF604895D18C024A424DA44AE5A40FF0758AB765D18C08DE612584AAE5A405D137761105D18C01B56A7B94BAE5A4088D459D2F65C18C00E46915A4DAE5A40384481E3D75C18C03D8276E24DAE5A40DDE396A0D05C18C0D679AFB552AE5A409C638A83955C18C0CF3DDAEE54AE5A4003E7316F7A5C18C05D09939856AE5A408A28DCE1655C18C097BFE72C58AE5A407D34E6BF515C18C019952FC35AAE5A40CC1363F4375C18C064C10EAD5FAE5A408B40AB82075C18C0AAC65C6361AE5A4046B7B98CF65B18C026B15A4F63AE5A403E80FBF0E25B18C06DB30CCC65AE5A408C3F9B66CB5B18C00000006066AE5A405E16D0FBC45B18C00000006066AE5A40000000A0FF7F18C0	0.9493999481201172	2026-06-09
462	89	0103000020E61000000100000069010000000000C0CCB45A4000000060CC4C19C00000000000B85A4000000060CC4C19C00000000000B85A40B2E7772C4D7219C0B96DDFA3FEB75A40575D876A4A7219C0B345D26EF4B75A40B27F9E060C7219C037610CF6F0B75A40C5B93C8CFF7119C02D7D433CEDB75A40C4D21B49DD7119C0BE2C921BEAB75A40F7393E5A9C7119C0B4AA251DE5B75A401FBC7669C37119C0179D2CB5DEB75A40EC1681B1BE7119C01A87FA5DD8B75A40757808E3A77119C0344B02D4D4B75A403CBF28417F7119C08350DEC7D1B75A4080272D5C567119C0103BF82ECAB75A40E3056C62DC7019C018271994C4B75A40FA85B24BAF7019C0C7269E58CCB75A40E9EE3A1BF26F19C040587CF9D3B75A40D1EB4FE2736F19C01CAD0F90D4B75A4043024697376F19C0FA10AF46D1B75A40972B723E2B6F19C08FBC186FD0B75A40BD6CE0B31A6F19C054A70359CFB75A405E6E8B8DD46E19C0AE090ED4CEB75A40B8C777CEBB6E19C04F779E78CEB75A40198EE733A06E19C0A2896654CFB75A402FD16A92696E19C0E76B3B12D4B75A4002E9AC60656E19C0A0CB8A97DDB75A40C9827813326E19C040EB2B59DFB75A4045F70725276E19C040D1860DE0B75A40A10040040B6E19C09919EC3CE0B75A40C317DCC5EA6D19C0C93EC8B2E0B75A40A2FF2FE8CE6D19C0EC9EE172E1B75A40AE3FD35CB86D19C0AF946588E3B75A40DC7D33D6A36D19C07F0A911DE5B75A40A8F11CDB7C6D19C0FB84FDE8E5B75A40A947BF22646D19C0E3E0D231E7B75A40EE79FEB4516D19C082700514EAB75A402D42B115346D19C0588FFB56EBB75A40276893C3276D19C01CCD36DCECB75A40B5A338471D6D19C045189A46EEB75A4043A21A40096D19C0C1F1C693EEB75A40EF91CD55F36C19C00237418AF0B75A40BB75487BCD6C19C0ADA23F34F3B75A401152B7B3AF6C19C065A88AA9F4B75A40E44C13B69F6C19C0124E0B5EF4B75A4094BC3AC7806C19C0E9D495CFF2B75A40B1169F02606C19C0390EBC5AEEB75A40FB75A73B4F6C19C09F55664AEBB75A400CAD4ECE506C19C0D6E429ABE9B75A4056293DD34B6C19C06150A6D1E4B75A4040FB9122326C19C074AAC65CE3B75A40AB1B94D5196C19C08C4B55DAE2B75A40B8CEBF5DF66B19C0A4BED133E2B75A409C397F6EC36B19C0E682E96AE1B75A40510C35AF8F6B19C099E83DDFE0B75A4063EC29DE6D6B19C07C348B06DFB75A4074B33F506E6B19C0835957BBDCB75A4005696BE9766B19C0F02F270DDAB75A4086D10726926B19C0912D2691D8B75A401E4E603AAD6B19C004F2DBC6D5B75A409E584C11856B19C06F63B323D5B75A401036864A6D6B19C0BCA13A67D5B75A40668286A3506B19C0F29A5775D6B75A408F5951DE226B19C03FD9DEB8D6B75A40CE3EEA0A116B19C0C832B385D6B75A40154152FAF86A19C0AB4D524FD5B75A40F325AF29EB6A19C040A03369D3B75A4084317D0ADB6A19C0A1979BB9D1B75A400F266A0EB56A19C054B8D4F7D0B75A4031CD74AF936A19C0F5E04966D0B75A40D7529B93726A19C0B33973B4CFB75A40372FF3C2426A19C02B5CA0EECDB75A408888F60C3C6A19C0D9942BBCCBB75A404F965AEF376A19C004AA7F10C9B75A406B47718E3A6A19C05F5D15A8C5B75A40AF230ED9406A19C0D8576831C2B75A40661AA8E7386A19C0CDE0945EC0B75A4032AB77B81D6A19C05C9E18A3BFB75A40816D0E21F86919C068BFFFA0BFB75A40F90A77D3D26919C05C566133C0B75A4088D68A36C76919C05001309EC1B75A406D455156C26919C001EB820BC3B75A403ECA2D52CD6919C065D531F8C5B75A40A4F732F6CA6919C0F9A5D997C7B75A403453B538BE6919C0A191BEFFC5B75A40011D41857E6919C0E45EAAE3C2B75A40DEAAEB504D6919C057714FFCBDB75A40734C16F71F6919C0D0B359F5B9B75A402E7079AC196919C0D20149D8B7B75A4023F609A0186919C09899E326B4B75A40397760A5276919C0D55E44DBB1B75A40B1FCF9B6606919C0AB3BBB21B2B75A40C1A73979916919C08DC98745B1B75A40A7AA7587B96919C0FF59F3E3AFB75A404F01D5E4CE6919C09B3BFA5FAEB75A40FAB7CB7EDD6919C085364AA8AAB75A404FE8F527F16919C022F312ADA6B75A40FA64202AE86919C077B8C260A3B75A40F07A1FFDE56919C0B452AD2AA0B75A40B6A970BA1B6A19C0D9767F619EB75A40E3587270446A19C0AFFA6D999DB75A405B87591E5A6A19C0B1D8CB5B9AB75A40281719D3026A19C0D644550298B75A408D5A0641EC6919C0CBE48A4196B75A4089A0C5ADDD6919C049C78B3B94B75A40F58A02D8DB6919C050768E5C92B75A409947FE60E06919C03F9EA74B90B75A40D6B61787E96919C08EA61F798CB75A40066FFE15E86919C0ADF6B0178AB75A406D14A3F8426A19C0D00B772E8CB75A407B455CA5606A19C08388D4B48BB75A4087FD9E58A76A19C0711DE38A8BB75A40D05DB7ADD26A19C054C2B8C08AB75A40EDA2433B026B19C00AE1873977B75A40739C80CB086C19C0E387EF6973B75A401D16B4DA0D6C19C0D2E0B6B670B75A4000130203526C19C03FE5982C6EB75A40DC15551A8C6C19C0F79FEBB163B75A403703B749A06C19C052CEBCC13CB75A401AAABDE36F6E19C0EB973E2A34B75A40C0B33D7AC36D19C0EF31A2FE44B75A40ED174740E06C19C06812ABF534B75A40FA27B858516B19C0B89B3B5519B75A4085888A27716C19C0C675429E13B75A40C20B6CDFED6B19C0A8565F5D15B75A40CEEF45C5496B19C01D339AA619B75A408D316601C96A19C0BD3B8D0F0EB75A40CAB447B9456A19C028CF616303B75A409C340D8AE66919C0BF6F3260FFB65A4081971936CA6A19C06607A6E4E6B65A40D6F8F13C5D6A19C057389380E2B65A409B5A11908A6A19C03C629923D0B65A4056945C0F706A19C013CCE20FD0B65A40918CE612586A19C02C0318E0CCB65A40752E7BC84A6A19C062BAB5F1CCB65A40AAB46A7CCB6919C0A16FC108D0B65A4045A6327B8F6919C02D4377A4D5B65A40EB71DF6A9D6819C0C8A87C19D6B65A40FCF61A272A6819C05E85949FD4B65A404FC29668DA6719C0B6B35483D5B65A40B5E78DEE7B6719C0E37ED12FDBB65A4017395508F56619C05150E50FE1B65A408AC2D3D0AB6619C0DFBF7971E2B65A40E7357689EA6519C097F03AD1E4B65A40AE5CB928C46519C00D631C6DE6B65A40AC866984236519C0549CB4BAE6B65A40C5573B8A736419C0B0DFB831E2B65A40BEE9A7493A6419C0B7BF69B0DFB65A40EDB36F93F66319C00727A25FDBB65A4041BCAE5FB06319C099B44E01D5B65A4053D55F0A6A6319C0888043A8D2B65A40965B5A0D896319C003B5183CCCB65A40C1351C3B4D6319C0DD67F052C5B65A40D87B968C086319C02219726CBDB65A40B5262724E36219C09436B0B0BBB65A406CDBE67C676219C0BE310400C7B65A40FD023054B46019C079382630C2B65A409E00D41E406019C08D6D0844BEB65A40537CD7FBE85F19C03C3FD69DB8B65A40C8B5A1629C5F19C0BA635694B7B65A4014A80F6E7C5F19C084ACB882B7B65A4062838593345F19C059805B1CBAB65A403845ECB8865E19C0E51C86A0B4B65A40DFEAEF5B635E19C00576EBEBAFB65A40CD599F724C5E19C01F0F7D77ABB65A40D12CBFC2385E19C02EB8D562A6B65A40E6536C71325E19C009D0A56E9DB65A4035C35785175E19C0679B1BD393B65A40DCF5D214015E19C026DD3B0F93B65A400052407F465E19C014BA015592B65A40F3823E479A5E19C0ADC266808BB65A406323B5F5785E19C0A131EE618AB65A4044DB3175575E19C0EF44FFBA89B65A405D0BC4FC265E19C05251AB9E82B65A40F27A30293E5E19C04C4CBCA882B65A40578451FF0F5E19C01664703983B65A40309287CFE75D19C075F6DF9483B65A40D6A71C93C55D19C02E782C1183B65A40DEDAD31FAB5D19C01859D70D80B65A402326F26E765D19C0A8D4DB557EB65A403C3DA539685D19C04C60843A76B65A40E1325D3E485D19C0E99216D371B65A40C52A943B225D19C092E057F66EB65A40B9556BBCCF5C19C07752BA4F69B65A40DD88DD2D7F5C19C0CBB50D4867B65A40D097DEFE5C5C19C0376C00DB66B65A408531D8C34D5C19C05AE322AD67B65A408DF0F620045C19C0181C6F3C69B65A40C71B4FBAE35B19C05EABF35E6BB65A406C2EED8ACF5B19C08DB38E4F6DB65A4078A3456C665B19C0B13621086BB65A4012E9C8DB5B5B19C04E7D207967B65A40247612B6445B19C0F080577064B65A404907358D375B19C0B3953C435DB65A4049032E7E095B19C0CC2B329559B65A4047C263E4D15A19C03BB5E9BE52B65A40BA68C878945A19C02A08799851B65A40467D923B6C5A19C04FA84CD64DB65A40FE06921C555A19C0B7DE252749B65A40104130A2485A19C0760CD98A47B65A40AF06280D355A19C06BAC0ECA45B65A40000979F30A5A19C07F40B15F41B65A40D2904CE2075A19C0BB6F6BC141B65A400FFC5EF9E25919C0121F8E6445B65A4026D35746D95919C01D684F1347B65A40B54BC054D85919C01BA1FA624AB65A407B93F0CEEB5919C0A3A6A7D94DB65A403524EEB1F45919C047A8BE9852B65A40D28C45D3D95919C0338AE59656B65A40E4198FADC25919C05C06F75E57B65A40B0E02307915919C0FE48111956B65A40763D2C2F545919C0477D48AE51B65A40040539831A5919C0A6EC99CA47B65A400AA58A3D0F5919C047544DB53BB65A403EDAEED4125919C090792E9D20B65A40E30973710A5919C0982B28B110B65A40FE0A3E72105919C0FD4F59A810B65A400E2A1664705919C029BE90C401B65A408F58E608745919C089844AB700B65A406BA1BF2BDD5819C0A6B4FE9600B65A40E48CBC07435819C007AC66E7FEB55A4091459A78075819C027A9A7EAF9B55A404688E1D9D45719C066B15E56F2B55A4093814DE7D45719C095826E2FE9B55A4068869EDED65719C0FF9CDDB5DFB55A400139BC7BDB5719C0A2E58A9CCFB55A4083B8173D5C5719C0D4C3865DCAB55A4074A14D69585719C063A93F0CBEB55A405F96766A2E5719C0E6E0E35DBFB55A40FE2EC786C95719C032755776C1B55A404FC69D77085819C043F1193FC3B55A40EF022505165819C0EFBE74A4C4B55A40BA3D528E135819C065E99ED0C6B55A40382971C2295819C0C2FC70EBC9B55A40EC70CF4E615819C00A1F0027CAB55A406C49FDAB7D5819C0C2FC70EBC9B55A40F6CE68AB925819C087E75BD5C8B55A4042E2C391AC5819C094F4D5FAC7B55A403BCCF2D0D25819C005B0B783C7B55A40DF8CF568055919C0CA9AA26DC6B55A405088258A355919C0476062E2C5B55A409198A0866F5919C0AC0ECA45C6B55A4099092BBA9A5919C03B53E8BCC6B55A40601B96ABC45919C094F4D5FAC7B55A40193D128A085A19C04CCFAA85C8B55A40122741C92E5A19C0F9A23D5EC8B55A4060D10891675A19C02F466E97C7B55A408F6D1970965A19C0766B990CC7B55A4031410DDFC25A19C09B8F6B43C5B55A40D9EE1EA0FB5A19C007D968EFC2B55A408D367D2C335B19C0D9D36938C0B55A40B9E57EE25B5B19C07CC0971DBDB55A401A5A530F875B19C006966DF1BAB55A40ED050BCCAF5B19C05AC8128CB9B55A40833FB26FDD5B19C072DF6A9DB8B55A40129F3BC1FE5B19C09C7B5924B7B55A4061490389375C19C0DF2B0483B5B55A408DF8043F605C19C0A3135333B5B55A4083F52455805C19C0DF2B0483B5B55A40696BE9769B5C19C0D21E8A5DB6B55A40F6DD639FB65C19C0F0A7C64BB7B55A40E4C4B2F4FC5C19C0CB83F414B9B55A40BD4A8803325D19C041AE1E41BBB55A400384C5973F5D19C0D461855BBEB55A408885B58C2F5D19C0D6A71C93C5B55A40C74D68ED115D19C06A5B83ADC8B55A402DEBFEB1105D19C01B9BC2EFCBB55A40DCAEE133235D19C0E966DA59CFB55A4096D05D12675D19C06094A0BFD0B55A40E954432CAC5D19C07D1DDDADD1B55A40BD00FBE8D45D19C00C62FB24D2B55A40F7FAA424355E19C0B3C00DE7D0B55A4023540493765E19C084B872F6CEB55A40DDCB22B9A15E19C0E5F791B6CCB55A4067518EB8B65E19C02239F471C8B55A4067518EB8B65E19C07E062F55C4B55A40EF3F8DD6AC5E19C0036A204CC0B55A40A32C32F0925E19C012A68350B9B55A4067F6D445655E19C0B592B135B6B55A404FA84CD64D5E19C01060EC18B2B55A40FE1076E50E5E19C09A35C2ECAFB55A40C0ED0912DB5D19C0DDE80885ADB55A406F5633219C5D19C049320631ABB55A40C4BB12375D5D19C08CE54CC9A8B55A400671D4C0455D19C04051D9B0A6B55A40AD6D8AC7455D19C08E0EFE34A4B55A40C4BB12375D5D19C06C13DD69A1B55A40DFF6A9CF7A5D19C002F62C639EB55A401840F850A25D19C00A945EE59AB55A4076C7BD54C75D19C077E0F7CA97B55A40062747A6E85D19C07E7B8D1395B55A40E7C2ED75F75D19C08516235C92B55A409686D0F7095E19C08D9AAF928FB55A408793EAF1315E19C0A6892DF38CB55A40A8380EBC5A5E19C0BA79F4D088B55A40078E1546C45E19C027C68DB685B55A4004FCBF8F0F5F19C0BDA5417683B55A403398D06E3E5F19C0D04D51E47FB55A40EDB94C4D825F19C04F1949CC7DB55A403B641415BB5F19C01B9FC9FE79B55A4060FD440A0A6019C00A206BFC78B55A4087D2286E266019C0F8109E1A79B55A40AB2A8FC93D6019C03948E3AB78B55A404BFB8B45786019C085D3DDD06FB55A403A8F2F46C96019C08FFCC1C073B55A402C6684B7076119C02D24607479B55A4047FFCBB5686119C0AD18AE0E80B55A407AFB73D1906119C0B153AC1A84B55A40F8FF71C2846119C02332ACE28DB55A403C2EAA45446119C0AF67BE3992B55A40A540B0F4EB6019C0433866D993B55A4098BF42E6CA6019C0BFC3A34396B55A4051D5A997846019C0642AB3F798B55A40AF1A95E5356019C069AD68739CB55A407DAD4B8DD05F19C03099CF5EA2B55A40F937C368B15F19C0FB912232ACB55A40A2009BBD7D5F19C0E204A6D3BAB55A407DAD4B8DD05F19C0691EC022BFB55A40CC2555DB4D6019C05D70067FBFB55A400FB56D18056119C0D4EE5701BEB55A40770A5E995C6119C0D235936FB6B55A40E5637781926219C0CD8FBFB4A8B55A4057C04EFBF76219C0B51666A19DB55A409A7D1EA33C6319C03FE603029DB55A40FF58880E816319C07F87A2409FB55A40C27AEDE3B26319C065A9F57EA3B55A40923EADA23F6419C023861DC6A4B55A404FDDA689886419C020B6F468AAB55A40EF8D2100386619C09DDA19A6B6B55A40A55C2BEB486719C0ADF71BEDB8B55A406A32E36DA56719C0BFD8D6AAB8B55A4034C1CB67D46719C037C7B94DB8B55A4036AFEAAC166819C0C1FEEBDCB4B55A4092FAFC416E6819C0A96BED7DAAB55A405DFC6D4F906819C09C525E2BA1B55A4079AD84EE926819C0B2683A3B99B55A401483763D876819C0C443183F8DB55A403B545392756819C002E7D6B587B55A408AE02472666819C0063065E080B55A404C3448C1536819C04A09C1AA7AB55A406902452C626819C00A68226C78B55A40B9B601E9AC6819C00FF10F5B7AB55A405187156EF96819C0E97E4E417EB55A401D90847D3B6919C02A3A92CB7FB55A406002B7EEE66919C0ADED37247FB55A40BEC3488A236A19C00D5531957EB55A40A4E36A64576A19C07DAEB6627FB55A407FAD0100B66A19C02A3A92CB7FB55A403198BF42E66A19C0179B560A81B55A40956C2BAC0A6B19C0BEA59C2F76B55A40288705AD766B19C071E316F373B55A409C189293896B19C02E3883BF5FB55A40632AFD84B36B19C0E2E5E95C51B55A4096CFF23CB86B19C0E1606F6248B55A40AD156D8E736B19C0BA9AE1AB42B55A400DD5DEF1376B19C08690F3FE3FB55A40BE175FB4C76B19C00400C79E3DB55A40B7B6F0BC546C19C0906802452CB55A4000E14389966C19C0B9AAECBB22B55A402E724F57776C19C0C64FE3DEFCB45A409413ED2AA46C19C0000000C0CCB45A40AB36D568A56C19C0000000C0CCB45A4000000060CC4C19C0	0.587399959564209	2026-06-09
484	89	0103000020E610000001000000320000000000002033BB5A40000000A033B318C00000002033BB5A4000000060008018C094538A2A07BE5A4000000060008018C044A852B307BE5A400475CAA31B8118C06D5512D907BE5A409D4CDC2A888118C07BBFD18E1BBE5A40DB317557768118C07BBFD18E1BBE5A403B35971B0C8518C03DBA111615BE5A4074B4AA251D8518C0E22021CA17BE5A404628B682A68518C057B5A4A31CBE5A4095D5743DD18518C044300E2E1DBE5A407C478D09318718C0B14E95EF19BE5A404298DBBDDC8718C02026E1421EBE5A40B2666490BB8818C0E8DD585018BE5A4084F23E8EE68818C002D9EBDD1FBE5A40967840D9948B18C09FC9FE791ABE5A4068041BD7BF8B18C057B5A4A31CBE5A40A053909F8D8C18C002D9EBDD1FBE5A40C7D79E59129018C0526342CC25BE5A40D2E28C614E9018C04302469737BE5A4048FC8A355C9418C06F826F9A3EBE5A401A886533879418C0938C9C853DBE5A4051BF0B5BB39518C04E2B85402EBE5A40683F5244869518C035CF11F92EBE5A407DEBC37AA39618C0A2ED98BA2BBE5A407BA35698BE9718C0E544BB0A29BE5A406D205D6C5A9918C0AA6395D233BE5A40BCCD1B27859918C0CCEB884336BE5A40E9D7D64FFF9918C04302469737BE5A40BB9D7DE5419A18C0E868554B3ABE5A40B96DDFA3FE9A18C0F277EFA831BE5A40DBA6785C549B18C0094FE8F527BE5A40F84F3750E09D18C0906802452CBE5A40F4BF5C8B16A018C00932022A1CBE5A406153E751F19F18C07380608E1EBE5A403145B9347EA118C0723271AB20BE5A40FA9B508880A318C077BB5E9A22BE5A4025EA059FE6A418C071E481C822BE5A40F3716DA818A718C06F4562821ABE5A40A27C410B09A818C050A73CBA11BE5A4030A017EE5CA818C037E0F3C308BE5A400D54C6BFCFA818C044C2F7FE06BE5A404BE7C3B304A918C033A5F5B704BE5A4053CC41D0D1AA18C05F5CAAD216BE5A405CC98E8D40AC18C07EC6850321BE5A406B44300E2EAD18C08D47A98427BE5A40DCBB067DE9AD18C08BDF14562ABE5A40C9E53FA4DFAE18C095F1EF332EBE5A400A4AD1CABDB018C0A9C3543733BE5A40000000A033B318C00000002033BB5A40000000A033B318C0	0.9175999760627747	2026-06-09
485	89	0103000020E61000000100000005000000000000C0CCB45A40000000A033B318C0000000C0CCB45A4000000060008018C00000000000B85A4000000060008018C00000000000B85A40000000A033B318C0000000C0CCB45A40000000A033B318C0	0.8319999575614929	2026-06-09
463	89	0103000020E610000001000000C90100000000000000B85A4000000060CC4C19C07A9D1392ECBA5A4000000060CC4C19C0DB87BCE5EABA5A4066BCADF4DA4C19C000AC8E1CE9BA5A40FAD170CADC4C19C0137F1475E6BA5A4077F35487DC4C19C082397AFCDEBA5A4066D993C0E64C19C095F25A09DDBA5A40E3FA777DE64C19C0AE8218E8DABA5A40B0726891ED4C19C04A0B9755D8BA5A40611C5C3AE64C19C0C860C5A9D6BA5A40725303CDE74C19C046D09849D4BA5A404F3C670B084D19C0051555BFD2BA5A4060730E9E094D19C05F605628D2BA5A40B0C91AF5104D19C05F7AFB73D1BA5A409E23F25D4A4D19C0008C67D0D0BA5A4087A3AB74774D19C0B3EE1F0BD1BA5A40543882548A4D19C04DDBBFB2D2BA5A40C05C8B16A04D19C02E8ECA4DD4BA5A40A3E5400FB54D19C0AB9509BFD4BA5A402041F163CC4D19C0BD1AA034D4BA5A40F20698F90E4E19C0CAE2FE23D3BA5A40800D8810574E19C09B92ACC3D1BA5A401A1A4F04714E19C081971936CABA5A40F7764B72C04E19C01897AAB4C5BA5A406E895C70064F19C02A1C412AC5BA5A40580C0D7A254F19C027ABD84ECABA5A40CFE04AD1254F19C084CF7B08CFBA5A40C059EFDC204F19C04B28D8DAD6BA5A40A115736B2D4F19C041F163CCDDBA5A40EA758BC0584F19C0FDAA121BE2BA5A4033D6A315844F19C0B5824B6CE3BA5A402C6D2700B54F19C098B4F347E2BA5A40139447DC085019C0936D8555E1BA5A40389D09F2585019C056BC9179E4BA5A40FA47DFA4695019C0840CE4D9E5BA5A408D7A8846775019C0363B527DE7BA5A407CD45FAFB05019C0EE409DF2E8BA5A40F94CF6CFD35019C04D49D6E1E8BA5A4048C0E8F2E65019C0546EA296E6BA5A40A3E716BA125119C042E90B21E7BA5A404225AE635C5119C0317E1AF7E6BA5A40D591239D815119C07C7F83F6EABA5A4002F390291F5219C017BA1281EABA5A40CEC133A1495219C0404D2D5BEBBA5A40075E2D77665219C0F0DFBC38F1BA5A4018265305A35219C090D78349F1BA5A4028D192C7D35219C0F6B6990AF1BA5A40C7BC8E38645319C0A35C1ABFF0BA5A4065170CAEB95319C08577B988EFBA5A40323D6189075419C0C2C3B46FEEBA5A4020EEEA55645419C069ACFD9DEDBA5A4036AD1402B95419C01D774A07EBBA5A406326512FF85419C05F9A22C0E9BA5A409CFC169D2C5519C0611C5C3AE6BA5A4068CBB914575519C081D1E5CDE1BA5A407F164B917C5519C000750305DEBA5A4062BCE6559D5519C09BC937DBDCBA5A4007431D56B85519C0B30B06D7DCBA5A40ACC95356D35519C04D2CF015DDBA5A40677E3507085619C066A208A9DBBA5A4000A8E2C62D5619C061FF756EDABA5A40EF586C938A5619C043E6CAA0DABA5A40D89E5912A05619C013622EA9DABA5A4033A9A10DC05619C0F0BF95ECD8BA5A402D6002B7EE5619C08066101FD8BA5A40A41B6151115719C073B8567BD8BA5A406B2DCC423B5719C06DAD2F12DABA5A4098C3EE3B865719C0BFD364C6DBBA5A40E61E12BEF75719C0EE3D5C72DCBA5A40971FB8CA135819C048A30227DBBA5A40855CA967415819C090696D1ADBBA5A40A1815836735819C09CFD8172DBBA5A4029CB10C7BA5819C0BA30D28BDABA5A40AC1DC539EA5819C021787C7BD7BA5A4029965B5A0D5919C088F37002D3BA5A40A60EF27A305919C07D7901F6D1BA5A402EE411DC485919C01D5723BBD2BA5A4000581D39D25919C02FC214E5D2BA5A4027F73B14055A19C07BF7C77BD5BA5A40C05AB56B425A19C0852348A5D8BA5A4026361FD7865A19C0E4F736FDD9BA5A40F3E7DB82A55A19C09C31CC09DABA5A4064E60297C75A19C04FAE2990D9BA5A40D6C743DFDD5A19C0E6797077D6BA5A40F8359204E15A19C0A01B9AB2D3BA5A407B319413ED5A19C0DE1D19ABCDBA5A40581AF8510D5B19C0750305DEC9BA5A40AD84EE92385B19C0D7DB662AC4BA5A40D5E940D6535B19C061C5A9D6C2BA5A400EA320787C5B19C02B6A300DC3BA5A4090D8EE1EA05B19C054FD4AE7C3BA5A408A8F4FC8CE5B19C0B9A81611C5BA5A407F6C921FF15B19C0ACC612D6C6BA5A40EBAD81AD125C19C01CD2A8C0C9BA5A401E537765175C19C055682096CDBA5A404B1E4FCB0F5C19C0302AA913D0BA5A404B3B35971B5C19C07C5F5CAAD2BA5A40450F7C0C565C19C005E10A28D4BA5A401D3BA8C4755C19C0B7291E17D5BA5A407845F0BF955C19C0FD87F4DBD7BA5A40E9D495CFF25C19C0A8DF85ADD9BA5A40558A1D8D435D19C04E7ADFF8DABA5A401096B1A19B5D19C0D158FB3BDBBA5A40C5538F34B85D19C061191BBAD9BA5A4059A31EA2D15D19C0B1524145D5BA5A40FEEF880AD55D19C04CC11A67D3BA5A40F37519FED35D19C00D54C6BFCFBA5A407BF486FBC85D19C0134548DDCEBA5A402CBB6070CD5D19C0CC988235CEBA5A40D107CBD8D05D19C073C982D3CCBA5A40D27E5AFBF15D19C0F709FBD1CBBA5A40EBB6FAA01D5E19C0EC6179A1CABA5A40013C58B55A5E19C06FA2F19FC9BA5A40AAF06778B35E19C015B07845CBBA5A4091138145D95E19C061CB8690CEBA5A40F0D709D4075F19C083989537D1BA5A40C27CC38E105F19C0521F926BD4BA5A4050F234AA1D5F19C039752F41D7BA5A4025A5EA68665F19C0F1AB2814D8BA5A409D4B7155D95F19C0B10D260FD5BA5A40CCADB59CF05F19C0C40B2252D3BA5A4029644227DF5F19C030FC96EFCFBA5A40CBA6B79AD05F19C0CA69F40FC7BA5A402A6B4029FF5F19C0E4E8E04FC3BA5A40B52D6FB31D6019C02FE1D05BBCBA5A4087D2286E266019C03DB83B6BB7BA5A409DFCCC0F126019C0B5503239B5BA5A40FC0FFAE3076019C01BC0B6D9B3BA5A4087D2286E266019C0FD193966B4BA5A407360DE88936019C0E6F4ABEFB2BA5A404ACBED03356119C00F43AB93B3BA5A407ADE8D05856119C04B8FA67AB2BA5A403760A120C26119C0CFA4A88EB0BA5A4097242AAFF06119C00B1C1A60B0BA5A403C759B26226219C0101835A9B2BA5A40C737CAB0406219C0C84E2E7CB3BA5A40F8A00CFA776219C0E2A2A4D1AEBA5A40E27668588C6219C0386E8CF8A9BA5A40E4D308A2936219C08E0EFE34A4BA5A40280351418F6219C07F3FEBD09FBA5A409D9BDB29C26219C0C63368E89FBA5A40B8301C19F56219C0FF250406A4BA5A40CFB5792D326319C093358F68A7BA5A4043F34AA3136319C01AC80E85AABA5A402DC9A601286319C0D7FA22A1ADBA5A40001FBC76696319C07143E790AFBA5A40D72E127FB96319C0812F3B7AB2BA5A40732CEFAA076419C0FD61F0D5B3BA5A406D36FBA82B6419C05D6A29C5B3BA5A405783E629616419C0F8BE5D9BB2BA5A40EC0F3922846419C0D6F14EF4AFBA5A40A2C90FA6726419C0BE6A65C2AFBA5A40D34A21904B6419C0EF6A03C1ADBA5A40CFC6A585266419C0D7E6B5C8ACBA5A40F06EC042416419C07324E18CABBA5A40C52176018A6419C03A07CF84A6BA5A403C17A133C46419C0A7F74322A3BA5A404B6540ACED6419C019BCF957A0BA5A40CB3D6E090A6519C085FFBE909FBA5A402A02F797386519C0C59DC195A2BA5A40063B0F385C6519C052D90B60A5BA5A408869DFDC5F6519C04402A150AABA5A402956B2086A6519C0C4133070AFBA5A4014330C699E6519C07B7203F4B1BA5A4075FE92F9EC6519C0267F411CB5BA5A400F0F61FC346619C09CBDD820B8BA5A40BF49D3A0686619C0657094BCBABA5A40EEAB17E87F6619C07CC0971DBDBA5A407CCBE6BBA56619C0699725F0BDBA5A40E31CD02DCF6619C03AA05B9EBDBA5A401F7013A4086719C0AC6411D4BABA5A40E831CA332F6719C0FC839213B7BA5A40DD47C9062D6719C03F26080DB3BA5A407F349C32376719C0F30AFAC1AFBA5A4073F4F8BD4D6719C053D1B3B4AEBA5A403DBDAD4F946719C06026E549ADBA5A40CADC7C23BA6719C074A61A07A8BA5A401B536639BF6719C05882D60DA5BA5A4061DF4E22C26719C0F4948BE7A2BA5A4004D31F50EC6719C023B7CB23A4BA5A409F39909A1B6819C0168D1079A6BA5A40428303102D6819C068C7B205A9BA5A40D8D880632A6819C037C71407ABBA5A400FDE0D58286819C019A831C6ACBA5A403D563A692B6819C019A831C6ACBA5A40A46A60504B6819C04F4B62FFABBA5A401EC022BF7E6819C04F4B62FFABBA5A40564046E5CB6819C0AE563728ABBA5A40B2DAFCBFEA6819C025E65949ABBA5A402943B005186919C09A7D795CAFBA5A4087CA75093D6919C05D3FB3DAB2BA5A40A49872744B6919C068887489B4BA5A40DD8A0E924F6919C003DA0C26B4BA5A40750470B3786919C0F893E7B0B1BA5A40DC18969A986919C05F37B6E8AEBA5A4081F975F1C86919C006F2ECF2ADBA5A40FB4B416D0A6A19C019F0E835ACBA5A40122741C92E6A19C0261AA4E0A9BA5A40073D409C2C6A19C0DAFE9595A6BA5A4091F870242B6A19C029498DBFA3BA5A4058B329B2316A19C05AED0676A1BA5A4034EC4152556A19C0BF870101A1BA5A40AD3E0DCE966A19C014A639C39EBA5A405139DCFDE06A19C07A15BE639DBA5A405E2ADB2C036B19C01CD13DEB9ABA5A4031D692E92B6B19C01129BCBA99BA5A404A0E338F576B19C04BF37D279CBA5A40914B7732936B19C085D448A69EBA5A407958A835CD6B19C084DFE1D1A1BA5A40A3714D26136C19C016A17D51A7BA5A40F931E6AE256C19C090DECBD8ABBA5A406E032D13346C19C0D1C72187ADBA5A4090AB47D04E6C19C00B197E26B1BA5A40F54DF5BFB76C19C0C83AC1A3B2BA5A4067C0B403096D19C094895B05B1BA5A400AB48531336D19C043B4B16DACBA5A40382CB242366D19C0CA6E66F4A3BA5A40585936CE016D19C00D11DCED9FBA5A401460B3B7EF6C19C0B5A338479DBA5A40446F4CAA116D19C0F88491039BBA5A40C8A71144276D19C0A1EF13AC96BA5A404CAA1155536D19C0DE1099A894BA5A409544F641966D19C0E0DA899290BA5A407D186BC9F46D19C0DC8882748CBA5A40F5633843166E19C042F806158BBA5A40DE3994A12A6E19C09B15F6598ABA5A40E04092A34A6E19C0C563F5FD8ABA5A406B03C12D696E19C0B33A83D08BBA5A4086425FD5B46E19C0290FC1278CBA5A40F0F0E890E56E19C008173C9688BA5A40C39CA04D0E6F19C0F81CB34783BA5A40D970A2A7126F19C0B4571F0F7DBA5A40362E2D34216F19C0EC7C89C278BA5A40653ACF33516F19C06FBD01C177BA5A4023128596756F19C086E28E3779BA5A40DC2FFA658B6F19C0C680913C7CBA5A400B8B40AB826F19C0BFFFA03F7EBA5A40C5FE57C27F6F19C0C351A85D82BA5A40F6BD3C539E6F19C0BCFB2D4B85BA5A4051C8844EBE6F19C0D320BBC186BA5A40C91352C8DF6F19C0C7A3AF7B86BA5A40E24BF26D0B7019C0219628D684BA5A40706BC141317019C05EB7ADD282BA5A40E5034C2A647019C0CFCEB3A382BA5A4089FE1A5AAE7019C0DA7635D483BA5A40D0910145D17019C0A9FD310887BA5A40A43DB901FA7019C000C1C1838BBA5A40192CE631147119C0752ACF728FBA5A401679A3A0257119C0502ED7EC92BA5A4048872C770B7119C02B07697C95BA5A4002FB438E087119C02486787F97BA5A40EB7AFDA4357119C0FA62EFC597BA5A40A59F70766B7119C0E33D624F96BA5A40794B2833947119C0090FE4EA91BA5A404A9A3FA6B57119C0B24B546F8DBA5A40BF886CD6CF7119C026BDB90988BA5A409591C4DCFF7119C04FE042C387BA5A40AC6CC438247219C0313AC54F88BA5A40F3FFAA23477219C01F3CC90C8ABA5A403936F1C4627219C040344E9E8DBA5A4082D0D5B1A57219C0DFC0E44691BA5A40F668609AD87219C0E33D624F96BA5A406D5E8BCC127319C0AB18F89B9ABA5A40277C009C287319C07A747EE59CBA5A409DC0CF132A7319C0FB5A971AA1BA5A406E0FE7864B7319C0CAB61D64A3BA5A407016E5886B7319C0BE39121EA3BA5A402D98F8A3A87319C01901158EA0BA5A402BECB314DA7319C0C268FBFC9CBA5A40457AF601ED7319C041576CDD97BA5A4089A93EA1E87319C014B7651B93BA5A40FD906DCFE27319C0DBC4C9FD8EBA5A40B70485E6DF7319C0EDC2C5408DBA5A4089A93EA1E87319C088FD54CB8CBA5A4002FC091D2A7419C040EC962E8EBA5A40EEBB7DB1527419C05859DB148FBA5A40A59938036D7419C0F2E9567490BA5A40045EC1919B7419C04CB159E48DBA5A404DF8A57EDE7419C05AB33ADE89BA5A404DA90139177519C0D24B31AC87BA5A40DBC8D00C3D7519C0C7A3AF7B86BA5A400C321356747519C08B2C3EAA86BA5A400DE36E10AD7519C06209B5F086BA5A40DF388485EE7519C04438C19286BA5A405527B1B5087619C052F2EA1C83BA5A405B05D616437619C0D2B5E5127DBA5A4087591E5A1A7619C0ABC1453877BA5A409F2F078BD47519C07E4CB56073BA5A4010093AB58E7519C08CF8A9856DBA5A4099130F83547519C032E312EC64BA5A4055336B29207519C02995F0845EBA5A40B1E9F7B30E7519C0C7FE68EE57BA5A400DA0843EFD7419C030C84C5851BA5A403AF4CC81D47419C00FAE25894ABA5A404AEAA97A9E7419C0C5E3A25A44BA5A40AAC601AA6E7419C05AD427B943BA5A40A7D9F280687419C07AC8940F41BA5A400930D1C54B7419C044FD892540BA5A40790206EEE57319C01788F94D3CBA5A4076F409EAA57319C0974BF44336BA5A40D356DB03637319C05386600B30BA5A4018DCC5EA457319C09DA9C6012ABA5A40CD3AE3FBE27219C0FFF1B96E25BA5A40875341A08E7219C0BA2C26361FBA5A406D14A3F8427219C00CA6063F16BA5A40DCE6D720DD7119C01D44C6FE0DBA5A40D5F5FA496B7219C030174C570BBA5A407EAA0A0DC47219C0AF30332207BA5A4051B17B3C3E7319C0237722D200BA5A405985CD00177419C008008E3DFBB95A405FFC7E7BE87419C00C2F771CF5B95A4036C24769DB7519C0D615D808E9B95A407319EDA7B57719C0B0F6C143E2B95A40C123850DAA7819C0BECD2C53DDB95A4039D62027A77919C0C54E1D50DBB95A403FF2182F277A19C073B21E08DAB95A403F4DD2A1787A19C0204196AAD9B95A4016623FD5327B19C0B67F0AECD6B95A40ED7DAA0A0D7C19C04D4EED0CD3B95A401283C0CAA17D19C07D4BEFD1D1B95A40BAF770C9717F19C051210D5DBFB95A40E441C417377F19C0FE98D6A6B1B95A40823573EDB07E19C07B6C263AA6B95A407BF99D26337E19C08A2C8837A1B95A4000146DD8007E19C03DEE00F4A0B95A4089CB9651D17D19C0DAB6DE25A7B95A407F2A1323F07C19C06085A5CBACB95A406144EC5DCD7B19C02511D033ACB95A40E9EC09B7217B19C03BFC3559A3B95A405610035DFB7A19C0C8597D1A9CB95A40DEA74F17CE7A19C0CB82893F8AB95A403D26F7E05A7A19C0E560360186B95A40752E7BC84A7A19C09E4FD31D7AB95A4073BC02D1937A19C011B287516BB95A409E8E119A6E7B19C033EF82D261B95A406BA79CE5687C19C00FB4024356B95A40BCCADAA6787C19C03D5464BE4DB95A40D4F36E2C287C19C015DE8A694BB95A406E1C0CD0117C19C0A999FFA12AB95A40B986BE60DC7A19C01FD7868AF1B85A40224ECC1F787919C05D1B857FECB85A40AEEAF6A3F27819C03C3DA539E8B85A405F3821BE5D7819C06A6D7594DEB85A4007FB65E6B87919C0B2EB83D1D1B85A40587AC8EFC87B19C08C56A478CBB85A400452071E847D19C07A6CCB80B3B85A406B2C616D8C7D19C006A458C9A2B85A402159C0046E7D19C0AF22A30392B85A4016DF50F86C7D19C0B03C484F91B85A40D21A834E087D19C0B0647DB985B85A409576B4BB517D19C04EE89A6E7EB85A40E26F20C9517D19C070229FFC82B85A40BC575293857C19C03F0BF8EB84B85A4042058717447C19C0AD4F39268BB85A4085419946937B19C0404B57B08DB85A405E68AED3487B19C0906AD8EF89B85A403CD862B7CF7A19C0E9B5D95889B85A40D6FCF84B8B7A19C07842AF3F89B85A401C430070EC7919C00667F0F78BB85A40E415889E947919C0EB54F99E91B85A4078EC67B1147919C0F54C2F3196B85A404C1C7920B27819C02FE9DE7998B85A40A4C112B46E7819C07C80EECB99B85A40042ED9C23D7819C0FF5E0A0F9AB85A40C987EAF70E7819C0999361269BB85A4008E00B38F07719C0262BD0389EB85A407149C44ABB7719C073631F09A0B85A40290989B48D7719C0F3E7DB82A5B85A409D465A2A6F7719C093DFA293A5B85A4032C687D9CB7619C0CA54C1A8A4B85A405B26C3F17C7619C02235ED629AB85A40FA298E03AF7619C0FC71FBE593B85A402D78D157907619C04CC5C6BC8EB85A40A054FB743C7619C07B15191D90B85A404B1FBAA0BE7519C04D2D5BEB8BB85A40B821C66B5E7519C0225A86938FB85A40526342CC257519C02366F6798CB85A408B51D7DAFB7419C09C91F76088B85A4009E23C9CC07419C02887AAF383B85A40AD9A3116977419C0BD1B0B0A83B85A406ADE718A8E7419C0C6A86BED7DB85A40D0B4C4CA687419C015C8EC2C7AB85A40E1EB6B5D6A7419C064E76D6C76B85A400FF10F5B7A7419C0EBC9FCA36FB85A402BBF0CC6887419C00E4FAF9465B85A406490BB08537419C0A6B338085FB85A40CD0EA782407519C0F4E38AE65CB85A40E14B3CFB257519C0378364A659B85A40ADDC0BCC0A7519C0E634554156B85A4079A7A734077519C03465A71F54B85A40D59700570D7519C0B2BAD57352B85A400EFA2D95127519C0E818EB7651B85A40029AAD612B7519C0F4F4B63E51B85A400791B17F437519C0D7C79E9850B85A40F0D69EFE587519C01F7D38ED4EB85A4050447529647519C080773C774CB85A404BA71A62617519C0B7C71C1549B85A40681E65694C7519C02FA8CA5246B85A40379C4363377519C03C87325445B85A4049298D3D207519C0369CE8A944B85A402EEEF5A4027519C0C5877E1244B85A40D829560DC27419C091D9B4AD41B85A4063CB97BCA67419C0F1D01CFE3FB85A40C3FEA14F9A7419C0FA3207F739B85A407D59DAA9B97419C0FB383F6A38B85A400C42D4D8B97419C07F4E417E36B85A4022895E46B17419C0EABF18DB35B85A400C080841A27419C062DC0DA235B85A40E0055B36847419C074A6BF4D35B85A409632BACD657419C0920ABEC433B85A40205D6C5A297419C0B1CAE08332B85A4022B60595027419C00BBD59DE30B85A40D955ED3FD77319C0A06527CD30B85A40A7E9B303AE7319C0D4168D6B32B85A40233D563A697319C09885764E33B85A40DE0610994D7319C03804D89134B85A405C7E969D347319C0CCA0359A37B85A40A6DD9ED6237319C04ED8D9EB38B85A40956C2BAC0A7319C04289E0C938B85A40A7DC8EBAE77219C0A80CD24238B85A40A9C29FE1CD7219C09D95FE6F36B85A40445EC598AA7219C0EA46B30D37B85A40BBA58B039E7219C06690717B38B85A4050BE45CC917219C0E2010A9A3BB85A40E39645178A7219C027A25F5B3FB85A4049C44ABB877219C0A94C310741B85A4061BB20C77B7219C0C68DB68542B85A4063A131EE617219C0D269824D42B85A403B3CDFAA467219C0B59B2A2941B85A40FDE2AD4E297219C06EADE5843FB85A404215EDE0167219C01B3C5D273FB85A40ECE4C237037219C0C7F2AE7A40B85A40002258B0E87119C0AF20729F41B85A406C7C26FBE77119C0EAC5F59441B85A4058AE1287C77119C062FC8FA740B85A40C74B9242B47119C0B68DF5C33EB85A40C74B9242B47119C0A09F4E1E3BB85A401292BBBEC57119C0B45BCB6438B85A400C282F8DBA7119C08BCB4CC436B85A4073E5A210B77119C0805479F134B85A4084C99E4EC37119C07B13437232B85A4057CC086F0F7219C0D4974AE427B85A40B8020AF5F47119C01C7BF65C26B85A40D6479682247219C02341029024B85A405E1DB6E33C7219C0F59AC35A21B85A404F965AEF377219C0CC69053C1FB85A405316CFEA2E7219C0C75345A71DB85A40E06B63473E7219C0032D13341CB85A40185B0872507219C0649DE05119B85A4042E32E675B7219C0366D6BB015B85A4025F5543D4F7219C0F7D4A01E11B85A40FA4C5189467219C0F9C907F30DB85A404459AE6D407219C00199E7D209B85A40AA66D652407219C0DF72501D06B85A406127ABD84E7219C09FE8BAF003B85A404B00FE29557219C00000000000B85A40B2E7772C4D7219C00000000000B85A4000000060CC4C19C0	0.6308000087738037	2026-06-09
464	89	0103000020E61000000100000005000000000000C0CCB45A40000000A0CD4C19C0000000C0CCB45A40000000609A1919C00000000000B85A40000000609A1919C00000000000B85A40000000A0CD4C19C0000000C0CCB45A40000000A0CD4C19C0	0.5848000049591064	2026-06-09
465	89	0103000020E610000001000000630100000000000000B85A40000000A0CD4C19C00000000000B85A40000000609A1919C0C6DCDCB533BA5A40000000609A1919C0FD8C66C034BA5A40AE34DF77C21919C0CFE9C3C430BA5A403E7B890C061A19C0F3D6AF2A31BA5A40F5C8D57E211A19C0AA6395D233BA5A40212235ED621A19C01CAFE53A32BA5A40541EDD088B1A19C07171F9B42FBA5A4082AB3C81B01B19C0D76D50FB2DBA5A40484A1F5FE71B19C0911216702ABA5A40A114ADDC0B1C19C06EFAB31F29BA5A4037555282591C19C0D78A91802CBA5A4028994121A71C19C0B4E2C0502CBA5A4018DD30C0F41C19C03AC2B34E26BA5A408EF458E9A41D19C03932456F27BA5A403349D16F041E19C080F277EF28BA5A40B96BAE3F2E1E19C05DDA159F27BA5A401DB4B2D8811E19C028CAEF7E26BA5A4088D5C4A7A51E19C05DDA159F27BA5A40FC8A355CE41E19C0E9F2E6702DBA5A4026512FF8341F19C0D78A91802CBA5A40C5CC9948C41F19C06EFAB31F29BA5A409ECA0E96562019C0068AB37D23BA5A40548CF337A12019C07A71E2AB1DBA5A40D0CBCDDCE82019C04561BC8B1CBA5A400426265E542119C0E371512D22BA5A4035C52D30752119C005FA449E24BA5A40995CD60E902119C03A7AFCDE26BA5A401F300F99F22119C080F277EF28BA5A40AEEF6888CF2219C01B892BC228BA5A4019C2D6112C2319C0202F5A3629BA5A40B3452D28672319C05B446F4C2ABA5A40DFD4511F922319C0FC4FA3352BBA5A40188E31C1BA2319C0D215116A2BBA5A4056B19D94EE2319C0197DBBDB2BBA5A400F09DFFB1B2419C0138FD5F72BBA5A40EA91ABFD422419C04974852D2CBA5A408CBB41B4562419C08AA82E852CBA5A4024A82BE9722419C06C8CE77D2DBA5A40D24B31AC872419C09C2DC5FA2BBA5A401FB935E9B62419C00D45CBCB2BBA5A406F2C280CCA2419C072EDFABB2DBA5A40C06C4C99E52419C059A2581330BA5A4086CD5BD0D62419C040FB912232BA5A40E02A4F20EC2419C06E5F515B34BA5A402F2BB92F0C2519C0EB7AFDA435BA5A40A8E90EBD202519C03D2E05FF36BA5A405B4A4C06362519C0FDEB264234BA5A40B127CB5A542519C0E0EC20C033BA5A405CDEC1F4622519C07A3881E934BA5A40742C4A647A2519C0FC1065B936BA5A40FAC1AF47972519C03D76BC6E36BA5A40E81780A1A22519C0090A720635BA5A40439259BDC32519C056629E9534BA5A40004D2954DC2519C0F6C9F6C635BA5A409D0C33D9E42519C07F935CB436BA5A40FD0978E3EE2519C0F6813F5736BA5A40665E58480A2619C0B0C4A81034BA5A404A777C201E2619C01B7B9BA333BA5A40A564DE4F322619C0325871AA35BA5A40FA77222D3A2619C031F378B537BA5A40537B6C263A2619C0F4CE577F3ABA5A409EA4AFD63F2619C0CF656A123CBA5A402F2416E75E2619C02D93E1783EBA5A40FF356ACF762619C021CB82893FBA5A4076D4E29D8D2619C01BE038DF3EBA5A40984638D2BE2619C027FE83A33FBA5A40982A6222EF2619C0E7768AB03CBA5A40FF7B4B94182719C0537B6C263ABA5A405B16026F372719C0CB24349339BA5A406E916A8E622719C066E9F98939BA5A40D83FF449932719C01715CCF33BBA5A40B3582F2BB92719C046EF54C03DBA5A401D07B9E6E92719C08C39BEAC3FBA5A40BE4A3E76172819C09227A4903FBA5A40B2EEC4515E2819C0634A7F8A3EBA5A40C2604898B32819C0BF4868CB39BA5A400458E4D70F2919C03788D68A36BA5A40C06268D02B2919C0E5338FB234BA5A40CE07BAAC782919C06885D84F35BA5A4078A2DA96B72919C06C81F39837BA5A4005F86EF3C62919C0BFBB95253ABA5A40C201E3CFA62919C0E08508933DBA5A404CB90C49772919C0334D7DC53FBA5A40927AAA9E272919C0967C47E842BA5A40DCB8C5FCDC2819C029A3DB5C46BA5A407297B32DB92819C0C8D34DBD49BA5A40D7C1C1DEC42819C01523A69F4BBA5A4051137D3ECA2819C010690A534ABA5A4094D343D9002919C0CF3D35A847BA5A40A342D02C642919C0E146CA1649BA5A40D77B3BD3952919C015DE8A694BBA5A401EB97F76D12919C083EB408C46BA5A40F89C05EB492A19C03746FCD442BA5A4008D5BC99872A19C04E82925D44BA5A404AAF720DD82A19C016FE672849BA5A40D232F735372B19C0851733784EBA5A40E9D32AFA432B19C03C003D6851BA5A40C82E07301B2B19C0A80183A44FBA5A4074547FCEEE2A19C0F5B5D37B4FBA5A404788974CBA2A19C000E5EFDE51BA5A4082ECAB61752A19C070F3210354BA5A401A283ADC582A19C0F1F0434A58BA5A40940A7437992A19C07E2F2A4E5ABA5A40E3F1FE89DB2A19C05BE619A059BA5A4036FF5481FF2A19C0E074818156BA5A40276321DF4A2B19C02F0ACC5452BA5A40BFC7AA52C42B19C0A80183A44FBA5A40ED0A22F7192C19C0FDC9CE914BBA5A40E277D32D3B2C19C029FFFFA446BA5A400E02E1F9FB2B19C0CB7564F643BA5A409D972FD4062C19C0A2B437F842BA5A40D9CD8C7E342C19C00DC74ED342BA5A403CB8E0B1442C19C049B4893842BA5A402A696A7EA12C19C091D6187442BA5A408641F4FF052D19C0D20D5E0542BA5A40BE518605522D19C0F47574B746BA5A406BB4C12E2F2D19C07F74A03D4DBA5A402C7D8DC9872D19C08C48145A56BA5A40E0377469B22D19C0F5A10BEA5BBA5A404404D2B47A2D19C07B2BB75961BA5A40384D9F1D702D19C00D350A4966BA5A409CAE8273A12D19C0083653C664BA5A40E5BFF682052E19C089BA6AF95CBA5A4052CB20883D2E19C0FDFDBD6F57BA5A40C7DA3A93912E19C048DFA46950BA5A40791CAB39E52E19C089CE328B50BA5A405A69ADC32C2F19C00041142752BA5A40EDD22B0A602F19C0571BADB456BA5A40EBB24E4B622F19C0E3DAF5775BBA5A40B31A5C84732F19C0D685C4E25CBA5A40E5130DADA92F19C0EEB089CC5CBA5A40160DBED5DF2F19C03136BE405ABA5A409723BFD9413019C0EF1582C15ABA5A4001D64FA4A03019C06C1DC1325BBA5A40A0A46549253119C0A777F17E5CBA5A4094BB74385F3119C0E8A562635EBA5A408928266F803119C0B6E4A72762BA5A40EF1B5F7B663119C09649C3DF65BA5A40EE186888743119C0885EEBF769BA5A40FF70FCF5AF3119C045D37E106EBA5A409BFB500E0B3219C0313FDC7A72BA5A408F2B3FBA223219C0BD152E5077BA5A40D3EAF5381D3219C0AFE53A327BBA5A40666C4320F23119C080D767CE7ABA5A4007A8BA91C33119C0CE041E7379BA5A405B446F4CAA3119C08DEA196778BA5A402DFE00B5623119C0E5CAEA677BBA5A40224AC5104A3119C0161CB9C983BA5A40F2B1BB40493119C008A7AA7587BA5A40109C8E5B273119C0CCFBEE0C89BA5A40A609DB4FC63019C037C9EAB188BA5A409D746C4E6F3019C07D8681F88ABA5A40B0E7C64F3E3019C035A039468DBA5A400BEE073C303019C032152C1F93BA5A40A58A3D0F493019C029FE94CF97BA5A40B20BAB1D6A3019C064833B069ABA5A40582547F0753019C0ECEDE0719BBA5A402ACA00AB7E3019C08681F80A9CBA5A40ABF8D04F823019C01904B1C79FBA5A4023618495AF3019C0E88AADFBA2BA5A4001DA56B3CE3019C0696E2AF7A7BA5A4034B91803EB3019C066E6B809ADBA5A4098A77345293119C07CD45FAFB0BA5A40D24A6B1D663119C04B5B5CE3B3BA5A40B33CB4345C3119C00DA7CCCDB7BA5A40BD7960B6533119C0D5F1F33ABDBA5A40FAEC80EB8A3119C022BD4D24BDBA5A4086263F98CA3119C0B7EF517FBDBA5A40D2CA187A1F3219C0E6B809ADBDBA5A40F8F3B74E6D3219C07BEB0D08BEBA5A408E6A227DA43219C0B6172C30BFBA5A40AAFF626CD73219C04A720A3CC1BA5A40BED06DD3E93219C0E39D8DA6C4BA5A402C184B47EF3219C0AD2B0BCBC4BA5A40EA944737C23219C0362383DCC5BA5A404DEE1C6F973219C0AB7BBF2CC8BA5A405E5B898A823219C0F20A444FCABA5A40A65DF1796A3219C01A9826B6CCBA5A40FB6C2E48443219C0A2B77878CFBA5A40D2CA187A1F3219C01810B5C8D1BA5A40E744717D0E3219C07BC9B557D5BA5A400FE7864B333219C021C3CF24D6BA5A40A65DF1796A3219C0D4F7753BD6BA5A409FC2B6EADF3219C0220E23CED4BA5A40236F14B4243319C0D6EF7849D2BA5A40FCA13E6E643319C0532B0252D1BA5A40E3C4573B8A3319C0B2BAD573D2BA5A403F29498DBF3319C003345BC3D6BA5A40371378CCE53319C024B0DE4DDCBA5A40A4703D0AD73319C080FC5BB8E2BA5A403491E398763319C0CB9B68FCE7BA5A40A1B0D52F223319C0ED061BE8EBBA5A40C885B9933E3319C0A56B26DFECBA5A40A021776C5F3319C0F6D03E56F0BA5A408258912CBB3319C0198D7C5EF1BA5A40541E38C2FD3319C0B34B0AE2F2BA5A405969F750473419C0FBB2B453F3BA5A4088CF42A78C3419C02C2CB81FF0BA5A4003081F4AB43419C07044F7ACEBBA5A400D45CBCBAB3419C02351C312EABA5A409DF7FF71C23419C0DCE918A1E9BA5A40F651FCCEE53419C0531A7B40EABA5A409605137F143519C02EDC03BEECBA5A40ABD61DE6263519C0E4AA6862F0BA5A40EDE588C6243519C0FBB2B453F3BA5A40671F7585883519C01764CBF2F5BA5A40A3EA573A1F3619C08D637F34F7BA5A40DC37ADCA743619C063E135F9F7BA5A4059935D1F8C3619C0314BF1A7FCBA5A401CCEA1B19B3619C013150555FEBA5A402598C51FA03619C007AC66E7FEBA5A40A1D398B5B93619C013150555FEBA5A40C64BDCCFCE3619C03134E895FCBA5A40C0023D79FD3619C03134E895FCBA5A404FD257EB1F3719C09CFE4701FDBA5A4097A201614C3719C09CE73EEFFCBA5A40A4CDCC27863719C026E88AADFBBA5A40DA290C80A73719C045F064DCF9BA5A4069F926F2C93719C0CEC29E76F8BA5A40513C1D7EED3719C0B0A3BB35FABA5A40267B3A0D073819C0FC7C4A84FCBA5A4041295AB9173819C013431779FEBA5A4004F40C2B263819C0BFA0E0BDFEBA5A40676BD84A433819C0AED9CA4BFEBA5A40AF714749593819C001F2CA9AFDBA5A40E23323CD693819C0E496A0D0FCBA5A406EF9484A7A3819C08B09206BFCBA5A40D44334BA833819C08B68E0ECFBBA5A4061095A37943819C0EB73B515FBBA5A40C7702B73A93819C06898350CFABA5A40533651F0B93819C08D7450D3F8BA5A40220BE24DC83819C022C1F979F8BA5A403D29931ADA3819C0F827A72CF9BA5A400ABE69FAEC3819C0D390A79BFABA5A408BB67416073919C079E6E5B0FBBA5A401559C6E1273919C049BE6D01FCBA5A40023917354E3919C0DFDC0484FBBA5A40E44E441A703919C026BD14C3FABA5A40A0E63FFF983919C0B67A9807FABA5A4046C71F56C93919C0506D7022FABA5A4097D17E5AFB3919C0BB20C77BFABA5A40DC943CE8233A19C026EB26E7FABA5A408F4C2C955C3A19C097303FDCFABA5A404F68A384AA3A19C0EBE97EA9FABA5A40E4F4F57CCD3A19C0626534F2F9BA5A40B16CE690D43A19C0815369D5F8BA5A40DC679599D23A19C028846973F7BA5A40200A664CC13A19C0D5FE733DF6BA5A40AD084845AD3A19C03BB31314F5BA5A406182644BA03A19C04E976A0BF4BA5A4001158E20953A19C031708AD8F1BA5A408AB0E1E9953A19C0D2F7BFC8F0BA5A4078962023A03A19C02067F569F0BA5A407CDDD8A2BB3A19C037781508F1BA5A4080249122D73A19C0A1AF6A5AF3BA5A406EEEF9AB113B19C01EE21FB6F4BA5A40473A03232F3B19C0248BEA63F4BA5A40A5F78DAF3D3B19C0549FF53AF3BA5A40FE17BE74493B19C0D70D805DF2BA5A40A094FF7F523B19C01401F335F0BA5A407933B44B653B19C033F2C352EEBA5A4045381C4C793B19C0EC037FAEECBA5A401FA40282943B19C04C546F0DECBA5A4093358F68A73B19C01C15EE4BECBA5A40C0E78711C23B19C08DB38E4FEDBA5A40B1D4C44CEC3B19C09EBC23BEEEBA5A4044B1CBA6123C19C049FA0F44F1BA5A40A405C314403C19C0607825C9F3BA5A405663096B633C19C053C7CFEBF4BA5A4023F8DF4A763C19C08248D0A9F5BA5A404C11853BBC3C19C00B43E4F4F5BA5A4086D162DF043D19C0DDDE24BCF3BA5A409236FA3D563D19C01FEBF362F2BA5A40E204A6D3BA3D19C0DE8BD420F1BA5A4047A34CB4F53D19C09D2CB5DEEFBA5A4098ADABB8273E19C0C7AEFE19EFBA5A40B74CE19C6C3E19C0CCECF318E5BA5A403BC269C18B3E19C05546C8E5E4BA5A402F490AD1C63E19C01A2E1796E4BA5A40DD9A745B223F19C01DA55C2BEBBA5A40DFBD480D123F19C0A64984A1E9BA5A403D83E1B77C3F19C06967E267EDBA5A405258F32DBD3F19C0D724896FF2BA5A401E5D5B2ED13F19C0C7CE801FFABA5A40DE36F867AB3F19C041EF8D2100BB5A40C0304F9DFD3F19C0CF1033A003BB5A4085CC3A88424019C026361FD706BB5A4081E4428AA64019C069458AB704BB5A40EBC891CEC04019C07767EDB60BBB5A40E8154F3DD24019C0422619390BBB5A4065ABCB29014119C08463963D09BB5A40BAF8DB9E204119C08B54185B08BB5A407590D783494119C013F06B2409BB5A40A8A9656B7D4119C0958098840BBB5A40FDF675E09C4119C06A85E97B0DBB5A40309C6B98A14119C0F9F719170EBB5A4074ECA012D74119C0172B6A300DBB5A40749A05DA1D4219C0EFE53E390ABB5A4045B75ED3834219C0A987687407BB5A4012FA997ADD4219C03ACAC16C02BB5A4066BB421F2C4319C08D2441B802BB5A40D253E410714319C0C365153603BB5A40C190D5AD9E4319C0DFFC868906BB5A40276C3F19E34319C0325706D506BB5A40047289230F4419C0FD2FD7A205BB5A40B4ACFBC7424419C0CEDF844204BB5A405F0D501A6A4419C02F36AD1402BB5A402BDCF291944419C02F36AD1402BB5A40D576137CD34419C0645DDC4603BB5A40C4B30419014519C0B7B75B9203BB5A40E65B1FD61B4519C010035DFB02BB5A4090BC7328434519C05340DAFF00BB5A402F8672A25D4519C0B39602D2FEBA5A401E8997A7734519C0662D05A4FDBA5A40EB1D6E87864519C0AF5B04C6FABA5A40CEC3094CA74519C08DEDB5A0F7BA5A40342BDB87BC4519C017D7F84CF6BA5A40D97745F0BF4519C0BFF38B12F4BA5A401283C0CAA14519C09C6B98A1F1BA5A404BC8073D9B4519C0FDC1C073EFBA5A4079EA9106B74519C01BF5108DEEBA5A4029081EDFDE4519C0DA1F28B7EDBA5A406D585359144619C086AB0320EEBA5A40670FB402434619C0266F8099EFBA5A4006137F14754619C0B493C151F2BA5A4066F7E461A14619C0CBA145B6F3BA5A4060AE450BD04619C02A90D959F4BA5A40603FC4060B4719C048DDCEBEF2BA5A4004E3E0D2314719C03D635FB2F1BA5A4015376E313F4719C090D78349F1BA5A402B306475AB4719C0253B3602F1BA5A401F477364E54719C07AFD497CEEBA5A4030F2B226164819C04CE141B3EBBA5A40CA1B60E63B4819C0A06F0B96EABA5A40E0DA8992904819C035D3BD4EEABA5A408AAF7614E74819C076C24B70EABA5A4023D923D40C4919C0FDC1C073EFBA5A407369FCC22B4919C095607138F3BA5A4034A14962494919C0F9D7F2CAF5BA5A40CDCEFD309D4919C0CED60B4FF9BA5A4013640454384A19C0A362F778FCBA5A40C539EAE8B84A19C055979D8FFCBA5A40458AB784324B19C003D0285DFABA5A407610E099754B19C003D0285DFABA5A409626A5A0DB4B19C069E0EC7BF9BA5A40E5F04927124C19C02AD5F48FF4BA5A40A59828E7304C19C0BFC81528F3BA5A400B708B43474C19C084DE76FCF2BA5A40D5511F926B4C19C06D01A1F5F0BA5A40C2A4F8F8844C19C09DB98784EFBA5A4056BABBCE864C19C06F9D7FBBECBA5A4039B709F7CA4C19C09BF55A6DECBA5A40000000A0CD4C19C00000000000B85A40000000A0CD4C19C0	0.41839998960494995	2026-06-09
466	89	0103000020E610000001000000670000000000002033BB5A400000006066E618C0F9B85F47A9BC5A400000006066E618C01C959BA8A5BC5A403DD175E107E718C0E2CAD93BA3BC5A40F33CB83B6BE718C0EFC682C2A0BC5A40AED9CA4BFEE718C0D2FBC6D79EBC5A40FCC56CC9AAE818C05CFFAECF9CBC5A40B745990D32E918C027D87F9D9BBC5A4077483140A2E918C0BC3B32569BBC5A406BD3D85E0BEA18C08C834BC79CBC5A40651BB80375EA18C0C1AA7AF99DBC5A40BF99982EC4EA18C038DBDC989EBC5A40A8363811FDEA18C061889CBE9EBC5A40BF81C98D22EB18C073F38DE89EBC5A404D31074147EB18C07B32FFE89BBC5A40CE3637A627EC18C05E81E84999BC5A40335184D4EDEC18C0304B3B3597BC5A402CF015DD7AED18C04E98309A95BC5A408D64EA09A6ED18C071546EA296BC5A40F3AFE595EBED18C0251FBB0B94BC5A403A2AEDC330EE18C0840D4FAF94BC5A4014234BE658EE18C0560BEC3191BC5A40906B43C538EF18C027A1F48590BC5A40732EC55565EF18C044B467E091BC5A40AFE0C84D1EF018C0C83956CE83BC5A40CE52B29C84F218C01A6B7F677BBC5A40232C2AE274F218C02733DE567ABC5A40B284B53176F218C07C43E1B375BC5A409B90D61874F218C0E1EB6B5D6ABC5A4067D311C0CDF218C03AE63C635FBC5A400BEBC6BB23F318C01B2E724F57BC5A40CC96AC8A70F318C0BB922E4759BC5A40E2B19FC552F418C0E9A0A6F166BC5A4058A3C3E85EF418C0D1FC7B3A68BC5A40EFAE0EDB71F618C088FF2A766ABC5A40A5E0849DBDF618C09ACC785B69BC5A4070B54E5C8EF718C0DFBCDD3763BC5A40D1B58A598AF718C0EBAFB21163BC5A40919845CDFCF718C05649641F64BC5A40E083D72E6DF818C036C8242367BC5A40B16B7BBB25F918C0C4D2C08F6ABC5A4061E0B9F770F918C07061DD7877BC5A4005323B8BDEF918C0CFBA46CB81BC5A404FCB0F5CE5F918C07555A01683BC5A4004711E4E60FA18C02920ED7F80BC5A40CBF6216FB9FA18C016FC36C478BC5A40868E1D54E2FA18C0DF35E84B6FBC5A401AC1C6F5EFFA18C02159C0046EBC5A40B8205B96AFFB18C0232C2AE274BC5A40E085ADD9CAFB18C08FE21C7574BC5A40A54A94BDA5FC18C054FEB5BC72BC5A40F910548D5EFD18C02159C0046EBC5A4059FAD005F5FD18C0100874266DBC5A4030D461855BFE18C07BBE66B96CBC5A4046240A2DEBFE18C0C97553CA6BBC5A4084D9041896FF18C0CBF78C4468BC5A406CAC6983B8FF18C0891F083568BC5A40AB5B3D27BDFF18C05998CF0369BC5A403EE6A8482A0019C05ACC199B67BC5A40FFEC478AC80019C001B2C68F67BC5A40BF08BF79160119C08ED36B0E6BBC5A40ACAA97DF690219C00A174DC260BC5A4063BE17BA6D0219C08701A66755BC5A4078D0ECBAB70219C07590D78349BC5A40BC3901F2CA0219C0A2CB400A43BC5A40DE8A694BC20219C09107C7D141BC5A40F59B2E30D00219C06E90A4FF40BC5A40FA23B149230319C0358A9B093CBC5A404AD466F73F0319C0FCE5EECE35BC5A40A4703D0AD70319C0132DD4F51FBC5A40656AB702AF0319C050A73CBA11BC5A40A4FCA4DAA70319C0CBE08332E8BB5A401CD0D2156C0319C0245A97BFE7BB5A4092527534B30319C04496163FD7BB5A401630815B770319C080DCD9B2D7BB5A4081C93269F80319C0C408E1D1C6BB5A4076DF313CF60319C070438CD7BCBB5A40B5FE9600FC0319C0A0C4E74EB0BB5A4032E6AE25E40319C05932C7F2AEBB5A400A2FC1A90F0419C0B1DEA815A6BB5A40325A4755130419C0028063CF9EBB5A4021753BFBCA0319C0C90391459ABB5A40656EBE11DD0319C0643E20D099BB5A4043CBBA7F2C0419C06E4DBA2D91BB5A40FE45D098490419C04301DBC188BB5A402B85402E710419C0B2D5E59480BB5A405F0D501A6A0419C00070ECD973BB5A408D47A984270419C0B0CBF09F6EBB5A406F7EC344830419C06939D0436DBB5A40583849F3C70419C0B7D3D68860BB5A40E7FF55478E0419C0BAD7497D59BB5A40E7FF55478E0419C0BAD7497D59BB5A40A88E554ACF0419C04B00FE2955BB5A40D0B9DBF5D20419C0CFF8BEB854BB5A40BFD4CF9B8A0419C0C5E6E3DA50BB5A407BDB4C85780419C05001309E41BB5A406F7EC344830419C0BBD1C77C40BB5A4041F2CEA10C0519C035D252793BBB5A409CA56439090519C0B8CA13083BBB5A40B477465B950419C06E313F3734BB5A40E7FF55478E0419C02194F77134BB5A40A88E554ACF0419C00000002033BB5A4089740F7ADE0419C00000002033BB5A400000006066E618C0	0.9705999493598938	2026-06-09
475	89	0103000020E610000001000000C8000000000000A099B15A40000000A0FF7F18C00000006066AE5A40000000A0FF7F18C00000006066AE5A405E16D0FBC45B18C04276DEC666AE5A4056AD9685C05B18C06B798AC168AE5A4000EDFDFCAD5B18C0931ADA006CAE5A4023049ABE8D5B18C01FA6D82C72AE5A400C7F3CAA505B18C0AA8DFBA078AE5A40465C001AA55B18C0125784517FAE5A409B04CA01165C18C0244CACE77FAE5A4063BF828F1C5C18C01CDC8C8983AE5A40EBC9575DE25B18C085C5F2F887AE5A405E79DA2B3D5C18C001DE02098AAE5A40177E703E755C18C0C619C39CA0AE5A4090831266DA5E18C021EA3E00A9AE5A408335CEA6236018C0B58185DDC1AE5A40343EDD8A0E6218C09DDE20B5E4AE5A4070B378B1306418C0F60D4C6E14AF5A4012143FC6DC6518C06EB257691CAF5A4073C2DF8A1F6618C0ED7200B331AF5A403DB08806CE6618C007A2DDD737AF5A402E3DF5A33C6618C004A4A2563DAF5A409E0F2ACCD66518C0B55CECAC4CAF5A4065F0E65F816618C06370DE4955AF5A404947DEDEDA6618C02426A8E15BAF5A40F3E1FEC8196718C063BE727360AF5A40DCD440F3396718C08A84002A66AF5A40716193EB5C6718C0258EE15666AF5A4082D20616766718C0A2C96A5F65AF5A40C795C4A39E6718C09DB3AACA63AF5A403EACDCB0126818C0AE18648165AF5A40382971C2296818C0D5F896836AAF5A4066F84F37506818C0923F18786EAF5A4087F31549606818C0A7131AD272AF5A4094C72EAC766818C0A033695375AF5A401616DC0F786818C07C9F05FC75AF5A401C9947FE606818C0E61E12BE77AF5A40CCE78134086818C0F783CB7479AF5A40EEFA16E7B96718C0155223997AAF5A40D80638CEB76718C06687F887ADAF5A406B63EC84976818C0A5051ECEB2AF5A40B0BAC4477A6718C0E49DE85FB7AF5A40B0BAC4477A6718C05319106BBBAF5A4016C3D501106718C0673DC626C3AF5A40665BBC0E8B6718C0D52B1B8CC7AF5A40665BBC0E8B6718C0DF3DF669CBAF5A40430E000B4F6618C08E51E806D4AF5A40AF4FEF98706618C0E0F3C308E1AF5A40BB2308FC866618C0596721A6E9AF5A4016F4835F8F6618C046860B2FF7AF5A40B956D6917E6618C08A1AF109FEAF5A40E2D3F7753B6618C08F160C5300B05A4070287CB60E6618C0C40F296101B05A403DD52137C36518C0942CCCE701B05A40648511B1776518C0949FF94102B05A401A57B7D5076518C09928E73004B05A40A8AB3B16DB6418C003A8F3F205B05A401A57B7D5076518C03318231205B05A4098D64BF84A6518C03318231205B05A4087342A70B26518C00335C69805B05A40C65B9D52146618C0D21D1F8807B05A403DA473D9436618C0689E12C605B05A40A8E56267656618C0FEABD8A903B05A40326CDE82B66618C0689E12C605B05A4059B85109F46618C0D833DF1C09B05A406A29C5330D6718C00CA029850AB05A408D45D3D9C96818C0DC2FFA650BB05A40226FB9FAB16918C06A6B44300EB05A40DCF3FC69A36A18C078EC67B114B05A40D0B359F5B96A18C055A0BBC914B05A40B4D02923896918C0D881734614B05A40BCFAC275D66818C03D0565BF13B05A40D8A3CBF67C6818C0D881734614B05A40F44CD477236818C0A3FB839213B05A40D26AED22F16718C055BDFC4E13B05A40DCA39295BA6718C00D0863FA14B05A409E4A61399D6718C0EFD412E115B05A404460F6FC7A6718C0428E52AE15B05A40CC310F4F656718C0F54FCB6A15B05A400FB40243566718C096BABFD515B05A4059130B7C456718C03037CE5C16B05A4060F01FC1436718C059541FA317B05A40D2B47A3D4E6718C088EC287318B05A4081785DBF606718C01DEE7E7019B05A400421B479776718C08DE843BC1AB05A40F323D97E8D6718C0169BA0971BB05A406B52C02CA36718C003441C461CB05A40AFBBD463B66718C0E62A71781CB05A40C77CE5E6C06718C04B94BDA51CB05A40E80423E5DD6718C0D3D3EC261DB05A400053AB54F56718C0CD58349D1DB05A401137A792016818C0CA294BBE23B05A408170AA5A776818C03EA18D122AB05A4093AF5F0BD56818C0ECB47FAF32B05A409E84888A276918C09A3B9FA63BB05A404F8935A6716918C0F6871C1142B05A406CCEC133A16918C052D4997B48B05A408EB0A888D36918C0CBEE6E0A50B05A4027DA5548F96918C005E4A66153B05A40ABF53416036A18C04AE0C5B164B05A40D341A89C406A18C01EA0A0B973B05A40FB8D1B237E6A18C0D1AFAD9F7EB05A4050F40A557B6A18C072F8495A96B05A4039E74C7F9B6A18C00D5F155EB8B05A4050F40A557B6A18C04824C09FD0B05A40EAEBF99AE56A18C04F779E78CEB05A40E67393BD4A6B18C03A144F87DFB05A40E12538F5816C18C059F78F85E8B05A409352D0ED256D18C0CFF00B54EBB05A40FB17528F7E6D18C009C1AA7AF9B05A40F525C055436F18C0BA79F4D008B15A4071491F042E7118C08A592F86F2B05A40539A289DA37118C0A231491BFDB05A405E4FCF166B7318C02C499EEBFBB05A4000CADFBDA37618C0797764AC36B15A40C72DE6E7867618C04B7842AF3FB15A4033C170AE617618C033535A7F4BB15A40C7D63384637618C034BBEEAD48B15A40CDC82077117618C042EBE1CB44B15A405133A48AE27518C06138D73043B15A4051853FC39B7518C08F6E844545B15A401327F73B147518C058AB764D48B15A40F2ED5D83BE7418C0045F2C674AB15A40C8D4B892787418C0DE3186834EB15A4036F39A0DE87318C04E57C1B950B15A40F6589F17937318C0120E620C51B15A405E85949F547318C0C57652BA4FB15A40F222B836F97218C06395777A4AB15A4097B9AFB9597218C065D531F845B15A40BE688F17D27118C0F6E3405942B15A40BAC61D25657118C00A1CBFA63DB15A406C312E0BDC7018C0DC195C293AB15A40D916540A707018C002A08A1B37B15A4033A9FCC6327018C0C7ECD1C034B15A40059D5AC7027018C05280289831B15A40A5486359D56F18C00CB2C0B22DB15A40F10005CD9D6F18C062D630E829B15A4069D43208626F18C039EA8DFF27B15A401EA3E139006F18C0819F275426B15A408401953B7D6E18C064A021D225B15A40696C544C4A6E18C0465964E025B15A40810C78F41A6E18C02297EE6426B15A40C026C68DB66D18C0AA494B4027B15A403646A11B506D18C0C8A4750A28B15A407DC96BCABA6C18C04029FFFF24B15A40787AA52C436C18C08E0B62FB24B15A4025DDE055206C18C070C4A40925B15A40A2C4F87A086C18C0F91D79D624B15A408B9356D7FC6B18C0AC3B16DB24B15A40808C6FDEEE6B18C0E165E14625B15A4081A8458EBE6B18C0FF0B5FBA24B15A40095971056F6B18C052DCA79924B15A4045DD62D9276B18C00CBDB49723B15A40824765D4C66A18C03BA0111123B15A400A325DE38E6A18C03C2DE4B622B15A40E2E5E95C516A18C037A4F6C720B15A4076A4FACE2F6A18C09CB4BAE61FB15A403EE7131ED96918C0321B09D91EB15A407B7203F4B16918C0FDAEBE701DB15A402DA74E513F6918C0FDAEBE701DB15A409EB64604E36818C05D610B8B1BB15A40DD0A6135966818C0D6D127A817B15A40C696D4BFDA6718C01717A29E19B15A4098B2C2E3916618C0CD5598631EB15A40B1EA6289BD6618C07E3C4F9720B15A40D20B2DA1716718C05E11FC6F25B15A404485EAE6E26718C0509CED1B29B15A402EB2F8A81A6818C00F71BDB733B15A404D593CABBB6818C0AE2B668437B15A4016E934C1266918C0A29D2EE642B15A40448655BC916918C014D852F64CB15A401C0934D8D46918C0892D98535DB15A40BDA36BCB256A18C0A48EE96484B15A403A9D1A1EB16418C008A7AA7587B15A406D5FF6A1C16418C009C6C1A563B15A40252A0AAAFC6918C0052F9F515FB15A4072666089AC6A18C03A8D599B6BB15A40775E74C3006B18C0184D1D9A68B15A40A8AED74F5A6B18C018FA714573B15A40E2A47A7C8C6B18C09A73959375B15A40AC7DF090186B18C06179461188B15A401A2087776F6B18C079909E2287B15A40A7CCCD37A26B18C0162296838FB15A402B9501B1B66B18C09A40118B98B15A402CD269824D6A18C0EECB3E3498B15A407E463360DA6918C0000000A099B15A4075D22E939A6918C0000000A099B15A409E9AE3ED826D18C0822C55B398B15A40347A7FCD836D18C0C084C08094B15A4003058310356E18C0000000A099B15A40F9404B9E566E18C0000000A099B15A4048A78B2B6A6E18C0AC4665798DB15A4055FB743C667018C022E758398FB15A40E18AD5308D7018C0FF9D488B8EB15A4031557AB7C37018C0CE6F986890B15A404E4354E1CF7018C0B5F97FD591B15A407077D66EBB7018C0661F1ACC95B15A40C1029832707018C041E1A24998B15A401171732A197018C0000000A099B15A401BDD075EEA6F18C0000000A099B15A40000000A0FF7F18C0	0.7405999898910522	2026-06-09
476	89	0103000020E61000000100000019000000000000E0CCB45A40000000A0FF7F18C03F5F5D9FCEB35A40000000A0FF7F18C085A7A157CDB35A4056B77A4E7A7F18C05247C7D5C8B35A40320807D6CC7D18C09074BCB8C3B35A40605EDB36E77B18C01066C9D2BDB35A406F2A52616C7918C0BA4FE9BBB6B35A401FBFB7E9CF7618C0B23B93ECC7B35A408B8054D4AA7718C06BFAA2F3D0B35A40A9007388137B18C06F63B323D5B35A4096198057157B18C05CFBA7C0EEB35A40D5E940D6537B18C06B93D453F5B35A40C1CF132A937D18C0BE69FAEC00B45A40A3A76D686F7D18C0C88F9D5CF8B35A402294ADE4197A18C0197C5006FDB35A4088145EDD0C7A18C08F8F7120FFB35A4053CC41D0D17A18C09747ED3408B45A402BD780ADB77A18C09641B5C109B45A40E6948098847B18C0B3EA73B515B45A402AABE97AA27B18C0BFF4F6E722B45A404913EF004F7A18C01F49490F43B45A4053AF5B04C67A18C097E4805D4DB45A40AC55BB26A47518C0C9E13895B1B45A407CE7BC6B757618C0000000E0CCB45A408A2481ABB87618C0000000E0CCB45A40000000A0FF7F18C0	0.6782000064849854	2026-06-09
477	89	0103000020E6100000010000000F000000000000A099B15A4075D22E939A6918C02823D3469AB15A400DB78D507D6918C09207228BB4B15A40D59A41D7196A18C0B1EA6289BDB15A400723F609A06818C0101E1263BEB15A40713D0AD7A36818C0172CD505BCB15A40D46531B1F96818C0634D1BC4BDB15A40C9981650036918C0A207E34CB8B15A40A1270A99D06918C080400C19B4B15A4012651470746A18C003780B24A8B15A400643C29C456C18C0F8BB1C1BA6B15A40A2B030E9946C18C01C333FEDA6B15A4022BF23CF9A6C18C048DE3994A1B15A40D9A9036A7B6D18C0000000A099B15A409E9AE3ED826D18C0000000A099B15A4075D22E939A6918C0	0.6782000064849854	2026-06-09
478	89	0103000020E61000000100000004000000000000A099B15A40F9404B9E566E18C0C3A27D079AB15A4032F43E44596E18C0000000A099B15A4048A78B2B6A6E18C0000000A099B15A40F9404B9E566E18C0	0.6782000064849854	2026-06-09
479	89	0103000020E6100000010000008F000000000000A099B15A40000000A0FF7F18C0000000A099B15A401BDD075EEA6F18C034E895FC99B15A40591C29B6DD6F18C00AD9791B9BB15A40D80638CEB76F18C051DEC7D19CB15A408D4C7622776F18C0C5D10B2DA1B15A40AB3A504C836F18C0A1B0D52FA2B15A40A0F99CBB5D6F18C0E7AFEB72A5B15A407205CA5CCF6E18C07F03498EAAB15A40DF49B0DDE26E18C08478C9A4ABB15A40EA12C42FAB6E18C03EAA0606B5B15A405C6B949AE26E18C09EEC6646BFB15A407274F0A7216D18C0DD4A0A87B9B15A40A4857071F96C18C0AD84EE92B8B15A40260AE35DE46C18C08D672B8AB2B15A40A5846055BD6C18C05D250E8FB3B15A40CB8B0233956C18C08E7CB9AAC7B15A40509610621D6D18C09C155113FDB15A405616E016876E18C0E939330BFEB15A40284B08B18E6E18C0FF9254A618B25A4089AB144C466F18C06DF47BAC2AB25A405456D3F5446F18C009DC5FE234B25A40295B24ED466F18C0D2B139BD41B25A40B73709EFBC6E18C06248F36C7BB25A40EF79596EC46E18C006CF296D96B25A406DF1DF72AB6E18C0BF677FFB95B25A4048F0D0C1446D18C03A854B7D8FB25A40FDEABB6C856A18C051C47D3F90B25A405CD77965286818C0D4E7B4B890B25A40188BF040AE6618C04968CBB994B25A400BE01C64486418C0BC630C079DB25A40B6A0F7C6106018C0AFB893E3A9B25A40431F2C63435F18C00551F701C8B25A40FF774485EA5E18C0C3F759C0DFB25A402C82FFAD645F18C0D350A390E4B25A40A5A31CCC266018C0F91C0E01F6B25A40081EDFDE356018C0F28178B8F8B25A409BDDFF6C506018C0A0504F1F01B35A4030DEEA94A26018C01B4C1EAA04B35A40D77F42E2C36118C0A8644A35FDB25A4052DFE819B16518C0BCE1E3B8F8B25A409B5EBDE5456918C023884E2AF5B25A4091ECB6B0136B18C05C0F1599EFB25A40A69718CBF46B18C031B5A50EF2B25A40CBB91457956D18C0F5C76AA9F2B25A40E3A029E0436E18C0D74FFF59F3B25A401E5036E50A6F18C052938554F6B25A40BB8BE6B79E6F18C0D15CA79116B35A408F19A88C7F6F18C08BE255D636B35A4062BD512B4C6F18C0FE987BED3EB35A40C054D8B1B66E18C0BF7E880D16B35A4071AC8BDB686018C01D76DF313CB35A40C4B46FEEAF5E18C0EE3F321D3AB35A40FCE1E7BF075F18C0D59A41D719B35A4071B092EA966018C0379089EF1FB35A40533CD3F0D26218C08A2F247120B35A4063CA2CE7F76218C05A91E22D21B35A4076EBEBAF0D6318C077BB5E9A22B35A4004D1EEEB1B6318C06E45AC0F35B35A40885B4FBEEA6218C0D0EC5FFE2FB35A4041C7FDFD186118C0D4E5DE0D33B35A408A0629780A6118C02BC313D536B35A40E613C31F8F6218C0640E38013CB35A404ED5986B2C6418C0825E132D54B35A401D4F7056E96318C0CF9C9A7054B35A40988B53083F6418C0E1DFB1E952B35A40C1D6B672406418C0E1DFB1E952B35A40DE6EEE54656418C09AD42BC052B35A400506FF113C6418C01813510251B35A402CBAF59A1E6418C03BA693113CB35A40435F306E596418C0B071FDBB3EB35A40240C03965C6518C0CD9B792840B35A4035A26AAADD6518C00E6EC6C441B35A40E2676D64686618C0DB1C42F053B35A404EBE34A0396618C0C1B45EC257B35A40842FA75F7D6718C0AEB6627F59B35A40D94B09771D6818C001F4A0455BB35A40C27D2E64BF6818C01D1B26BF6AB35A4040683D7C996818C00D4460F67CB35A40F3FA383F6A6818C04A6249B97BB35A40AD0F90D4E76718C0DAF7F24C79B35A40DE74CB0EF16718C08772FD1678B35A402DDCA8047A6718C0650113B875B35A4096E59079896618C0027FF8F96FB35A40E73922DFA56418C067DFCB3365B35A400167CE9FDB6018C01ADB6B416FB35A40DB4136DABB6018C015C8EC2C7AB35A40371C96067E6418C0133246DA7CB35A40E6D3BE14796518C04CC2853C82B35A40336FD575A86618C0CA37DBDC98B35A4025B1A4DC7D6E18C041B62C5F97B35A40E42CEC69876F18C08C69A67B9DB35A40E92807B3097018C0EFC682C2A0B35A409241EE224C7118C077483140A2B35A40F86EF3C6497118C0CBA2B08BA2B35A40477364E5977118C09C6C0377A0B35A407A185A9D9C7118C071F8EEA0A3B35A409C4539E2DA7218C076285481A4B35A4060C1470E227318C01F65C405A0B35A40A5DAA7E3317318C0AE7BD058A0B35A40DFED30DC6F7318C018546529A3B35A40A139A1C6737418C0A6AF8CB2A3B35A4050E4A48BA87418C020D099B4A9B35A4003081F4AB47418C0EA156069AAB35A40EB4E1CE5057518C0CCE20F50ABB35A40097BC9B5577518C067D883A4AAB35A40A724EB70747518C0F16206CFA9B35A404F2CA688C27518C050E10852A9B35A409F2F078BD47518C06E3FCF55A9B35A4059349D9D0C7618C01A868F88A9B35A40726C3D43387618C03E4569CAA9B35A406DB30CCC657618C0FC83EDCCA9B35A40F702B342917618C0BBBFD595AAB35A400518963FDF7618C00EA48B4DABB35A4061EF0FA5077718C0BA15C26AACB35A40CC1022742B7718C0073AA462ADB35A408EA2186A5E7718C0E28B9BBFAEB35A40C7CE801F7A7718C0AC753D2CAFB35A406BA56B81987718C0F4C5DE8BAFB35A4053420B64D17718C0F96871C6B0B35A4085AF54BC367818C0827A8E23B1B35A401F865627677818C02E76FBACB2B35A402BEBED85B87818C0B65906E6B2B35A4014E236BF067918C0BBB4E1B0B4B35A40A6DC3301757918C0F6227FD5B6B35A40FE124C906C7918C0E8C715CDB9B35A405698631E9E7A18C011137937BBB35A4090B3FA34387B18C00BF4E4F5BBB35A40E0D74812847B18C0F3DC8CE4BCB35A40EDCC4E50D47B18C07422669BC0B35A401D8299A5537D18C0AB2A8FC9BDB35A40E2CEE04AD17D18C04D73E1F6BAB35A40B258D471467E18C036F5CB71B8B35A407918A42AB77E18C0EAD0E979B7B35A408CCDD8E1F97E18C0DE9B95A3B6B35A40DED737E62B7F18C050430A54B5B35A40CB89D1CEC47F18C0DB3BFE66BDB35A40D97CB7D49C7F18C081D9F3EBBDB35A40E1E93AF9997F18C096653ED6C2B35A40A1702CDE7E7F18C07007EA94C7B35A402C82FFAD647F18C0CFDE7426C8B35A4061C66F65E47F18C01B53433BC8B35A40000000A0FF7F18C0000000A099B15A40000000A0FF7F18C0	0.6782000064849854	2026-06-09
486	89	0103000020E610000001000000BC0000000000004033BB5A40000000A0FF7F18C00000000000B85A40000000A0FF7F18C00000000000B85A40FE79B4BDBE6918C0C672A66414B85A40D089F326756818C024A3B90416B85A407B2304F5776818C0B05F668E1BB85A4097B32DB9406818C0BCAE5FB01BB85A406461E355316818C0A4445C4A27B85A403CE3B155386818C04B2A093F27B85A40376046674F6818C09188DF032AB85A404D542580516818C0444A58C029B85A401A868F88296918C0B6C3BA4C28B85A40B4024356B76A18C074D42C2B28B85A400AD40737BE6B18C0D55B035B25B85A407D4DC57C2F6C18C085EB51B81EB85A40C631923D426D18C0B0D293E81BB85A40A536CC2B326D18C0BDC804FC1AB85A40494E8127886D18C0299FD44D18B85A40387BB141706E18C0F6E2D58313B85A4027446568E16F18C06F22444310B85A40E95619D7097118C0B59ABF5312B85A40D9CCC6EF127118C00C5E4FCF16B85A40173FD7080E7118C076DD5B9118B85A40C2D8E7D6107118C0E4F38AA71EB85A40EE44A401176F18C0BEEEBE7424B85A405A4B5C22726D18C0E045048827B85A40C121AF624C6D18C05E5CF45F31B85A40C108D0A56E6D18C05E5CF45F31B85A40F5296CABFE6D18C0067FBF982DB85A405B858373FC6E18C0EEC627092EB85A40D2B47A3D4E6F18C0320D79BA29B85A40BC445090337018C06E5974A128B85A4088C157CFA47018C04040081225B85A403F4860BD9B7018C04DA9A67F24B85A40E378F475CF7018C015CCF33B28B85A40957C9175DD7018C09703988D29B85A40A407F478107118C0EE3C96E33AB85A40D393E81B877018C00B7E1B623CB85A4049980E42E56C18C0FC4A8C0A41B85A4006D44098806C18C070743A353CB85A40AFA01FFC7A6C18C07570557E3EB85A4059106F42C66818C0E289C51451B85A405F7AFB73D16818C0E289C51451B85A40D5DBB0B7DE6818C02DE4B62256B85A40151BF33AE26818C06FD3444456B85A40CA0688388C6818C0A89F81A243B85A40AF8E2D15656818C0F2ABDE863DB85A4096FECAEFD96718C0BCC0F6DD3EB85A40AEAFBF362C6718C0333674B33FB85A4097EC8E7BA96618C002AC9F4841B85A4008DA2E7E646418C05500E72043B85A40C1BC1127416118C02403E55B44B85A40EA077591426118C03052DE7D44B85A40899BAE82736118C0A4E3C51D4AB85A4022DE3AFF766118C0DA69B5D14AB85A408917FA168C6018C05038BBB54CB85A408DB454DE8E6018C0271B6A6F4BB85A40D34ECDE5066318C08C2B2E8E4AB85A403AA1212DDF6418C08A4798584FB85A405D0F7052E26418C089E29F6351B85A405872158BDF6418C0FFCA4A9352B85A40468E194DD36418C017974FFB52B85A40C9D3A8763C6418C0A5AABF1454B85A403FC978EF036318C09ECA0E9656B85A40D46EAAA4046318C06E5ADF7657B85A40BC41B456B46118C0328111EA58B85A40E48C17C1B56118C02691D84958B85A40BC5AEECC046318C0085E883059B85A40ABD09BE50D6318C07F32C68759B85A405618117B576318C00872F5085AB85A40FD80AC4C9D6418C0591FC5EF5CB85A40EB2928FB9D6418C0E7D374875EB85A40C293CCA0906318C010F1C5CD5FB85A40AC2A453C236318C0F8382E3E60B85A409B4649FE166318C0E6E1A9EC60B85A40A0562CD90C6318C032CFA51364B85A404AD05FE8116318C0C6D0FB1065B85A40128EB4AF976118C0C73835866FB85A40A5C05D51A56118C015F021976EB85A40345FCA65486218C0372DC25E72B85A4022084614496218C03D1BA84272B85A40D3985A00646218C05A48C0E872B85A406DFBC33B656218C0BD01C17776B85A40128EB4AF976118C099E08A7A77B85A4049AF1754656118C04C15319177B85A40D34D6210586118C0A54929E876B85A40CDE3D5DE4C6118C047A6E8ED74B85A40CDE3D5DE4C6118C047A6E8ED74B85A40CC159458086118C0368FC3607EB85A40BC8B4171116118C0B43D7AC37DB85A40B2BE81C98D6218C07F445DB57CB85A4001F50B1B0A6418C014C550F37AB85A40E78D93C2BC6718C0F783CB7479B85A406B685E69746A18C05D7AEA4779B85A4015EBAFB2116B18C09953B8D477B85A40C629841FE66C18C07B713D6590B85A4027648CB4F96C18C056C334C291B85A405AC63CE1DB6A18C014FC805193B85A4042565CC1DB6818C025613A0895B85A40526B50EA816518C0DC1ECE0D97B85A4055AD3BCC4D6218C0CF62CED8BCB85A40F62686E4646218C0DB3E9AA0BCB85A404C5BB79CA66218C0A82913C8B6B85A400C1C7519A36218C07D03931BC5B85A40028063CF9E6318C0969350FAC2B85A4086538B2DA96718C050C24CDBBFB85A4061206349146D18C0DA75CAFED4B85A401157CEDE196D18C04A9869FBD7B85A407A4DB450D76718C0F5EC5E93DAB85A4068E32DFC856318C0856C6AEA06B95A40FBA24E8AA06318C00FF7EC1406B95A40DAFA8E86F86418C04BD0BAA104B95A40F1F7E692056718C0C90B44AA03B95A408CF84ECC7A6918C0647A1DCC01B95A409983A0A3556D18C045E2D4BD04B95A40AF777FBC576D18C086D162DF04B95A40B5FAEAAA406D18C0871FF70810B95A40A57098C3496D18C0278AEB7310B95A402C5B90D2116D18C0E8F4616218B95A4071372D1D186D18C0CAADA47018B95A40DD0C9299666D18C0F10005CD1DB95A4089A6A267696D18C02687F4801EB95A4055E87239146C18C0D88AEC391FB95A4000F9B770C56A18C0737A281B20B95A409E735C32336818C0E20FF57123B95A40FDFFEED3A76318C09D4CDC2A88B95A402CB6EE8BF06318C09FD623C3E0B95A40F2C7597D1A6418C0660AE764F3B95A40A86851442B6418C061F426D0F1B95A4088C90A348E6718C0F601EDB3EFB95A4034AF343A316D18C0C1EE2A5AEFB95A402FE12B15AF6D18C0660AE764F3B95A402946F185246E18C07418DD8BF9B95A40A6F8533E5F6E18C088951B5602BA5A40A15BF9765C6E18C0F2A1FABD03BA5A40683CB60A076F18C075FCBC4E0FBA5A40ABF875960F6F18C04B1E4FCB0FBA5A4058AD4CF8A56E18C086E8103812BA5A40E42F2DEA936C18C0BF982D5915BA5A40C634D3BD4E6A18C0965F066344BA5A400A117008556A18C02AA913D044BA5A4041295AB9176818C03788D68A36BA5A40D0471971016818C0C72E51BD35BA5A4053CF8250DE6718C09BE271512DBA5A40AE8218E8DA6718C0EF5696E82CBA5A401FBB0B94146818C088D860E124BA5A40FD4CBD6E116818C0890CAB7823BA5A40DC0E0D8B516718C01B834E081DBA5A4076C4211B486718C0AA29C93A1CBA5A4072C3EFA65B6618C074EE76BD34BA5A40C34483143C6518C001193A7650BA5A40E6B2D1393F6518C04A7EC4AF58BA5A40520C9068026518C0833463D174BA5A4047CCECF3186518C07825C9737DBA5A40349F73B7EB6518C0C156091687BA5A403F36C98FF86518C063D34A2190BA5A400821205F426518C0CB85CABF96BA5A400821205F426518C0C6C1A563CEBA5A409BC761307F6518C09C871398CEBA5A40D2CD59FA2B6718C0A2FF2FE8CEBA5A4044FAEDEBC06918C0371B2B31CFBA5A408BF9B9A1296B18C0A794D74AE8BA5A407B6B60AB046B18C0558847E2E5BA5A40FEB8FDF2C96A18C0C6E1CCAFE6BA5A405FD218ADA36A18C0349F73B7EBBA5A406A12BC218D6A18C09C51F355F2BA5A405F7B6649806A18C09AB51490F6BA5A40D7C22CB4736A18C0406A1327F7BA5A40431CEBE2366A18C00C772E8CF4BA5A40AFCC5B751D6A18C061B2A7D3F0BA5A40E3E4D940156A18C087DF4DB7ECBA5A4082C7B7770D6A18C0A8C821E2E6BA5A40B075A911FA6918C093567C43E1BA5A40B6DB2E34D76918C0D0F0660DDEBA5A40E998F38C7D6918C07C7C4276DEBA5A401E34BBEEAD6818C0B16F2711E1BA5A40580053060E6818C056BC9179E4BA5A40E8A562635E6718C08813984EEBBA5A40B090B932A86618C086AB0320EEBA5A40C6BE64E3C16618C09D853DEDF0BA5A40CC46E7FC146718C07DD0B359F5BA5A405F96766A2E6718C08FA67A32FFBA5A403D2828452B6718C09B3DD00A0CBB5A40CC46E7FC146718C08D2AC3B81BBB5A402D095053CB6618C0639AE95E27BB5A401C412AC58E6618C05AF3E32F2DBB5A40C136E2C96E6618C00000004033BB5A40C136E2C96E6618C00000004033BB5A40000000A0FF7F18C0	0.8143999576568604	2026-06-09
487	89	0103000020E610000001000000AB0000000000002033BB5A40000000A0FF7F18C00000002033BB5A40C136E2C96E6618C0C009850838BB5A40C136E2C96E6618C02788BA0F40BB5A40B69F8CF1616618C01C7920B248BB5A404BCD1E68056618C0E71DA7E848BB5A40790261A7586518C0C904FC1A49BB5A403B35971B0C6518C03A92CB7F48BB5A4086200725CC6418C057772CB649BB5A408C2FDAE3856418C02F4FE78A52BB5A40ED48F59D5F6418C0CD203EB063BB5A40F91400E3196418C0DB9B29BE6BBB5A40FD5AA846F96318C0A5F3E15982BB5A406BF12900C66318C0E415889E94BB5A405A290472896318C0E08442049CBB5A4089F7D2CA736318C07319EDA7B5BB5A4045C07C0D1C6318C0ACAC6D8AC7BB5A4096F8927CDB6218C01DB34703D3BB5A403C61D394AE6218C079E51F22DABB5A40080F89319F6218C01D740987DEBB5A40C2120F289B6218C05133A48AE2BB5A40C8091346B36218C0BEBC00FBE8BB5A4023145B41D36218C017D7F84CF6BB5A40894160E5D06218C03106D671FCBB5A4073309B00C36218C0C51EDAC70ABC5A40FF756EDA8C6318C08B8BA37213BC5A4060AC6F60726318C026C632FD12BC5A406C956071386318C08BC22E8A1EBC5A4061C43E01146318C0EE05668522BC5A409DA04D0E9F6418C0D714C8EC2CBC5A4036E7E099D06418C0B63176C24BBC5A40A27A6B60AB6418C00C01C0B167BC5A407BDB4C85786418C08856DDD98DBC5A409EE9CA0CC06318C0F583BA48A1BC5A40E4A25A44146318C0F2AE1F07CABC5A40BD76C47CD46218C0C3E80313C9BC5A409CACACC8436218C0F349DD84B1BC5A404746BD96466218C0ED331DF0AFBC5A4024C852358B6118C0C7D5C8AEB4BC5A401E5EC603806118C0AF905E79B5BC5A40B3B85A82E76118C08FB40A51F4BC5A4085025BCA9E6118C0B52C04DEEEBC5A40217E5935635C18C02995F084DEBC5A4027E8E5666E5C18C059A65F22DEBC5A4017409D972F5C18C0ED5575A018BD5A4036D6B441DC5B18C09360600C1BBD5A405A8121AB5B5D18C068098DBB1CBD5A40ED0676A15E5D18C01419671D1FBD5A40F7459D14415F18C04FCFBBB120BD5A40CFD8976C3C6018C0421E66D421BD5A40643C4A253C6118C0D8DBC1E336BD5A40B8F5E4AB2E6118C078FEFEDE37BD5A40C733C3A1126218C011830A583CBD5A40FC8804F8136218C07BA6F2D13DBD5A40E3FC4D28446018C03E3DB66540BD5A4061AEA0C4426018C00F18DAEF3FBD5A4081F167D36C6118C0785270C24EBD5A406C521BE6156118C0E88E59515EBD5A4052860552BD6018C00B79A97D5FBD5A40C30C8D27826018C051F1248E61BD5A40C3B1D3B4306018C0CEB348C961BD5A401321BFC8156018C0E49B12B559BD5A40C07EE3C6885F18C05A3C06755BBD5A4085A22F73705F18C07AE063B062BD5A40F20B0ADEEB5F18C05C2041F163BD5A40D0F0660DDE5F18C0EA33B10A65BD5A400FDA0649FA5F18C0B267CF656ABD5A40F511F8C3CF5F18C057410C746DBD5A40D776C9EEB85F18C04C74F11277BD5A40D20B2DA1715F18C08BF5B2927BBD5A40E9A85956505F18C089E30A3980BD5A4000D6F4EA2D5F18C0B0DA464D85BD5A4026BDB909085F18C0E47107A087BD5A40D4997B48F85E18C07162FEC08BBD5A407FBCFCF3D95E18C0A09EE3488CBD5A40CA051D63DD5E18C0DBF813958DBD5A40A07DF66DD25E18C0D5F3249F8DBD5A4024B6BB07E85E18C03A43CC808EBD5A408813984EEB5E18C0BC4C5EAE8FBD5A4063B83A00E25E18C02C7299E491BD5A40E219D93ADD5E18C0F0F1536694BD5A4007C8E1DDDB5E18C0BFDD488F95BD5A40A24A28D8DA5E18C007BBBC9495BD5A40524BCEE4F65E18C01416269D92BD5A401B4641F0F85E18C0EC713A2490BD5A40D3E92FAAFB5E18C0BD1E4C8A8FBD5A40C959D8D30E5F18C099E9A8B48FBD5A406433D131315F18C01578825891BD5A40A9BCC227425F18C0855B3E9292BD5A405169C4CC3E5F18C092B64CE19CBD5A40EE974F560C5F18C0CD1319679DBD5A4043C879FF1F5F18C01E45E746A2BD5A40BBF2599E075F18C06A076D83A4BD5A405A8A9A9E665F18C01C1FD214A6BD5A40A7F79EDB955F18C0C8A71144A7BD5A4047A4B789A45F18C0D923D40CA9BD5A407DA9447EA25F18C0730DD87AABBD5A409C7D2FCF945F18C0535E865AAEBD5A40641EF983815F18C0CA011654AFBD5A40D738F647735F18C05F06088BAFBD5A4041560108695F18C04CC3F011B1BD5A40A0F99CBB5D5F18C0DF2EA0BCB4BD5A40508FC8D2E25F18C050E449D2B5BD5A40AF6C301EEF5F18C0E97129F8B7BD5A40F8020EFC036018C0104C2487BEBD5A401E7A41FADC5F18C021866753BFBD5A400A73710AE15F18C0A9ABF188C0BD5A405D63E135F95F18C0074C9649C3BD5A4007DD1445FE5F18C050C2F121CDBD5A4040B2CA96F65F18C0BD00FBE8D4BD5A406EB36785D85F18C0E6F8B2FEE0BD5A409AE6C2ED755F18C090D14BD6F2BD5A40843B61D3945E18C04AFBD5D212BE5A403629BB4F445D18C0F98AC97619BE5A4073EB7FCA425D18C0DB5A159719BE5A403C94579D8B5D18C0BEFFEACC18BE5A408C2B2E8ECA5D18C06C38769A16BE5A4042CC2555DB5D18C0B407B53A14BE5A40A239FC7FE65D18C0E404B7FF12BE5A40751F80D4265E18C062B36D6212BE5A408DC8C1B68F5E18C0E0089CB610BE5A40E2CB4411525F18C075FCBC4E0FBE5A406C2002B3E75F18C0AB5AD2510EBE5A40F3C06CA7526018C0B07092E60FBE5A400618F1F8516018C029965B5A0DBE5A406C5A2904726118C00A18B8970FBE5A403E5A9C31CC6118C09725F03D12BE5A4073EDB02E136218C09DB415A012BE5A40FA3372CC686218C0856C0F3114BE5A4063C625D8C96218C0B68C2F351DBE5A40A8DB7E9EAB6218C0E85C9BD722BE5A40BCA882F68F6218C0B7C94D7919BE5A40A1359AB7456418C0F39947591ABE5A4036DFD27B746418C0A55BC0151ABE5A40B2913534AF6418C03BDCB35318BE5A40D4731C89E16418C0B88A6AB617BE5A40F65503DE136518C01E0E5C2F17BE5A40D9DEB8D6286518C0B9173D5C17BE5A4069CFC023856518C0D15CA79116BE5A403CB54478C56518C0D5CBEF3419BE5A405D972BCDF76518C040D8CE9C1ABE5A409654127E4E6618C0C20F73EE1BBE5A40C9A76CFD996618C0F39947591ABE5A408680327CFA6618C02397491E19BE5A403685DF97446718C01893A3A517BE5A4053E34AE2516718C08FFAEB1516BE5A4026FB8CB04D6718C0B9EF62AB15BE5A405EEA31DB5F6718C0A9177C9A13BE5A403CEF6BC94F6718C043215DC713BE5A4074F7EFB03F6718C0017F42870ABE5A40230A7778196718C08F2D156500BE5A40D04F278F5D6818C040A19E3E02BE5A40A945E977066A18C0F2B803D003BE5A4068C240214C6B18C02123FB7B04BE5A408C43A275F96B18C00A12DBDD03BE5A40BC218D0A9C6C18C05070B1A206BE5A4089D2DEE00B7318C044DC9C4A06BE5A404371C79BFC7618C0BC40498105BE5A400A9DD7D8257A18C085B1852007BE5A4075AE2825047B18C085B1852007BE5A40C4CF7F0F5E7B18C0F16778B306BE5A40304B3B35977B18C0A9A10DC006BE5A4062BB7B80EE7B18C0D925AAB706BE5A400C906802457C18C07A1D71C806BE5A40999B6F44F77C18C07A1D71C806BE5A407C0C569C6A7D18C062DBA2CC06BE5A40D1419770E87D18C04A99D4D006BE5A401F80D4264E7E18C0D34ECDE506BE5A4085ECBC8DCD7E18C01A1538D906BE5A4062DA37F7577F18C01F9D2D2A07BE5A40000000A0FF7F18C00000002033BB5A40000000A0FF7F18C0	0.8145999908447266	2026-06-09
488	89	0103000020E610000001000000050200000000000000B85A40000000A0FF7F18C0000000C0CCB45A40000000A0FF7F18C0000000C0CCB45A4024A6A75CB87618C093C49272F7B45A4054FF2092217718C006BD378600B55A40D5CA845FEA7718C0E5B9BE0F07B55A4075CB0EF10F7B18C05DD1F7640FB55A407F8461C0927B18C084B12A6714B55A40510C35AF8F7B18C07B46C77A0FB55A407E1D3867447918C0B03FE48810B55A407E1D3867447918C05798BED710B55A40EB44381C4C7918C01F48DE3914B55A40D351691F867918C0D2EFB1AA14B55A4079680EFF9F7918C03773A32314B55A40DAA21694B37918C074D9435612B55A40C832B385D67918C0AEE820F914B55A404569CAA9F87A18C09B2CA4B217B55A402288F370027B18C00EA4E6061EB55A4035DF77C2017B18C066811BCE21B55A40129B34B2D07B18C0D5FC42D925B55A408AE2FA1CC47B18C050E1085229B55A4051F4650EEE7B18C0F266C3503DB55A40B1602C1DBD7B18C07838CB764FB55A407FF4F2E0937B18C0F1AB281458B55A4089FBD9D9A17B18C0BC00A02F62B55A40FBBF3456AC7B18C032E94A5F63B55A40C9096EFF257C18C0FB986AC166B55A400C00FA22467C18C0416A6EE069B55A4089B14CBF447C18C082CC295C6AB55A4067D075864E7C18C0D09783456AB55A40D894D002597C18C0F42BE79C69B55A40CE740A4D6D7C18C01D63DD2E6AB55A406D2123FB7B7C18C052CF27976BB55A40F6D95C90887C18C0C8B7D2C66CB55A408A7F8E45897C18C04EAE731D74B55A4023C21AC28C7C18C0056C072376B55A4046A3F1FA827C18C0E14AD12577B55A400CE71A66687C18C022AD8CA177B55A40A60FB809527C18C0999537D178B55A4067D075864E7C18C01B5AAEC879B55A401D716D4D5F7C18C0517CC6CF90B55A4018D412865C7C18C0A46C36FBA8B55A406D3A02B8597C18C05BB79CA6AAB55A40A60FB809527C18C0DE7B139EABB55A401E577E74457C18C06C1C565DACB55A408F34B8AD2D7C18C0FBBC981CADB55A40624CFA7B297C18C0895DDBDBADB55A405CE26D4A1E7C18C06026E549ADB55A40DF162CD5057C18C06C8F83B7ACB55A4095D00259F47B18C0BA5ADDA0ACB55A40E5B27680CC7B18C03C9281F2ADB55A402F127FB9BB7B18C04D840D4FAFB55A40EFD23C36B87B18C01C6D663EB1B55A4046065ED2BD7B18C016A75A0BB3B55A40DF48EA4EC17B18C0A4BACA24B4B55A4006C71B4FBA7B18C01AA37554B5B55A40D8DE5D1DB67B18C05B785E2AB6B55A40012AC187B77B18C0DE3CD521B7B55A402F127FB9BB7B18C0FB7D5AA0B8B55A40A1D6D935C67B18C07ECFA33DB9B55A40357C0BEBC67B18C024287E8CB9B55A4084786EEBB87B18C08E345DF4BAB55A40C2EA7E04B47B18C0C42D7A02BCB55A40BD4D243DB17B18C05241EA1BBDB55A40E4CB553DAA7B18C04CF443B6BDB55A4018714BF5AE7B18C01CE3D418BEB55A40DFBB7262B47B18C081ED60C4BEB55A40B1602C1DBD7B18C0FEAF84FFBEB55A4062B77471C07B18C0DF7C34E6BFB55A40FC19DEACC17B18C083A62556C6B55A40A1D6D935C67B18C01270630EDDB55A404C70EA03C97B18C067DC2FFAE5B55A40E5B27680CC7B18C0BD12EDCFEAB55A40845F8F2EDB7B18C0DFDC5F3DEEB55A40230CA8DCE97B18C015634FF1EEB55A40C9224DBC037C18C0D8898164F0B55A406C6CC031157C18C0781C5080F2B55A40BD1C76DF317C18C0955DD5FEF3B55A4022F4D83B487C18C0295F2BFCF4B55A4028EBDC59607C18C06560D339F5B55A40D97BF1457B7C18C0D6A5EB2EF5B55A402F23AB11B07C18C089810937F4B55A40231DD434DE7C18C0AD156D8EF3B55A401220F939F47C18C0722E6A9CF2B55A40EA2E3F26087D18C0F1CEEB99EFB55A4094C95F10477D18C0E5CA4521EEB55A40615E36F0597D18C05E0AB4E0EAB55A40345D9901787D18C06C651DE9E7B55A40B19B638A837D18C0A9A3E36AE4B55A40B028DB76907D18C03A9BE9B9E0B55A4012D66B1F977D18C0F99D2633DEB55A40673C5B51947D18C06601C92ADBB55A409597A1968B7D18C056010869D7B55A4028E329F5767D18C0DA441CA1D5B55A40D322916C647D18C01222CFE4D1B55A40A620E461467D18C072022E23D0B55A4013EE3AC0387D18C0B96C74CECFB55A4073CE99FE367D18C01A4DD30CCEB55A400774CBB3377D18C08C2B2E8ECAB55A404B6947BB1B7D18C00B598231C7B55A40D9A4EC3E117D18C07DB83F72C6B55A40B6508DF2277D18C03DBB7CEBC3B55A403402E08E267D18C002AC9F48C1B55A40061A225D227D18C0E1FBD126BDB55A404B6947BB1B7D18C0BDB2C178BCB55A40894FF003467D18C0823EECE0BBB55A40F590DF91677D18C047E4BB94BAB55A40EA7019DC7B7D18C08AAB6F05B9B55A40F590DF91677D18C0618E1EBFB7B55A402E6695E35F7D18C0C6843D92B7B55A402EF30CD06C7D18C0BAA871CAB7B55A40EA7019DC7B7D18C0BA1B9F24B8B55A4061D2CE1F897D18C05A136635B8B55A40A09E888F997D18C0E3C5C210B9B55A407E8AE3C0AB7D18C02A166470B9B55A403F32C280CA7D18C0249BABE6B9B55A4001344A97FE7D18C006F52D73BAB55A408F56105E167E18C0BE3F941EBCB55A406D5C5A68427E18C086EFB380BFB55A406C5D6A847E7E18C00DB045C1C2B55A4084ABF2F3957E18C0C9772975C9B55A40B6172C30BF7E18C0564046E5CBB55A4045AD7A0ACA7E18C09B3924B5D0B55A40FB66518EB87E18C07718EEB7D1B55A40774B72C0AE7E18C03B3F202BD3B55A408EB2D9ECA37E18C02ED681BDD3B55A40774B72C0AE7E18C01BA7D71CD6B55A400BF1A375AF7E18C08626E4DED7B55A4027F56569A77E18C02B1AC638DAB55A402D78D157907E18C0017ED7B1DBB55A40BC26FFEE787E18C0659CD035DDB55A40784A62A4727E18C00A03E0E9DFB55A40F6FBB440717E18C0A41AF67BE2B55A40B11F18F66A7E18C068CEFA94E3B55A4033FB3C46797E18C06C651DE9E7B55A40AB2924F48E7E18C0F913950DEBB55A4061CA1BBB9F7E18C08AE6012CF2B55A404B49C5B5907E18C0BD152E50F7B55A4017F77A52817E18C0C9642772F7B55A4028F4554D6B7E18C0B70DA320F8B55A40BC3FDEAB567E18C02D8320F6F8B55A40CCC930934D7E18C045C88A2BF8B55A40626E522C127E18C0CA56F20CF5B55A4028B27B97F77D18C095D00259F4B55A409B75C6F7C57D18C071AFCC5BF5B55A408481E7DEC37D18C05E8022BBF7B55A4078C59D1C4F7D18C045C88A2BF8B55A40FA2C2A3D2E7D18C05117844DF8B55A40735A01CF077D18C0B4B6DF90FCB55A40067D8E345D7C18C0135A208BFEB55A40FB8E86F82C7C18C0EE38EA8DFFB55A40D41055F8337C18C029D599D601B65A40EA36F28AF17B18C01335875A09B65A40357C0BEBC67B18C01335875A09B65A4029A8F287B07B18C083667C0423B65A4079A235502A7B18C036035C902DB65A4018810C78F47A18C0C76D8F392AB65A40A182C30B227A18C00B8F47BA30B65A40901150E1087A18C0758181D632B65A408FE1B19FC57A18C0D8ADAFBF36B65A40FB22A12DE77A18C06CD7DF6D39B65A4084C2FB05167B18C017B9A7AB3BB65A40236F14B4247B18C0ECB7C02F3FB65A40B7144669257B18C0177A692F47B65A402288F370027B18C0044BBF8E49B65A40894567F4FE7A18C009D4AC7D4BB65A40735188DBFC7A18C07F2F85074DB65A40246E0498E87A18C043E389204EB65A40B82C150AC77A18C054BB703150B65A40EF4D78AE947A18C024BE6E6C51B65A40C8E8256B797A18C0E25BB3F050B65A40B876A224247A18C0C84C58D155B65A40345BC3561A7A18C0C84C58D155B65A40EAFBBA1D2B7A18C06C4E6F905AB65A40B876A224247A18C0FB61DFA95BB65A40EAE2DB604D7A18C00CC798605DB65A40739B15F6597A18C0DC5669415EB65A401E3526C45C7A18C09F7D9BB45FB65A409CE678605B7A18C0C80D1A5561B65A402A221EE4507A18C05CC41CA963B65A401E4E05813A7A18C06D9C03BA65B65A405723BBD2327A18C063658FAB6CB65A401D67E43D187A18C0D9C067356EB65A40345BC3561A7A18C0910BCEE06FB65A40C800F50B1B7A18C03111CA5672B65A40D98A47F3117A18C0059DB58075B65A4067C6EC76077A18C050F7A68E7AB65A40CE9C3FB7E17918C0D348F02B7BB65A40EB138ABECC7918C06DC5FEB27BB65A4024021FCDA27918C014ABABA77BB65A40D9BBF550917918C0F3BB9F0983B65A40F0C8B326717918C0B6C82C3185B65A40EA2C697BAA7918C0D309B2AF86B65A40C3AE377BB17918C0B48B0EED88B65A40E68F0EB4A77918C02DFF6B8A91B65A40231BFE89807918C01E59AFD895B65A407A67FEE2637918C0EC04EA839BB65A40A7689BD1457918C032D6EDA29EB65A405C227255347918C07338A91E9FB65A4089230F44167918C002D9EBDD9FB65A402E6C729DEB7818C0C5FF1D51A1B65A407E350708E67818C018C79283A3B65A40569F06674B7918C06A1BDA5BA5B65A40234DBC033C7918C0214C9BBBA7B65A40C3DFE5D8307918C01F436C55B7B65A40D4CB947B267818C03C84F1D3B8B65A40C9DD8C3FF67718C08E4B6606BBB65A40EBF1310EE47718C01B22B8DBBFB65A4095A42199C47718C00A9865F4C8B65A4023F9A5D9977718C01B704C05CBB65A4024E0C61CBA7718C085EF58C7CCB65A40346A1904B17718C0A3BDB0EBCDB65A40ACCABE2B827718C0C0FE356ACFB65A400E04B7A4597718C0B81E85EBD1B65A4096D5CFF6437718C0106FE70CD6B65A40416FE0C4467718C092A68B5ED7B65A40567DAEB6627718C0088F368ED8B65A4096BCF039667718C049641F64D9B65A40EB22E06B637718C0F55F8CEDDAB65A40A0DCB6EF517718C0C04CCA93DAB65A40EB3BBF28417718C03D88539CD9B65A40A0F595AC2F7718C0CB50700CDCB65A4079904369147718C095D8B5BDDDB65A4018C9C3E7F37618C0C470BF8DDEB65A40412D060FD37618C046353685DFB65A4012EB9E86B97618C0877D4CB5E0B65A40E5756968A87618C05D6E30D4E1B65A40363FFED2A27618C0CDF5C7C5E2B65A40BEF73768AF7618C0C18C2958E3B65A40CE0E023CB37618C050BA3EBDE3B65A40A026440AAF7618C03D772744E5B65A402A5206B3AE7618C06694788AE6B65A407A1B9B1DA97618C01ECB715DE7B65A40C9C452C9A57618C0118AADA0E9B65A40F008B831877618C0342C465DEBB65A4052CF27976B7618C0675B7281F0B65A4090E67E3D157618C0607BC102F3B65A4007472465E67518C0B2423635F5B65A40AC8F87BEBB7518C0CF108E59F6B65A40A1A17F828B7518C0BE912F57F5B65A40A724EB70747518C07DBC4681F4B65A40010E46915A7518C0A150AAD8F3B65A409C36E334447518C048C32973F3B65A403AFCDA9F307518C0E2B26554F4B65A40C3CDF3F11A7518C04D4C1762F5B65A409148DBF8137518C0931D1B81F8B65A40F1283A37127518C04D327216F6B65A40FDBA78E4B47418C02B82A4F4F1B65A40AC23A2F3757418C09F3825C5ECB65A402384471B477418C009DDCAB7E3B65A40A04E7974237418C017105A0FDFB65A4062DC685B287418C08400CFACDBB65A409BCB0D863A7418C0C2A38D23D6B65A40196481655B7418C0C4FA50B3D1B65A40AC23A2F3757418C02C62D861CCB65A404197152FBB7418C00F07AE97CBB65A405E0E6036A67418C0C2E2CB9FCAB65A408FAC57EC8A7418C0F2DFCD64C9B65A401FCE0D97667418C0E1606F62C8B65A4063C3899E4A7418C0D0155BF7C5B65A40B742588D257418C0A76B370BC5B65A40526BF5300F7418C0D76839D0C3B65A40DA3C0E83F97318C0253493B9C3B65A40790206EEE57318C0A2E2491CC3B65A40A7D0D446D07318C0D2DF4BE1C1B65A405D8AABCABE7318C038633D5AC1B65A40ADA6EB89AE7318C0B5B2333BC1B65A404C1938A0A57318C09DE62ED3C0B65A408421BC87957318C0B62B9908C0B65A40CE80C4C0847318C027FE83A3BFB65A40A27E17B6667318C0B59EC662C0B65A405DBB59283E7318C06D5C5A68C2B65A40D41BFF4F0F7318C055A4C2D8C2B65A40F62FA41EFD7218C061808EA0C2B65A40846B49A2F27218C085A1C49DC1B65A40B33918FBDC7218C063D75130BEB65A40E6A4411BCA7218C09461269BBCB65A40A2C8A4D0C37218C06AB702AFBBB65A40C946D6D0BC7218C0DCA39295BAB65A40EA5A7B9FAA7218C000C5C892B9B65A40A764EF7B8A7218C0A71DA3E1B9B65A404CAD52D55F7218C08F650B52BAB65A40AD003A27517218C0E19FADDEBCB65A40455CA560327218C02E51627CBDB65A40683D7C99287218C0F2046795BEB65A4078E0AD3DFD7118C0985D41E4BEB65A40F02774A8F07118C0B62B9908C0B65A400635327ED07118C020ABA5CAC1B65A40081B43A5B67118C07E4EE6C4C3B65A40FB462A42A07118C0B3D4D578C4B65A405C9A1194917118C0241AEE6DC4B65A40E46B2AE67B7118C0FBFC9C27C3B65A400DD06C0D5B7118C061808EA0C2B65A40D97D22AA4B7118C0BA9AE1ABC2B65A40D4F9A69F267118C0E3B732F2C3B65A40566133C0057118C0EF20D15FC3B65A40DA95F14AED7018C0253493B9C3B65A4096B95400E77018C08FB39F7BC5B65A40EB1F4432E47018C05FB69DB6C6B65A40E0185D39D67018C0E17A14AEC7B65A40ACC612D6C67018C0A08B868CC7B65A4034982B28B17018C07E294D94CEB65A402A91442FA37018C08894B080D3B65A406199C816937018C0BB50AF4AD8B65A402F14B01D8C7018C00D8B51D7DAB65A403A3476D3777018C03B31900CDEB65A402F2D8FDA697018C09281F22DE2B65A4012B644D37E7018C00B822271EAB65A40F13F4349927118C09DA27E72EFB65A406C94F59B897118C011C1DDFE01B75A4051AC0958617118C0717CA30C0BB75A40067FBF982D7118C0CA7F924C18B75A40DD2B4E10D07018C0F9179C1C19B75A4045099F52CA7018C0E15F048D19B75A4079420AF9FB7018C05F9B8D9518B75A40A1A75C3C177118C06D3656621EB75A4073B0485D7C7318C0AF9811DE1EB75A40353E3844817318C08A77DBE01FB75A40CF1C48CD0D7418C085611B4C1EB75A40FD0406FF117418C06656A5E320B75A402A59A9FB5B7518C06EF717E629B75A4089DF5EE3447518C0E4DFC2152BB75A403BE3FBE2527518C0E42D573F36B75A40E695EB6D337518C09ECF807A33B75A404597DCCDF87318C0BB9DD89E34B75A402EA3FDB4F67318C0C099F3E736B75A401833D307DC7418C09F20B1DD3DB75A40733914F4CD7418C04AFC40A841B75A405F155E38C67418C0C6FD47A643B75A40F1CD80C4C07418C04F88CAD042B75A40C317810C787418C01A02DB1C42B75A40DF8ECB13637418C0973D642541B75A40A79F26E9507418C032D417F840B75A4002898109377418C07F129F3B41B75A40467EFD101B7418C0B40BBC4942B75A406EE23F38FA7318C0F66D77C542B75A402FA2ED98BA7318C0DEB5DF3543B75A40E55BC41CA97318C06CC94F4F44B75A40295140248D7318C0EF1A99EC44B75A400105CD9D4F7318C0D1BF6E2244B75A40DAB749FBD57218C0BE90C48146B75A40EA5A7B9FAA7218C0A48169624BB75A4024480092447218C018867E5C51B75A404BF8EF0BF97118C0AB22DC6454B75A40A7C75B53C57118C0EC8497E054B75A40DA328573B27118C0E1359EBE54B75A40E0B5F0619B7118C03370404B57B75A40C9DAF005777118C068695D5958B75A408B81BFA9597118C0B8D90EFC5EB75A40C9F3CFC2547118C0832E861769B75A4068D196CEE27018C0D56828A46BB75A40BE3676E4A37018C020DDBEFD6FB75A404C8BFA24777018C07A45A6327BB75A405D2D1CAD0F7018C0F669CB6F87B75A40BDCBA0359A6F18C08A93FB1D8AB75A4051161978496F18C04C55359C8DB75A409B1B785A236F18C06C3B12D495B75A40ACBD99E2BB6E18C0F2F2CF679BB75A40FBD5D2927D6E18C0AB949EE9A5B75A40F6662F36086E18C08F2E803AAFB75A40B6589B10846D18C0C81D801EB4B75A408375D2B1396D18C085F70B2CB6B75A40B106DE7F1A6D18C0C48FD6BDBAB75A4055682096CD6C18C099011D9CBEB75A40E5A2B5FD866C18C04470B77FC0B75A40F0A88CDA586C18C04EF5BFB7C4B75A40235F5331DF6B18C00B653CA5DEB75A40D310FA3EC16A18C09509641BDDB75A404A0E338F576B18C0DEB0C80AD9B75A403909A52F846C18C0A9B17389D9B75A40407331618F6C18C026016A6AD9B75A407982B34A9F6C18C026EDFC91D8B75A40B2E4E088A46C18C00E21F829D8B75A40DE93E23ECD6C18C0732B84D5D8B75A40B0389CF9D56C18C03E46D49FD8B75A40EA471EE3E56C18C00FAECACFD7B75A404BF5AE8BEC6C18C0450CE0D2D6B75A40EA4F2C01426D18C0059CEFF1D3B75A40D4298F6E846D18C0BED82038D3B75A40229A8A9EA56D18C04CEC9051D4B75A40508248D0A96D18C095BBCFF1D1B75A4029BA89B5536E18C02F38DE78D2B75A40358EA2186A6E18C02FF3C242D2B75A40BB0622307B6E18C08FA50F5DD0B75A40FB6E5FAC146F18C0FE367AEBB2B75A405140248D1B7018C03765B84BACB75A4088669E5C537018C0F7BF6DB76EB75A40F67931395A7218C0960F9C8E5BB75A4095DCBCCC0B7318C0AEE1D8695AB75A40137530AC2C7318C06D7F1DEE59B75A40CF7FB4A4487318C0376C5B9459B75A4090279364677318C01465CAE259B75A40CE80C4C0847318C0DEDEDA2E59B75A408421BC87957318C0503E986F58B75A405283C4D1B07318C00300112C58B75A40C8E47915BE7318C04462CCA758B75A400DC11660C47318C091A053EB58B75A406EFB1EF5D77318C091A053EB58B75A40E61027E60F7418C00FDCDCF357B75A404CE88942267418C08C1766FC56B75A406760E4654D7418C0A45CD03156B75A40C3FEA14F9A7418C0F10D85CF56B75A404BB7DBE4A67418C0D955ED3F57B75A40EB4A15D6D77418C0D955ED3F57B75A405CF7A0B1407518C04462CCA758B75A40A724EB70747518C0F609A01859B75A407A0A6FC5B47518C02C1D627259B75A40A256E24BF27518C05C8D919158B75A4062FEC00B117618C02794748357B75A4035CC75BFAF7618C04348275C59B75A402F490AD1C67618C04348275C59B75A40C872B790EC7618C02C1D627259B75A40B1039DFF0D7818C02B908FCC59B75A40B80ABD59DE7818C014AD815259B75A40ADDA3521AD7918C0A9CB18D558B75A4023B9A1CE817A18C05C8D919158B75A4029F27FA20D7B18C003BE912F57B75A403AC2B34EA67B18C0DF7426C863B75A40B4D194F8377B18C025AE635C71B75A40CD898741AA7A18C09EC25B316DB75A409F0C44053D7A18C010AFEB176CB75A40F48B12F4177A18C04C88B9A46AB75A40051555BFD27918C09A53138E6AB75A409F888F99557918C04535DBCB6CB75A400BC96E0B3B7918C0820EA9586BB75A40B011D264107918C059F157126AB75A401165B9B6017918C0B20BAB1D6AB75A40825BD2ACC77818C01702CAF069B75A40278B5649BF7818C01702CAF069B75A407DD756A2A27818C07632DD906BB75A40C7365FDB917818C004464DAA6CB75A40288A462D837818C058D7B2C66AB75A405B0E4F0A4E7818C03F47F5E76CB75A40D865F84F377818C0876FBC966BB75A4072A774B0FE7718C035A8476469B75A4011548D5E0D7818C0B370A31268B75A40EAD55B5E147818C0A721AAF067B75A4095884BE9F47718C03C88F8E266B75A40EF71A609DB7718C061A92EE065B75A4006668522DD7718C01F47736465B75A4012537D42D17718C005AB459F6AB75A400B02D0CDA37718C07797D58569B75A404B5AF10D857718C0F45F313468B75A4089E5E0E35D7718C0F777B6476FB75A40BC69E9C0287718C0801CDEBD6DB75A407222B028DB7618C0E3E0D23167B75A40FBC10A010A7718C0A20BEA5B66B75A40BB82C87D067718C0BA50549165B75A40EFEDF19DF37618C06889DF5E63B75A40EFEDF19DF37618C0AFD980BE63B75A40BBCC5598637618C00D7DC1B865B75A40A4D8767F617618C02535594865B75A408E70FF36307618C03E07962364B75A40CEAF41BA337618C08B451D6764B75A40B0C56E9F557618C03E6656A563B75A40611CB7F3587618C0096D399762B75A402878AFFFDF7518C0F127CF6163B75A408F352383DC7518C00E83F92B64B75A402946F185247618C0F63D8FF664B75A402946F185247618C01A5FC5F363B75A4066039FD5B87518C03EF3284B63B75A406166440EB67518C02D019DEE61B75A403FCFFAEF1C7518C0B0C513E662B75A4028DB1BD71A7518C0096D399762B75A401019FB37D47418C02D8E6F9461B75A4077D66EBBD07418C0FD039B2963B75A40729D90E7447418C052FD39BB6BB75A403F4A3668F97318C093D222916CB75A4067AF88AB147418C02432625573B75A40EAFC25F3D97318C0B3D2A41474B75A409FB6FC76C87318C02E443D3377B75A4023EBBA01B07318C0EAFDEB817BB75A40338EECA5847318C0C90EE0E382B75A4072FFECA2437318C0F7B41E1986B75A40C77EBB911E7318C01469D1F187B75A401DCBBBEA017318C006C314408CB75A40D807FE5CD97218C088FAB8918DB75A40F56569A7E67218C06182BF0493B75A40016C4084B87218C02C89A2F691B75A40C145DDBD927218C0F5471806ACB75A4000016BD5AE7118C01316702AADB75A4044C42863D77118C00CEC8C4AC5B75A4050148D5A067118C08CCC6D0CCBB75A400C1F1153227118C0FE2B2B4DCAB75A40FB95CE87677118C0A015BDF8C7B75A4022140088607118C00083EEDCC5B75A403E5A9C31CC7118C00A95C9BAC9B75A4089A0C5ADDD7118C0466E9747C8B75A4022B193B0257218C0A484059CCAB75A4016C49B90317218C0D50EDA06C9B75A401792DD16767218C0BA241818C3B75A40A62089A8D37318C0C857A76FBEB75A40AB28B91EE07418C046933078BDB75A4022718FA50F7518C07F3AD4A5B5B75A4012B57E445D7518C0E0C1AAD5B2B75A400C321356747518C080C7A64BB5B75A4072D7B738CF7518C01F40D01BB8B75A40DEFFC709137618C08C7ED9E2BFB75A4028918EBCBD7518C0852BFB09C2B75A4055794CEEC17518C0A2DFADE2C3B75A405CE3D81FCD7518C04D4E48C6C5B75A401184D0E6DD7518C0BD564277C9B75A4056606D31E47518C092472696CAB75A40FA1C69BAE87518C051E56A1ACAB75A40395DBB59287618C05AC63CE1DBB75A40C104C996407518C0246827DEDCB75A4078301812E67418C01D88765FDFB75A40615518B6C17418C00047F1E0DDB75A40DF1F4A0F9E7418C084D558C2DAB75A401D797B6BBB7418C060B422C5DBB75A406D74CE4F717418C09C1AC3F7D9B75A4050166305647418C0334E4354E1B75A40A6E5513B0D7218C081DA5EC1ECB75A402D5BEB8B846E18C09A87026CF6B75A40E28794B0806B18C08BC7A06EFBB75A40C039C890086A18C00000000000B85A40FE79B4BDBE6918C00000000000B85A40000000A0FF7F18C0	0.5803999900817871	2026-06-09
\.


--
-- Data for Name: aod_satellite; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.aod_satellite (id, satellite_name) FROM stdin;
1	Himawari
\.


--
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text) FROM stdin;
\.


--
-- Data for Name: weather_data; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.weather_data (id, station_id, date, temperature, temp_max, temp_min, feels_like, feels_like_max, feels_like_min, dew_point, humidity, wind_speed, wind_gust, wind_dir, precipitation, precip_cover, barometric_pressure, sea_level_pressure, cloud_cover, visibility, uv_index, solar_radiation, solar_energy) FROM stdin;
1	4	2026-05-27	28.3	33.6	24.4	30.9	39	24.4	23.7	78.2	14	15.1	7.6	0	0	1011	\N	18.4	6.5	8	249.2	21.5
2	6	2026-05-27	28.3	33.7	24.3	30.8	39	24.3	23.7	78.3	14.2	15.1	12.7	0	0	1011	\N	19.5	6.5	8	249.2	21.5
3	5	2026-05-27	28.3	33.7	24.3	30.8	39	24.3	23.7	78.3	14.2	15.5	12.2	0.2	0	1011	\N	18.6	6.5	8	247.5	21.5
4	8	2026-05-27	28.4	32.9	25	31.2	38.5	25	23.9	78	12.8	15.1	350.5	0	0	1010.9	\N	16.1	6.7	8	249.2	21.5
5	7	2026-05-27	28.3	34	24	30.7	39.2	24	23.6	78.5	14.7	15.5	29.9	0.2	0	1011	\N	21.6	6.4	8	247.5	21.5
6	1	2026-05-27	28.3	33.5	24.5	30.9	38.9	24.5	23.7	78.2	13.9	15.1	5.4	0	0	1011	\N	18.1	6.6	8	249.2	21.5
7	2	2026-05-27	28.3	33.5	24.5	30.9	38.9	24.5	23.7	78.2	13.9	15.1	6.3	0	0	1011	\N	18.5	6.6	8	249.2	21.5
8	3	2026-05-27	28.3	33.5	24.5	30.9	38.9	24.5	23.7	78.2	13.9	15.1	5.8	0	0	1011	\N	18.4	6.6	8	249.2	21.5
9	4	2026-05-28	28.2	33.8	24	29.5	36.6	24	21.7	70.4	18.4	14.4	268.9	0	0	1011.1	\N	10.3	8.4	9	254.8	22.3
10	6	2026-05-28	28.2	33.8	24	29.5	36.6	24	21.7	70.4	18.4	14.4	263	0	0	1011.1	\N	10.3	8.4	9	254.8	22.3
11	5	2026-05-28	28.2	33.8	24	29.5	36.6	24	21.7	70.4	18.4	14.4	263.4	0	0	1011.1	\N	9.9	8.4	9	253.3	22
12	8	2026-05-28	28	33.4	24	29.4	36.7	24	21.6	70.4	18.4	14.4	278	0	0	1010.9	\N	12	8.4	9	254.8	22.3
13	7	2026-05-28	28.3	34	24	29.5	36.5	24	21.7	70.5	18.4	14.4	236.5	0	0	1011.2	\N	9.5	8.4	9	253.3	22
14	1	2026-05-28	28.2	33.8	24	29.4	36.6	24	21.7	70.4	18.4	14.4	271.3	0	0	1011.1	\N	10.5	8.4	9	254.8	22.3
15	2	2026-05-28	28.2	33.8	24	29.4	36.6	24	21.7	70.4	18.4	14.4	270.4	0	0	1011.1	\N	10.6	8.4	9	254.8	22.3
16	3	2026-05-28	28.2	33.8	24	29.4	36.6	24	21.7	70.4	18.4	14.4	270.7	0	0	1011.1	\N	10.6	8.4	9	254.8	22.3
17	4	2026-05-29	28.4	33	24	30.8	37.4	24	22.7	73	17.6	18	327.3	0	0	1010.6	\N	34.5	7.1	8	235.2	20.4
18	6	2026-05-29	28.4	33	23.9	30.8	37.6	23.9	22.7	73	17.8	18	330.4	0	0	1010.6	\N	34.9	7.1	8	235.2	20.4
19	5	2026-05-29	28.4	33	24	30.8	37.6	24	22.7	73	17.7	18.4	329.6	0.2	0	1010.6	\N	35.3	7.1	8	237.8	20.5
20	8	2026-05-29	28.3	33	24	30.5	36.7	24	22.6	73	16.4	18	303.5	0	0	1010.4	\N	32.4	7.1	8	235.2	20.4
21	7	2026-05-29	28.4	32.9	24	30.9	37.9	24	22.7	73	18.3	18.4	333.5	0.2	0	1010.6	\N	36.3	7	8	237.8	20.5
22	1	2026-05-29	28.4	33	24	30.8	37.4	24	22.7	73	17.5	18	325.3	0	0	1010.5	\N	34.3	7.1	8	235.2	20.4
23	2	2026-05-29	28.4	33	24	30.8	37.4	24	22.7	73	17.5	18	326	0	0	1010.6	\N	34.4	7.1	8	235.2	20.4
24	3	2026-05-29	28.4	33	24	30.8	37.4	24	22.7	73	17.5	18	325.7	0	0	1010.6	\N	34.4	7.1	8	235.2	20.4
25	4	2026-05-30	28.5	33.5	26	31.8	38.1	26	24	77.7	15.6	16.9	60.7	0.8	4.17	1010	\N	49.5	6.1	8	226.7	19.3
26	6	2026-05-30	28.5	33.6	26	31.7	38.1	26	24	77.6	15.3	16.9	64	0.8	4.17	1010	\N	50.1	6.1	8	226.7	19.3
27	5	2026-05-30	28.5	33.6	26	31.7	38.1	26	24	77.6	15.4	15.8	63.5	0.7	4.17	1010	\N	50	6.1	8	225.9	19.5
28	8	2026-05-30	28.5	32.8	25.8	31.6	37.9	25.8	24.1	78	16.8	16.9	47.7	0.8	4.17	1009.9	\N	46.4	6	8	226.7	19.3
29	7	2026-05-30	28.5	33.9	26	32	38.2	26	24	77.5	14.8	15.8	72.2	0.7	4.17	1010	\N	51.5	6.1	8	225.9	19.5
30	1	2026-05-30	28.5	33.4	26	31.8	38.1	26	24	77.7	15.7	16.9	59.4	0.8	4.17	1010	\N	49.2	6.1	8	226.7	19.3
31	2	2026-05-30	28.5	33.5	26	31.7	38.1	26	24	77.7	15.6	16.9	60.1	0.8	4.17	1010	\N	49.4	6.1	8	226.7	19.3
32	3	2026-05-30	28.5	33.5	26	31.8	38.1	26	24	77.7	15.6	16.9	59.3	0.8	4.17	1010	\N	49.3	6.1	8	226.7	19.3
33	4	2026-05-31	27.5	30.7	24.6	30.2	35.9	24.6	23.5	79.4	14	16.9	298.4	0.9	8.33	1010.5	\N	57	7.1	8	180.8	15.7
34	6	2026-05-31	27.6	30.8	24.6	30.2	36	24.6	23.5	79	14.2	16.9	296.4	0.9	8.33	1010.5	\N	57.5	7.3	8	180.8	15.7
35	5	2026-05-31	27.6	30.8	24.9	30.3	36	24.9	23.5	79.2	14.1	18.4	295.6	0.8	4.17	1010.5	\N	57.8	7.3	8	183.6	15.9
36	8	2026-05-31	27.3	30.4	24.6	29.8	35.1	24.6	23.8	81.8	12.8	16.9	314.8	0.9	8.33	1010.4	\N	54.5	6.2	8	180.8	15.7
37	7	2026-05-31	27.7	30.9	24.9	30.4	36.4	24.9	23.4	78.1	14.7	18.4	290.9	0.8	4.17	1010.5	\N	59	7.7	8	183.6	15.9
38	1	2026-05-31	27.5	30.7	24.6	30.2	35.8	24.6	23.6	79.6	13.9	16.9	299.8	0.9	8.33	1010.5	\N	56.8	7	8	180.8	15.7
39	2	2026-05-31	27.5	30.7	24.6	30.2	35.8	24.6	23.6	79.5	13.9	16.9	298.7	0.9	8.33	1010.5	\N	56.9	7.1	8	180.8	15.7
40	3	2026-05-31	27.5	30.7	24.6	30.2	35.8	24.6	23.6	79.6	13.9	16.9	299.2	0.9	8.33	1010.5	\N	56.9	7	8	180.8	15.7
41	4	2026-06-01	28.6	32.7	26	32.1	37.9	26	23.7	75.7	15.2	18.4	33.2	0.1	0	1010.9	\N	63.9	6	7	205.2	17.8
42	6	2026-06-01	28.6	32.8	26	32.1	37.9	26	23.7	75.6	15	18.4	34.9	0.1	0	1010.9	\N	66.2	6.1	7	205.2	17.8
43	5	2026-06-01	28.6	32.8	26	32.1	37.9	26	23.7	75.4	15.1	18.4	36.9	0.2	4.17	1010.9	\N	65.9	6.1	8	218.9	18.9
44	8	2026-06-01	28.7	32.4	25.9	32.4	37.9	25.9	23.9	75.9	15.8	18.4	28.7	0.1	0	1010.8	\N	51.9	5.8	7	205.2	17.8
45	7	2026-06-01	28.5	32.9	26	32	38	26	23.6	75.3	14.8	18.4	42.4	0.2	4.17	1010.9	\N	71.7	6.2	8	218.9	18.9
46	1	2026-06-01	28.6	32.7	26	32.1	37.9	26	23.7	75.7	15.2	18.4	32.4	0.1	0	1010.9	\N	62.8	6	7	205.2	17.8
47	2	2026-06-01	28.6	32.7	26	32.1	37.9	26	23.7	75.7	15.2	18.4	32.9	0.1	0	1010.9	\N	63.4	6	7	205.2	17.8
48	3	2026-06-01	28.6	32.7	26	32.1	37.9	26	23.7	75.7	15.2	18.4	32.8	0.1	0	1010.9	\N	63.1	6	7	205.2	17.8
49	4	2026-06-02	29.3	33.5	25.2	32.6	38.9	25.2	23.3	71.6	14.8	16.2	37.6	0.2	0	1010.4	\N	42.8	6.4	7	208.8	18
50	6	2026-06-02	29.3	33.6	25.1	32.6	39	25.1	23.3	71.5	14.8	16.2	38.3	0.2	0	1010.4	\N	43.2	6.4	7	208.8	18
51	5	2026-06-02	29.3	33.6	25.1	32.6	39	25.1	23.3	71.5	14.8	16.2	37	0.5	0	1010.4	\N	43.1	6.4	7	212.4	18.4
52	8	2026-06-02	29.2	32.8	25.4	32.6	38.4	25.4	23.4	72.2	14.8	16.2	34.2	0.2	0	1010.3	\N	40.5	6.6	7	208.8	18
53	7	2026-06-02	29.4	33.9	25	32.6	39.2	25	23.2	71.2	14.8	16.2	38.8	0.5	0	1010.4	\N	44.2	6.3	7	212.4	18.4
54	1	2026-06-02	29.3	33.4	25.2	32.6	38.9	25.2	23.3	71.6	14.8	16.2	37	0.2	0	1010.3	\N	42.6	6.4	7	208.8	18
55	2	2026-06-02	29.3	33.5	25.2	32.6	38.9	25.2	23.3	71.6	14.8	16.2	37	0.2	0	1010.4	\N	42.7	6.4	7	208.8	18
56	3	2026-06-02	29.3	33.5	25.2	32.6	38.9	25.2	23.3	71.6	14.8	16.2	37.1	0.2	0	1010.4	\N	42.6	6.4	7	208.8	18
57	4	2026-06-03	29.3	33	26.2	32	36.7	26.2	22.7	69.5	16.8	15.5	56.6	0.1	0	1009.5	\N	46.5	6.9	8	231	19.9
58	6	2026-06-03	29.3	33	26.1	32	36.7	26.1	22.6	69.1	17.2	15.5	57.1	0.1	0	1009.5	\N	47.1	6.9	8	231	19.9
59	5	2026-06-03	29.3	33	26.1	32	36.7	26.1	22.6	69.2	17.1	15.1	57	0.2	0	1009.5	\N	47	6.9	8	227.1	19.6
60	8	2026-06-03	29.2	33	26.5	32.3	36.7	26.5	23.2	71.2	16.8	15.5	55.4	0.1	0	1009.4	\N	43.6	6.9	8	231	19.9
61	7	2026-06-03	29.3	32.9	26	31.9	36.7	26	22.4	68.5	18.3	15.1	57.9	0.2	0	1009.5	\N	48.4	6.9	8	227.1	19.6
62	1	2026-06-03	29.3	33	26.2	32	36.7	26.2	22.8	69.6	16.6	15.5	56.5	0.1	0	1009.5	\N	46.3	6.9	8	231	19.9
63	2	2026-06-03	29.3	33	26.2	32	36.7	26.2	22.7	69.5	16.7	15.5	56.5	0.1	0	1009.5	\N	46.4	6.9	8	231	19.9
64	3	2026-06-03	29.3	33	26.2	32	36.7	26.2	22.7	69.6	16.6	15.5	56.4	0.1	0	1009.5	\N	46.3	6.9	8	231	19.9
65	4	2026-06-04	29.6	33.5	26.2	33.6	38.5	26.2	23.8	72	25.5	16.2	83.9	4.7	29.17	1009.9	\N	40.8	5.5	8	189.7	16.4
66	6	2026-06-04	29.6	33.6	26.1	33.6	38.3	26.1	23.7	71.6	25.6	16.2	84	4.7	29.17	1009.9	\N	41.5	5.5	8	189.7	16.4
67	5	2026-06-04	29.6	33.6	26.1	33.6	38.3	26.1	23.7	71.7	25.6	19.8	83.9	2.4	16.67	1009.9	\N	41.4	5.5	8	203.9	17.7
68	8	2026-06-04	29.5	33	26.5	34.2	39.3	26.5	24.2	73.9	24.9	16.2	82	4.7	29.17	1009.9	\N	37.2	5.4	8	189.7	16.4
69	7	2026-06-04	29.6	33.9	26	33.4	38.2	26	23.5	70.8	25.9	19.8	84.1	2.4	16.67	1009.9	\N	43.2	5.5	8	203.9	17.7
70	1	2026-06-04	29.6	33.4	26.2	33.6	38.5	26.2	23.8	72.1	25.5	16.2	83.8	4.7	29.17	1009.9	\N	40.5	5.4	8	189.7	16.4
71	2	2026-06-04	29.6	33.5	26.2	33.6	38.5	26.2	23.8	72	25.5	16.2	84	4.7	29.17	1009.9	\N	40.7	5.5	8	189.7	16.4
72	3	2026-06-04	29.6	33.5	26.2	33.6	38.5	26.2	23.8	72.1	25.5	16.2	83.8	4.7	29.17	1009.9	\N	40.6	5.5	8	189.7	16.4
73	4	2026-06-05	29.7	34	26.2	34.4	40.8	26.2	24.4	74.1	28.6	46.4	76.9	0.1	4.17	1010.3	\N	37.7	5.4	8	245.2	21.1
74	6	2026-06-05	29.7	34	26.1	34.4	40.7	26.1	24.3	73.8	28.3	46.4	77	0.1	4.17	1010.3	\N	38.3	5.4	8	245.2	21.1
75	5	2026-06-05	29.8	34	26.1	34.4	40.7	26.1	24.3	73.9	28.4	46.4	77.1	0	0	1010.3	\N	38.2	5.4	8	242.6	20.9
76	8	2026-06-05	29.6	34	26.5	34.4	41.3	26.5	24.6	75.2	29.9	46.4	76.4	0.1	4.17	1010.3	\N	35	5.4	8	245.2	21.1
77	7	2026-06-05	29.8	34	26	34.4	40.5	26	24.2	73.3	27.7	46.4	77.5	0	0	1010.4	\N	39.5	5.4	8	242.6	20.9
78	1	2026-06-05	29.7	34	26.2	34.4	40.8	26.2	24.4	74.2	28.7	46.4	76.7	0.1	4.17	1010.3	\N	37.5	5.4	8	245.2	21.1
79	2	2026-06-05	29.7	34	26.2	34.4	40.8	26.2	24.4	74.1	28.7	46.4	76.6	0.1	4.17	1010.3	\N	37.6	5.4	8	245.2	21.1
80	3	2026-06-05	29.7	34	26.2	34.4	40.8	26.2	24.4	74.1	28.7	46.4	76.6	0.1	4.17	1010.3	\N	37.5	5.4	8	245.2	21.1
81	4	2026-06-06	29.8	34	26.4	34.4	40.4	26.4	24	72.2	29.5	23	81.5	0.2	0	1010.9	\N	37.5	7.8	9	250.9	21.8
82	6	2026-06-06	29.8	34	26.3	34.3	40.4	26.3	24	72	29.5	23	81.9	0.2	0	1010.9	\N	37.8	7.9	9	250.9	21.8
83	5	2026-06-06	29.8	34	26.3	34.2	40.4	26.3	24	72	29.5	26.6	81.5	0	0	1010.9	\N	36.9	7.9	9	250.9	21.9
84	8	2026-06-06	29.8	34	27	34.7	40.6	29.7	24.3	73.2	29.5	23	82	0.2	0	1010.8	\N	36.3	7.6	9	250.9	21.8
85	7	2026-06-06	29.8	34	26	34.1	40.5	26	23.8	71.5	29.5	26.6	82	0	0	1011	\N	37.5	8	9	250.9	21.9
86	1	2026-06-06	29.8	34	26.5	34.4	40.4	26.5	24	72.2	29.5	23	81.7	0.2	0	1010.9	\N	37.4	7.8	9	250.9	21.8
87	2	2026-06-06	29.8	34	26.4	34.4	40.4	26.4	24	72.2	29.5	23	81.7	0.2	0	1010.9	\N	37.5	7.8	9	250.9	21.8
88	3	2026-06-06	29.8	34	26.4	34.4	40.4	26.4	24	72.2	29.5	23	81.6	0.2	0	1010.9	\N	37.5	7.8	9	250.9	21.8
89	4	2026-06-07	29	33.7	24.4	31.3	37.4	24.4	22.6	70.5	19.8	28.1	66.1	0	0	1011.9	\N	28.1	6.3	9	254.2	22
90	6	2026-06-07	29	33.8	24.3	31.3	37.3	24.3	22.6	70.5	20.6	28.1	66.2	0	0	1011.9	\N	28.1	6.3	9	254.2	22
91	5	2026-06-07	29	33.8	24.3	31.3	37.3	24.3	22.6	70.5	20.4	27.4	66.3	0	0	1011.9	\N	27.5	6.3	9	254.9	22
92	8	2026-06-07	29.1	33.4	25.1	31.8	37.6	25.1	22.8	70.7	19.7	28.1	67.7	0	0	1011.7	\N	28.1	6.3	9	254.2	22
93	7	2026-06-07	29	33.9	24	31.2	37.2	24	22.5	70.5	22.2	27.4	68	0	0	1012	\N	27.5	6.3	9	254.9	22
94	1	2026-06-07	29.1	33.7	24.5	31.3	37.4	24.5	22.6	70.5	19.5	28.1	65.8	0	0	1011.9	\N	28.1	6.3	9	254.2	22
95	2	2026-06-07	29	33.7	24.4	31.3	37.4	24.4	22.6	70.5	19.7	28.1	66.1	0	0	1011.9	\N	28.1	6.3	9	254.2	22
96	3	2026-06-07	29	33.7	24.4	31.3	37.4	24.4	22.6	70.5	19.6	28.1	66	0	0	1011.9	\N	28.1	6.3	9	254.2	22
97	4	2026-06-08	29.2	33.7	24.4	31.6	37.6	24.4	22.4	68.3	18.8	15.1	59.9	0	0	1011.5	\N	32.8	6.6	9	250.9	21.9
98	6	2026-06-08	29.2	33.8	24.3	31.6	37.5	24.3	22.3	68.2	19.3	15.1	60.9	0	0	1011.5	\N	33.3	6.7	9	250.9	21.9
99	5	2026-06-08	29.2	33.8	24.3	31.6	37.5	24.3	22.3	68.3	19.2	14.4	60.8	0	0	1011.5	\N	33.2	6.7	9	250.9	21.7
100	8	2026-06-08	29.2	33.4	25.1	32	38.2	25.1	22.5	68.6	16.6	15.1	60	0	0	1011.5	\N	30.4	6.3	9	250.9	21.9
101	7	2026-06-08	29.2	33.9	24	31.6	37.2	24	22.3	68.2	20.5	14.4	64.3	0	0	1011.6	\N	34.4	6.9	9	250.9	21.7
102	1	2026-06-08	29.2	33.7	24.5	31.6	37.6	24.5	22.4	68.3	18.6	15.1	59.4	0	0	1011.5	\N	32.6	6.6	9	250.9	21.9
103	2	2026-06-08	29.2	33.7	24.4	31.6	37.6	24.4	22.4	68.3	18.7	15.1	59.5	0	0	1011.5	\N	32.7	6.6	9	250.9	21.9
104	3	2026-06-08	29.2	33.7	24.4	31.6	37.6	24.4	22.4	68.3	18.7	15.1	59.4	0	0	1011.5	\N	32.6	6.6	9	250.9	21.9
105	4	2026-06-09	28.9	33.7	24.4	31.3	38.3	24.4	22.8	71.2	11.8	15.1	85.4	0	0	1011	\N	36.6	5.7	9	252.3	22
106	6	2026-06-09	29	33.8	24.3	31.3	38.5	24.3	22.7	71	12.1	15.1	89.3	0	0	1011	\N	36.8	5.7	9	252.3	22
107	5	2026-06-09	29	33.8	24.3	31.3	38.5	24.3	22.8	71	12	13.3	89	0	0	1011	\N	36.8	5.7	9	252.3	21.9
108	8	2026-06-09	28.8	33.4	25	31.6	38	25	23.1	72.2	12.2	15.1	71.8	0	0	1010.8	\N	35.2	5.1	9	252.3	22
109	7	2026-06-09	29	33.9	24	31.3	39.1	24	22.7	70.6	12.9	13.3	100.2	0	0	1011	\N	37.5	6	9	252.3	21.9
110	1	2026-06-09	28.9	33.7	24.5	31.3	38.2	24.5	22.8	71.3	11.6	15.1	83.3	0	0	1010.9	\N	36.5	5.6	9	252.3	22
111	2	2026-06-09	28.9	33.7	24.4	31.3	38.2	24.4	22.8	71.2	11.7	15.1	84.4	0	0	1011	\N	36.5	5.6	9	252.3	22
112	3	2026-06-09	28.9	33.7	24.4	31.3	38.2	24.4	22.8	71.3	11.6	15.1	84.1	0	0	1011	\N	36.5	5.6	9	252.3	22
113	1	2026-06-11	29	32.8	26.2	31.2	35	26.2	21.3	64	19.1	14.8	23.8	0.3	0	1013.1	\N	24.9	23.3	9	236.2	20.7
114	2	2026-06-11	29	32.8	26.2	31.2	35	26.2	21.3	64	19.1	14.8	23.8	0.3	0	1013.1	\N	24.9	23.3	9	236.2	20.7
115	3	2026-06-11	29	32.8	26.2	31.2	35	26.2	21.3	64	19.1	14.8	23.8	0.3	0	1013.1	\N	24.9	23.3	9	236.2	20.7
116	4	2026-06-11	29	32.8	26.2	31.2	35	26.2	21.3	64	19.1	14.8	23.8	0.3	0	1013.1	\N	24.8	23.3	9	236.2	20.7
117	5	2026-06-11	29	33.7	25.9	30.6	35.7	25.9	21.1	63.6	17.3	13.3	56.1	0.1	0	1013.1	\N	21	23.3	9	247.8	21.6
118	6	2026-06-11	29	32.8	26.1	31.2	35	26.1	21.3	64	19.1	14.8	23.8	0.3	0	1013.1	\N	24.8	23.3	9	236.2	20.7
119	8	2026-06-11	29	32.8	26.5	31.2	35	26.5	21.3	64	19.1	14.8	24.3	0.3	0	1013.1	\N	25.2	23.3	9	236.2	20.7
120	7	2026-06-11	29	33.6	25.6	30.8	35.6	25.6	21	63.2	16.2	12.6	48.8	0	0	1013	\N	21.3	21.8	9	252.3	22
121	4	2026-05-13	28	\N	\N	\N	\N	\N	22.8	74	31.4	\N	\N	0.06	\N	\N	\N	\N	\N	\N	\N	\N
122	4	2026-05-14	27.1	\N	\N	\N	\N	\N	23.9	83.4	21.4	\N	\N	46.117	\N	\N	\N	\N	\N	\N	\N	\N
123	4	2026-05-15	27.6	\N	\N	\N	\N	\N	24	81.8	22.3	\N	\N	15.666	\N	\N	\N	\N	\N	\N	\N	\N
124	4	2026-05-16	28	\N	\N	\N	\N	\N	24.3	81.2	22.1	\N	\N	2.819	\N	\N	\N	\N	\N	\N	\N	\N
125	4	2026-05-17	27.8	\N	\N	\N	\N	\N	24.9	84.9	19.3	\N	\N	24.298	\N	\N	\N	\N	\N	\N	\N	\N
126	4	2026-05-18	26.9	\N	\N	\N	\N	\N	25	89.7	21.4	\N	\N	42.869	\N	\N	\N	\N	\N	\N	\N	\N
127	4	2026-05-19	27.3	\N	\N	\N	\N	\N	23.8	81.8	23.8	\N	\N	13.774	\N	\N	\N	\N	\N	\N	\N	\N
128	4	2026-05-20	27.2	\N	\N	\N	\N	\N	24.4	84.8	12.8	\N	\N	6.94	\N	\N	\N	\N	\N	\N	\N	\N
129	4	2026-05-21	28.5	\N	\N	\N	\N	\N	23.6	75.7	23.8	\N	\N	3.904	\N	\N	\N	\N	\N	\N	\N	\N
130	4	2026-05-22	29	\N	\N	\N	\N	\N	23.6	73.4	18.2	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
131	4	2026-05-23	29.6	\N	\N	\N	\N	\N	22.6	67.3	20.8	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
132	4	2026-05-24	29.2	\N	\N	\N	\N	\N	23.9	73.6	15.4	\N	\N	0.006	\N	\N	\N	\N	\N	\N	\N	\N
133	4	2026-05-25	28.2	\N	\N	\N	\N	\N	23.2	75.2	29.3	\N	\N	1.051	\N	\N	\N	\N	\N	\N	\N	\N
134	4	2026-05-26	28.1	\N	\N	\N	\N	\N	23.2	75.3	23.7	\N	\N	1.676	\N	\N	\N	\N	\N	\N	\N	\N
135	6	2026-05-13	27.8	\N	\N	\N	\N	\N	22.7	74.5	32	\N	\N	1.649	\N	\N	\N	\N	\N	\N	\N	\N
136	6	2026-05-14	26.8	\N	\N	\N	\N	\N	23.7	84.1	22.7	\N	\N	33.388	\N	\N	\N	\N	\N	\N	\N	\N
137	6	2026-05-15	27.4	\N	\N	\N	\N	\N	23.7	81.5	23.3	\N	\N	11.065	\N	\N	\N	\N	\N	\N	\N	\N
138	6	2026-05-16	27.8	\N	\N	\N	\N	\N	24.1	81	18.8	\N	\N	3.049	\N	\N	\N	\N	\N	\N	\N	\N
139	6	2026-05-17	27.6	\N	\N	\N	\N	\N	24.8	85	19.4	\N	\N	16.128	\N	\N	\N	\N	\N	\N	\N	\N
140	6	2026-05-18	26.6	\N	\N	\N	\N	\N	24.8	89.7	21.7	\N	\N	30.995	\N	\N	\N	\N	\N	\N	\N	\N
141	6	2026-05-19	27	\N	\N	\N	\N	\N	23.7	82.9	24.8	\N	\N	16.934	\N	\N	\N	\N	\N	\N	\N	\N
142	6	2026-05-20	26.9	\N	\N	\N	\N	\N	24.1	85.1	12.4	\N	\N	6.804	\N	\N	\N	\N	\N	\N	\N	\N
143	6	2026-05-21	28.2	\N	\N	\N	\N	\N	23.3	75.9	24.8	\N	\N	2.249	\N	\N	\N	\N	\N	\N	\N	\N
144	6	2026-05-22	28.8	\N	\N	\N	\N	\N	23.2	73.2	16.7	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
145	6	2026-05-23	29.4	\N	\N	\N	\N	\N	22.2	66.7	21.2	\N	\N	0.044	\N	\N	\N	\N	\N	\N	\N	\N
146	6	2026-05-24	28.9	\N	\N	\N	\N	\N	23.5	73.5	15.2	\N	\N	0.051	\N	\N	\N	\N	\N	\N	\N	\N
147	6	2026-05-25	27.8	\N	\N	\N	\N	\N	23	75.5	29.9	\N	\N	3.335	\N	\N	\N	\N	\N	\N	\N	\N
148	6	2026-05-26	27.9	\N	\N	\N	\N	\N	22.9	75.2	23.4	\N	\N	4.007	\N	\N	\N	\N	\N	\N	\N	\N
149	3	2026-05-13	27.9	\N	\N	\N	\N	\N	22.8	74.4	31.2	\N	\N	0.285	\N	\N	\N	\N	\N	\N	\N	\N
150	3	2026-05-14	27	\N	\N	\N	\N	\N	23.9	83.6	21.3	\N	\N	42.252	\N	\N	\N	\N	\N	\N	\N	\N
151	3	2026-05-15	27.5	\N	\N	\N	\N	\N	24	81.8	21.9	\N	\N	14.177	\N	\N	\N	\N	\N	\N	\N	\N
152	3	2026-05-16	27.9	\N	\N	\N	\N	\N	24.3	81.2	21.2	\N	\N	2.872	\N	\N	\N	\N	\N	\N	\N	\N
153	3	2026-05-17	27.7	\N	\N	\N	\N	\N	24.9	84.9	19.3	\N	\N	22.801	\N	\N	\N	\N	\N	\N	\N	\N
154	3	2026-05-18	26.8	\N	\N	\N	\N	\N	24.9	89.7	21.3	\N	\N	40.199	\N	\N	\N	\N	\N	\N	\N	\N
155	3	2026-05-19	27.2	\N	\N	\N	\N	\N	23.8	82.2	23.3	\N	\N	15.305	\N	\N	\N	\N	\N	\N	\N	\N
156	3	2026-05-20	27.2	\N	\N	\N	\N	\N	24.4	84.8	13	\N	\N	6.701	\N	\N	\N	\N	\N	\N	\N	\N
157	3	2026-05-21	28.4	\N	\N	\N	\N	\N	23.6	76.2	23.3	\N	\N	3.474	\N	\N	\N	\N	\N	\N	\N	\N
158	3	2026-05-22	29	\N	\N	\N	\N	\N	23.5	73.6	17.5	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
159	3	2026-05-23	29.6	\N	\N	\N	\N	\N	22.6	67.5	20.6	\N	\N	0.003	\N	\N	\N	\N	\N	\N	\N	\N
160	3	2026-05-24	29.1	\N	\N	\N	\N	\N	23.8	73.8	15.4	\N	\N	0.028	\N	\N	\N	\N	\N	\N	\N	\N
161	3	2026-05-25	28.1	\N	\N	\N	\N	\N	23.2	75.5	29	\N	\N	1.455	\N	\N	\N	\N	\N	\N	\N	\N
162	3	2026-05-26	28.1	\N	\N	\N	\N	\N	23.2	75.5	23.9	\N	\N	2.214	\N	\N	\N	\N	\N	\N	\N	\N
163	8	2026-05-13	27.6	\N	\N	\N	\N	\N	23	76.3	29.9	\N	\N	0.487	\N	\N	\N	\N	\N	\N	\N	\N
164	8	2026-05-14	26.9	\N	\N	\N	\N	\N	23.9	83.9	20.1	\N	\N	36.655	\N	\N	\N	\N	\N	\N	\N	\N
165	8	2026-05-15	27.5	\N	\N	\N	\N	\N	24	82.4	16.8	\N	\N	11.534	\N	\N	\N	\N	\N	\N	\N	\N
166	8	2026-05-16	27.8	\N	\N	\N	\N	\N	24.3	81.8	20.3	\N	\N	2.822	\N	\N	\N	\N	\N	\N	\N	\N
167	8	2026-05-17	27.7	\N	\N	\N	\N	\N	24.9	85.1	19.3	\N	\N	19.973	\N	\N	\N	\N	\N	\N	\N	\N
168	8	2026-05-18	26.6	\N	\N	\N	\N	\N	24.8	89.9	20.1	\N	\N	33.055	\N	\N	\N	\N	\N	\N	\N	\N
169	8	2026-05-19	27.1	\N	\N	\N	\N	\N	23.8	82.8	17.8	\N	\N	19.833	\N	\N	\N	\N	\N	\N	\N	\N
170	8	2026-05-20	27.1	\N	\N	\N	\N	\N	24.3	85.2	15.2	\N	\N	6.582	\N	\N	\N	\N	\N	\N	\N	\N
171	8	2026-05-21	27.9	\N	\N	\N	\N	\N	23.8	79	17.9	\N	\N	2.767	\N	\N	\N	\N	\N	\N	\N	\N
172	8	2026-05-22	28.7	\N	\N	\N	\N	\N	23.7	75.3	16.7	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
173	8	2026-05-23	29.3	\N	\N	\N	\N	\N	23	69.9	18.5	\N	\N	0.007	\N	\N	\N	\N	\N	\N	\N	\N
174	8	2026-05-24	28.8	\N	\N	\N	\N	\N	24	75.9	16.7	\N	\N	0.045	\N	\N	\N	\N	\N	\N	\N	\N
175	8	2026-05-25	27.7	\N	\N	\N	\N	\N	23.3	77.5	25.6	\N	\N	2.841	\N	\N	\N	\N	\N	\N	\N	\N
176	8	2026-05-26	27.8	\N	\N	\N	\N	\N	23.2	76.8	25.8	\N	\N	3.955	\N	\N	\N	\N	\N	\N	\N	\N
177	5	2026-05-13	28	\N	\N	\N	\N	\N	22.9	74.4	31.9	\N	\N	1.673	\N	\N	\N	\N	\N	\N	\N	\N
178	5	2026-05-14	27.1	\N	\N	\N	\N	\N	23.9	83.6	21.7	\N	\N	24.963	\N	\N	\N	\N	\N	\N	\N	\N
179	5	2026-05-15	27.5	\N	\N	\N	\N	\N	24	81.9	23.2	\N	\N	7.934	\N	\N	\N	\N	\N	\N	\N	\N
180	5	2026-05-16	28	\N	\N	\N	\N	\N	24.3	81.3	19.4	\N	\N	3.445	\N	\N	\N	\N	\N	\N	\N	\N
181	5	2026-05-17	27.8	\N	\N	\N	\N	\N	24.9	84.9	19.4	\N	\N	17.951	\N	\N	\N	\N	\N	\N	\N	\N
182	5	2026-05-18	26.8	\N	\N	\N	\N	\N	24.9	89.6	21.7	\N	\N	31.631	\N	\N	\N	\N	\N	\N	\N	\N
183	5	2026-05-19	27.2	\N	\N	\N	\N	\N	23.9	82.9	24.8	\N	\N	17.956	\N	\N	\N	\N	\N	\N	\N	\N
184	5	2026-05-20	27.2	\N	\N	\N	\N	\N	24.4	84.9	12.4	\N	\N	5.317	\N	\N	\N	\N	\N	\N	\N	\N
185	5	2026-05-21	28.5	\N	\N	\N	\N	\N	23.6	75.9	24.8	\N	\N	1.66	\N	\N	\N	\N	\N	\N	\N	\N
186	5	2026-05-22	29	\N	\N	\N	\N	\N	23.6	73.5	14.9	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
187	5	2026-05-23	29.6	\N	\N	\N	\N	\N	22.6	67.3	21.2	\N	\N	0.004	\N	\N	\N	\N	\N	\N	\N	\N
188	5	2026-05-24	29.1	\N	\N	\N	\N	\N	23.9	74	15.2	\N	\N	0.166	\N	\N	\N	\N	\N	\N	\N	\N
189	5	2026-05-25	28.1	\N	\N	\N	\N	\N	23.2	75.2	29.9	\N	\N	1.244	\N	\N	\N	\N	\N	\N	\N	\N
190	5	2026-05-26	28.2	\N	\N	\N	\N	\N	23.2	75.5	23.4	\N	\N	2.258	\N	\N	\N	\N	\N	\N	\N	\N
191	7	2026-05-13	27.9	\N	\N	\N	\N	\N	22.6	73.3	33.4	\N	\N	0.791	\N	\N	\N	\N	\N	\N	\N	\N
192	7	2026-05-14	26.9	\N	\N	\N	\N	\N	23.7	83.8	27.2	\N	\N	33.91	\N	\N	\N	\N	\N	\N	\N	\N
193	7	2026-05-15	27.5	\N	\N	\N	\N	\N	23.7	80.4	30.8	\N	\N	12.1	\N	\N	\N	\N	\N	\N	\N	\N
194	7	2026-05-16	28	\N	\N	\N	\N	\N	24	80	18.4	\N	\N	3.087	\N	\N	\N	\N	\N	\N	\N	\N
195	7	2026-05-17	27.7	\N	\N	\N	\N	\N	24.8	84.9	19.4	\N	\N	19.712	\N	\N	\N	\N	\N	\N	\N	\N
196	7	2026-05-18	26.8	\N	\N	\N	\N	\N	24.8	89.4	22.3	\N	\N	33.928	\N	\N	\N	\N	\N	\N	\N	\N
197	7	2026-05-19	27.1	\N	\N	\N	\N	\N	23.7	82.5	27.6	\N	\N	16.73	\N	\N	\N	\N	\N	\N	\N	\N
198	7	2026-05-20	27	\N	\N	\N	\N	\N	24.2	85	14.3	\N	\N	6.004	\N	\N	\N	\N	\N	\N	\N	\N
199	7	2026-05-21	28.5	\N	\N	\N	\N	\N	23.2	74.1	27.6	\N	\N	2.616	\N	\N	\N	\N	\N	\N	\N	\N
200	7	2026-05-22	29.1	\N	\N	\N	\N	\N	23	71.7	18.2	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
201	7	2026-05-23	29.7	\N	\N	\N	\N	\N	21.8	64.5	22.3	\N	\N	0.026	\N	\N	\N	\N	\N	\N	\N	\N
202	7	2026-05-24	29.1	\N	\N	\N	\N	\N	23.4	71.8	14.8	\N	\N	0.076	\N	\N	\N	\N	\N	\N	\N	\N
203	7	2026-05-25	28.1	\N	\N	\N	\N	\N	22.9	74	31.6	\N	\N	2.054	\N	\N	\N	\N	\N	\N	\N	\N
204	7	2026-05-26	28.2	\N	\N	\N	\N	\N	22.9	73.7	22.4	\N	\N	2.97	\N	\N	\N	\N	\N	\N	\N	\N
205	1	2026-05-13	28	\N	\N	\N	\N	\N	22.8	74.1	31.1	\N	\N	0.011	\N	\N	\N	\N	\N	\N	\N	\N
206	1	2026-05-14	27.1	\N	\N	\N	\N	\N	23.9	83.4	21.3	\N	\N	46.842	\N	\N	\N	\N	\N	\N	\N	\N
207	1	2026-05-15	27.6	\N	\N	\N	\N	\N	24	81.8	21.8	\N	\N	15.941	\N	\N	\N	\N	\N	\N	\N	\N
208	1	2026-05-16	28	\N	\N	\N	\N	\N	24.3	81.3	22.3	\N	\N	2.804	\N	\N	\N	\N	\N	\N	\N	\N
209	1	2026-05-17	27.8	\N	\N	\N	\N	\N	24.9	84.9	19.3	\N	\N	24.548	\N	\N	\N	\N	\N	\N	\N	\N
210	1	2026-05-18	26.8	\N	\N	\N	\N	\N	25	89.8	21.3	\N	\N	43.307	\N	\N	\N	\N	\N	\N	\N	\N
211	1	2026-05-19	27.3	\N	\N	\N	\N	\N	23.7	81.8	23.3	\N	\N	13.545	\N	\N	\N	\N	\N	\N	\N	\N
212	1	2026-05-20	27.2	\N	\N	\N	\N	\N	24.4	84.8	13	\N	\N	6.989	\N	\N	\N	\N	\N	\N	\N	\N
213	1	2026-05-21	28.5	\N	\N	\N	\N	\N	23.6	75.9	23.3	\N	\N	3.983	\N	\N	\N	\N	\N	\N	\N	\N
214	1	2026-05-22	29	\N	\N	\N	\N	\N	23.6	73.5	18.3	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
215	1	2026-05-23	29.6	\N	\N	\N	\N	\N	22.6	67.5	20.6	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
216	1	2026-05-24	29.1	\N	\N	\N	\N	\N	23.9	73.7	15.5	\N	\N	0.001	\N	\N	\N	\N	\N	\N	\N	\N
217	1	2026-05-25	28.1	\N	\N	\N	\N	\N	23.2	75.3	29	\N	\N	1.007	\N	\N	\N	\N	\N	\N	\N	\N
218	1	2026-05-26	28.1	\N	\N	\N	\N	\N	23.2	75.4	23.9	\N	\N	1.611	\N	\N	\N	\N	\N	\N	\N	\N
219	2	2026-05-13	27.9	\N	\N	\N	\N	\N	22.8	74.5	31.3	\N	\N	0.414	\N	\N	\N	\N	\N	\N	\N	\N
220	2	2026-05-14	27	\N	\N	\N	\N	\N	23.8	83.7	21.4	\N	\N	39.376	\N	\N	\N	\N	\N	\N	\N	\N
221	2	2026-05-15	27.5	\N	\N	\N	\N	\N	23.9	81.7	22	\N	\N	13.083	\N	\N	\N	\N	\N	\N	\N	\N
222	2	2026-05-16	27.9	\N	\N	\N	\N	\N	24.3	81.2	20.6	\N	\N	2.873	\N	\N	\N	\N	\N	\N	\N	\N
223	2	2026-05-17	27.7	\N	\N	\N	\N	\N	24.9	84.9	19.3	\N	\N	21.516	\N	\N	\N	\N	\N	\N	\N	\N
224	2	2026-05-18	26.8	\N	\N	\N	\N	\N	24.9	89.7	21.4	\N	\N	38.073	\N	\N	\N	\N	\N	\N	\N	\N
225	2	2026-05-19	27.2	\N	\N	\N	\N	\N	23.8	82.4	23.5	\N	\N	16.514	\N	\N	\N	\N	\N	\N	\N	\N
226	2	2026-05-20	27.1	\N	\N	\N	\N	\N	24.3	84.9	12.9	\N	\N	6.508	\N	\N	\N	\N	\N	\N	\N	\N
227	2	2026-05-21	28.4	\N	\N	\N	\N	\N	23.6	76.3	23.5	\N	\N	3.162	\N	\N	\N	\N	\N	\N	\N	\N
228	2	2026-05-22	28.9	\N	\N	\N	\N	\N	23.5	73.6	17.2	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
229	2	2026-05-23	29.5	\N	\N	\N	\N	\N	22.5	67.4	20.7	\N	\N	0.007	\N	\N	\N	\N	\N	\N	\N	\N
230	2	2026-05-24	29	\N	\N	\N	\N	\N	23.8	73.9	15.4	\N	\N	0.039	\N	\N	\N	\N	\N	\N	\N	\N
231	2	2026-05-25	28	\N	\N	\N	\N	\N	23.2	75.6	29.1	\N	\N	1.915	\N	\N	\N	\N	\N	\N	\N	\N
232	2	2026-05-26	28.1	\N	\N	\N	\N	\N	23.1	75.5	23.8	\N	\N	2.767	\N	\N	\N	\N	\N	\N	\N	\N
233	4	2026-04-11	27.7	\N	\N	\N	\N	\N	23.3	77.4	27.5	\N	\N	28.482	\N	\N	\N	\N	\N	\N	\N	\N
234	4	2026-04-12	26.8	\N	\N	\N	\N	\N	23	79.8	29.3	\N	\N	4.305	\N	\N	\N	\N	\N	\N	\N	\N
235	4	2026-04-13	26.1	\N	\N	\N	\N	\N	23.6	86.2	22.2	\N	\N	4.732	\N	\N	\N	\N	\N	\N	\N	\N
236	4	2026-04-14	27.1	\N	\N	\N	\N	\N	23.9	83.4	23	\N	\N	27.777	\N	\N	\N	\N	\N	\N	\N	\N
237	4	2026-04-15	26.6	\N	\N	\N	\N	\N	24	86	18.1	\N	\N	23.881	\N	\N	\N	\N	\N	\N	\N	\N
238	4	2026-04-16	27.4	\N	\N	\N	\N	\N	24.6	85.7	15.9	\N	\N	23.573	\N	\N	\N	\N	\N	\N	\N	\N
239	4	2026-04-17	28.2	\N	\N	\N	\N	\N	24.9	82.7	22.3	\N	\N	6.538	\N	\N	\N	\N	\N	\N	\N	\N
240	4	2026-04-18	26.4	\N	\N	\N	\N	\N	24.8	90.8	18.5	\N	\N	17.408	\N	\N	\N	\N	\N	\N	\N	\N
241	4	2026-04-19	27.2	\N	\N	\N	\N	\N	24.2	83.7	27.4	\N	\N	10.231	\N	\N	\N	\N	\N	\N	\N	\N
242	4	2026-04-20	28.8	\N	\N	\N	\N	\N	23.5	74.2	25.2	\N	\N	0.196	\N	\N	\N	\N	\N	\N	\N	\N
243	4	2026-04-21	29.2	\N	\N	\N	\N	\N	22.7	69.2	22.6	\N	\N	0.983	\N	\N	\N	\N	\N	\N	\N	\N
244	4	2026-04-22	29.5	\N	\N	\N	\N	\N	22.9	68.4	24.9	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
245	4	2026-04-23	28	\N	\N	\N	\N	\N	23.3	76	25.8	\N	\N	0.102	\N	\N	\N	\N	\N	\N	\N	\N
246	4	2026-04-24	27.3	\N	\N	\N	\N	\N	23.4	80.1	25	\N	\N	20.1	\N	\N	\N	\N	\N	\N	\N	\N
247	4	2026-04-25	27.5	\N	\N	\N	\N	\N	24	81.9	22.2	\N	\N	0.033	\N	\N	\N	\N	\N	\N	\N	\N
248	4	2026-04-26	28.2	\N	\N	\N	\N	\N	23.6	77.1	18.2	\N	\N	7.011	\N	\N	\N	\N	\N	\N	\N	\N
249	4	2026-04-27	28	\N	\N	\N	\N	\N	22.8	74	31.4	\N	\N	0.06	\N	\N	\N	\N	\N	\N	\N	\N
250	4	2026-04-28	27.1	\N	\N	\N	\N	\N	23.9	83.4	21.4	\N	\N	46.117	\N	\N	\N	\N	\N	\N	\N	\N
251	4	2026-04-29	27.6	\N	\N	\N	\N	\N	24	81.8	22.3	\N	\N	15.666	\N	\N	\N	\N	\N	\N	\N	\N
252	4	2026-04-30	28	\N	\N	\N	\N	\N	24.3	81.2	22.1	\N	\N	2.819	\N	\N	\N	\N	\N	\N	\N	\N
253	4	2026-05-01	27.8	\N	\N	\N	\N	\N	24.9	84.9	19.3	\N	\N	24.298	\N	\N	\N	\N	\N	\N	\N	\N
254	4	2026-05-02	26.9	\N	\N	\N	\N	\N	25	89.7	21.4	\N	\N	42.869	\N	\N	\N	\N	\N	\N	\N	\N
255	4	2026-05-03	27.3	\N	\N	\N	\N	\N	23.8	81.8	23.8	\N	\N	13.774	\N	\N	\N	\N	\N	\N	\N	\N
256	4	2026-05-04	27.2	\N	\N	\N	\N	\N	24.4	84.8	12.8	\N	\N	6.94	\N	\N	\N	\N	\N	\N	\N	\N
257	4	2026-05-05	28.5	\N	\N	\N	\N	\N	23.6	75.7	23.8	\N	\N	3.904	\N	\N	\N	\N	\N	\N	\N	\N
258	4	2026-05-06	29	\N	\N	\N	\N	\N	23.6	73.4	18.2	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
259	4	2026-05-07	29.6	\N	\N	\N	\N	\N	22.6	67.3	20.8	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
260	4	2026-05-08	29.2	\N	\N	\N	\N	\N	23.9	73.6	15.4	\N	\N	0.006	\N	\N	\N	\N	\N	\N	\N	\N
261	4	2026-05-09	28.2	\N	\N	\N	\N	\N	23.2	75.2	29.3	\N	\N	1.051	\N	\N	\N	\N	\N	\N	\N	\N
262	4	2026-05-10	28.1	\N	\N	\N	\N	\N	23.2	75.3	23.7	\N	\N	1.676	\N	\N	\N	\N	\N	\N	\N	\N
263	6	2026-04-11	27.5	\N	\N	\N	\N	\N	23.2	78.2	27.6	\N	\N	20.892	\N	\N	\N	\N	\N	\N	\N	\N
264	6	2026-04-12	26.7	\N	\N	\N	\N	\N	22.7	79.2	30.4	\N	\N	10.929	\N	\N	\N	\N	\N	\N	\N	\N
265	6	2026-04-13	25.9	\N	\N	\N	\N	\N	23.4	86.4	22.3	\N	\N	7.032	\N	\N	\N	\N	\N	\N	\N	\N
266	6	2026-04-14	26.9	\N	\N	\N	\N	\N	23.8	83.8	23.3	\N	\N	23.721	\N	\N	\N	\N	\N	\N	\N	\N
267	6	2026-04-15	26.2	\N	\N	\N	\N	\N	23.9	87.2	13.8	\N	\N	14.344	\N	\N	\N	\N	\N	\N	\N	\N
268	6	2026-04-16	27.2	\N	\N	\N	\N	\N	24.4	85.6	16.5	\N	\N	15.895	\N	\N	\N	\N	\N	\N	\N	\N
269	6	2026-04-17	28	\N	\N	\N	\N	\N	24.6	82.9	22.3	\N	\N	21.285	\N	\N	\N	\N	\N	\N	\N	\N
270	6	2026-04-18	26.1	\N	\N	\N	\N	\N	24.8	92.3	18.5	\N	\N	29.466	\N	\N	\N	\N	\N	\N	\N	\N
271	6	2026-04-19	26.9	\N	\N	\N	\N	\N	24.1	84.6	28	\N	\N	5.847	\N	\N	\N	\N	\N	\N	\N	\N
272	6	2026-04-20	28.5	\N	\N	\N	\N	\N	23.4	74.9	25.9	\N	\N	0.376	\N	\N	\N	\N	\N	\N	\N	\N
273	6	2026-04-21	28.8	\N	\N	\N	\N	\N	22.5	69.7	22.4	\N	\N	1.494	\N	\N	\N	\N	\N	\N	\N	\N
274	6	2026-04-22	29.1	\N	\N	\N	\N	\N	22.7	68.8	25.2	\N	\N	0.018	\N	\N	\N	\N	\N	\N	\N	\N
275	6	2026-04-23	27.5	\N	\N	\N	\N	\N	23.2	77.4	31.2	\N	\N	7.001	\N	\N	\N	\N	\N	\N	\N	\N
276	6	2026-04-24	27	\N	\N	\N	\N	\N	23.1	80.5	25.7	\N	\N	18.894	\N	\N	\N	\N	\N	\N	\N	\N
277	6	2026-04-25	27.2	\N	\N	\N	\N	\N	23.9	83	22.7	\N	\N	4.275	\N	\N	\N	\N	\N	\N	\N	\N
278	6	2026-04-26	27.9	\N	\N	\N	\N	\N	23.5	77.7	18.2	\N	\N	9.09	\N	\N	\N	\N	\N	\N	\N	\N
279	6	2026-04-27	27.8	\N	\N	\N	\N	\N	22.7	74.5	32	\N	\N	1.649	\N	\N	\N	\N	\N	\N	\N	\N
280	6	2026-04-28	26.8	\N	\N	\N	\N	\N	23.7	84.1	22.7	\N	\N	33.388	\N	\N	\N	\N	\N	\N	\N	\N
281	6	2026-04-29	27.4	\N	\N	\N	\N	\N	23.7	81.5	23.3	\N	\N	11.065	\N	\N	\N	\N	\N	\N	\N	\N
282	6	2026-04-30	27.8	\N	\N	\N	\N	\N	24.1	81	18.8	\N	\N	3.049	\N	\N	\N	\N	\N	\N	\N	\N
283	6	2026-05-01	27.6	\N	\N	\N	\N	\N	24.8	85	19.4	\N	\N	16.128	\N	\N	\N	\N	\N	\N	\N	\N
284	6	2026-05-02	26.6	\N	\N	\N	\N	\N	24.8	89.7	21.7	\N	\N	30.995	\N	\N	\N	\N	\N	\N	\N	\N
285	6	2026-05-03	27	\N	\N	\N	\N	\N	23.7	82.9	24.8	\N	\N	16.934	\N	\N	\N	\N	\N	\N	\N	\N
286	6	2026-05-04	26.9	\N	\N	\N	\N	\N	24.1	85.1	12.4	\N	\N	6.804	\N	\N	\N	\N	\N	\N	\N	\N
287	6	2026-05-05	28.2	\N	\N	\N	\N	\N	23.3	75.9	24.8	\N	\N	2.249	\N	\N	\N	\N	\N	\N	\N	\N
288	6	2026-05-06	28.8	\N	\N	\N	\N	\N	23.2	73.2	16.7	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
289	6	2026-05-07	29.4	\N	\N	\N	\N	\N	22.2	66.7	21.2	\N	\N	0.044	\N	\N	\N	\N	\N	\N	\N	\N
290	6	2026-05-08	28.9	\N	\N	\N	\N	\N	23.5	73.5	15.2	\N	\N	0.051	\N	\N	\N	\N	\N	\N	\N	\N
291	6	2026-05-09	27.8	\N	\N	\N	\N	\N	23	75.5	29.9	\N	\N	3.335	\N	\N	\N	\N	\N	\N	\N	\N
292	6	2026-05-10	27.9	\N	\N	\N	\N	\N	22.9	75.2	23.4	\N	\N	4.007	\N	\N	\N	\N	\N	\N	\N	\N
293	3	2026-04-11	27.7	\N	\N	\N	\N	\N	23.3	77.5	27.5	\N	\N	25.62	\N	\N	\N	\N	\N	\N	\N	\N
294	3	2026-04-12	26.8	\N	\N	\N	\N	\N	23	79.8	28.8	\N	\N	5.989	\N	\N	\N	\N	\N	\N	\N	\N
295	3	2026-04-13	26.1	\N	\N	\N	\N	\N	23.6	86.4	22.2	\N	\N	4.545	\N	\N	\N	\N	\N	\N	\N	\N
296	3	2026-04-14	27.1	\N	\N	\N	\N	\N	23.9	83.4	23	\N	\N	28.206	\N	\N	\N	\N	\N	\N	\N	\N
297	3	2026-04-15	26.5	\N	\N	\N	\N	\N	24	86.1	16.8	\N	\N	21.412	\N	\N	\N	\N	\N	\N	\N	\N
298	3	2026-04-16	27.3	\N	\N	\N	\N	\N	24.6	85.6	15.6	\N	\N	21.53	\N	\N	\N	\N	\N	\N	\N	\N
299	3	2026-04-17	28.2	\N	\N	\N	\N	\N	24.8	82.8	22.3	\N	\N	10.188	\N	\N	\N	\N	\N	\N	\N	\N
300	3	2026-04-18	26.4	\N	\N	\N	\N	\N	24.8	91.2	18.5	\N	\N	19.627	\N	\N	\N	\N	\N	\N	\N	\N
301	3	2026-04-19	27.2	\N	\N	\N	\N	\N	24.2	83.9	27.2	\N	\N	8.962	\N	\N	\N	\N	\N	\N	\N	\N
302	3	2026-04-20	28.8	\N	\N	\N	\N	\N	23.5	74.4	24.9	\N	\N	0.177	\N	\N	\N	\N	\N	\N	\N	\N
303	3	2026-04-21	29.1	\N	\N	\N	\N	\N	22.7	69.3	22.8	\N	\N	0.94	\N	\N	\N	\N	\N	\N	\N	\N
304	3	2026-04-22	29.4	\N	\N	\N	\N	\N	22.9	68.5	24.8	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
305	3	2026-04-23	27.9	\N	\N	\N	\N	\N	23.3	76.2	25.3	\N	\N	0.495	\N	\N	\N	\N	\N	\N	\N	\N
306	3	2026-04-24	27.2	\N	\N	\N	\N	\N	23.4	80.2	24.7	\N	\N	20.766	\N	\N	\N	\N	\N	\N	\N	\N
307	3	2026-04-25	27.5	\N	\N	\N	\N	\N	24	82.1	22	\N	\N	0.239	\N	\N	\N	\N	\N	\N	\N	\N
308	3	2026-04-26	28.2	\N	\N	\N	\N	\N	23.6	77.2	18.1	\N	\N	7.398	\N	\N	\N	\N	\N	\N	\N	\N
309	3	2026-04-27	27.9	\N	\N	\N	\N	\N	22.8	74.4	31.2	\N	\N	0.285	\N	\N	\N	\N	\N	\N	\N	\N
310	3	2026-04-28	27	\N	\N	\N	\N	\N	23.9	83.6	21.3	\N	\N	42.252	\N	\N	\N	\N	\N	\N	\N	\N
311	3	2026-04-29	27.5	\N	\N	\N	\N	\N	24	81.8	21.9	\N	\N	14.177	\N	\N	\N	\N	\N	\N	\N	\N
312	3	2026-04-30	27.9	\N	\N	\N	\N	\N	24.3	81.2	21.2	\N	\N	2.872	\N	\N	\N	\N	\N	\N	\N	\N
313	3	2026-05-01	27.7	\N	\N	\N	\N	\N	24.9	84.9	19.3	\N	\N	22.801	\N	\N	\N	\N	\N	\N	\N	\N
314	3	2026-05-02	26.8	\N	\N	\N	\N	\N	24.9	89.7	21.3	\N	\N	40.199	\N	\N	\N	\N	\N	\N	\N	\N
315	3	2026-05-03	27.2	\N	\N	\N	\N	\N	23.8	82.2	23.3	\N	\N	15.305	\N	\N	\N	\N	\N	\N	\N	\N
316	3	2026-05-04	27.2	\N	\N	\N	\N	\N	24.4	84.8	13	\N	\N	6.701	\N	\N	\N	\N	\N	\N	\N	\N
317	3	2026-05-05	28.4	\N	\N	\N	\N	\N	23.6	76.2	23.3	\N	\N	3.474	\N	\N	\N	\N	\N	\N	\N	\N
318	3	2026-05-06	29	\N	\N	\N	\N	\N	23.5	73.6	17.5	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
319	3	2026-05-07	29.6	\N	\N	\N	\N	\N	22.6	67.5	20.6	\N	\N	0.003	\N	\N	\N	\N	\N	\N	\N	\N
320	3	2026-05-08	29.1	\N	\N	\N	\N	\N	23.8	73.8	15.4	\N	\N	0.028	\N	\N	\N	\N	\N	\N	\N	\N
321	3	2026-05-09	28.1	\N	\N	\N	\N	\N	23.2	75.5	29	\N	\N	1.455	\N	\N	\N	\N	\N	\N	\N	\N
322	3	2026-05-10	28.1	\N	\N	\N	\N	\N	23.2	75.5	23.9	\N	\N	2.214	\N	\N	\N	\N	\N	\N	\N	\N
323	8	2026-04-11	27.7	\N	\N	\N	\N	\N	23.2	77	27.1	\N	\N	18.516	\N	\N	\N	\N	\N	\N	\N	\N
324	8	2026-04-12	26.5	\N	\N	\N	\N	\N	23	81.5	26.3	\N	\N	10.412	\N	\N	\N	\N	\N	\N	\N	\N
325	8	2026-04-13	25.9	\N	\N	\N	\N	\N	23.6	87.4	22.1	\N	\N	4.701	\N	\N	\N	\N	\N	\N	\N	\N
326	8	2026-04-14	27.1	\N	\N	\N	\N	\N	23.9	83.2	23.8	\N	\N	23.893	\N	\N	\N	\N	\N	\N	\N	\N
327	8	2026-04-15	26.6	\N	\N	\N	\N	\N	23.8	85.1	13.7	\N	\N	15.956	\N	\N	\N	\N	\N	\N	\N	\N
328	8	2026-04-16	27.2	\N	\N	\N	\N	\N	24.5	85.8	12.1	\N	\N	17.751	\N	\N	\N	\N	\N	\N	\N	\N
329	8	2026-04-17	28.1	\N	\N	\N	\N	\N	24.8	83.3	22.3	\N	\N	21.781	\N	\N	\N	\N	\N	\N	\N	\N
330	8	2026-04-18	26.2	\N	\N	\N	\N	\N	24.6	91.3	18.6	\N	\N	24.242	\N	\N	\N	\N	\N	\N	\N	\N
331	8	2026-04-19	27.2	\N	\N	\N	\N	\N	24.1	83.8	24.2	\N	\N	6.51	\N	\N	\N	\N	\N	\N	\N	\N
332	8	2026-04-20	28.9	\N	\N	\N	\N	\N	23.6	74.3	22.5	\N	\N	0.132	\N	\N	\N	\N	\N	\N	\N	\N
333	8	2026-04-21	29.1	\N	\N	\N	\N	\N	22.7	69.6	25.7	\N	\N	0.911	\N	\N	\N	\N	\N	\N	\N	\N
334	8	2026-04-22	29.4	\N	\N	\N	\N	\N	22.9	68.8	23.6	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
335	8	2026-04-23	27.9	\N	\N	\N	\N	\N	23.2	75.8	24.7	\N	\N	0.89	\N	\N	\N	\N	\N	\N	\N	\N
336	8	2026-04-24	27.2	\N	\N	\N	\N	\N	23.4	80.4	20.8	\N	\N	23.559	\N	\N	\N	\N	\N	\N	\N	\N
337	8	2026-04-25	27.5	\N	\N	\N	\N	\N	24	82	19.2	\N	\N	0.826	\N	\N	\N	\N	\N	\N	\N	\N
338	8	2026-04-26	28	\N	\N	\N	\N	\N	23.5	77.9	17.8	\N	\N	9.47	\N	\N	\N	\N	\N	\N	\N	\N
339	8	2026-04-27	27.6	\N	\N	\N	\N	\N	23	76.3	29.9	\N	\N	0.487	\N	\N	\N	\N	\N	\N	\N	\N
340	8	2026-04-28	26.9	\N	\N	\N	\N	\N	23.9	83.9	20.1	\N	\N	36.655	\N	\N	\N	\N	\N	\N	\N	\N
341	8	2026-04-29	27.5	\N	\N	\N	\N	\N	24	82.4	16.8	\N	\N	11.534	\N	\N	\N	\N	\N	\N	\N	\N
342	8	2026-04-30	27.8	\N	\N	\N	\N	\N	24.3	81.8	20.3	\N	\N	2.822	\N	\N	\N	\N	\N	\N	\N	\N
343	8	2026-05-01	27.7	\N	\N	\N	\N	\N	24.9	85.1	19.3	\N	\N	19.973	\N	\N	\N	\N	\N	\N	\N	\N
344	8	2026-05-02	26.6	\N	\N	\N	\N	\N	24.8	89.9	20.1	\N	\N	33.055	\N	\N	\N	\N	\N	\N	\N	\N
345	8	2026-05-03	27.1	\N	\N	\N	\N	\N	23.8	82.8	17.8	\N	\N	19.833	\N	\N	\N	\N	\N	\N	\N	\N
346	8	2026-05-04	27.1	\N	\N	\N	\N	\N	24.3	85.2	15.2	\N	\N	6.582	\N	\N	\N	\N	\N	\N	\N	\N
347	8	2026-05-05	27.9	\N	\N	\N	\N	\N	23.8	79	17.9	\N	\N	2.767	\N	\N	\N	\N	\N	\N	\N	\N
348	8	2026-05-06	28.7	\N	\N	\N	\N	\N	23.7	75.3	16.7	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
349	8	2026-05-07	29.3	\N	\N	\N	\N	\N	23	69.9	18.5	\N	\N	0.007	\N	\N	\N	\N	\N	\N	\N	\N
350	8	2026-05-08	28.8	\N	\N	\N	\N	\N	24	75.9	16.7	\N	\N	0.045	\N	\N	\N	\N	\N	\N	\N	\N
351	8	2026-05-09	27.7	\N	\N	\N	\N	\N	23.3	77.5	25.6	\N	\N	2.841	\N	\N	\N	\N	\N	\N	\N	\N
352	8	2026-05-10	27.8	\N	\N	\N	\N	\N	23.2	76.8	25.8	\N	\N	3.955	\N	\N	\N	\N	\N	\N	\N	\N
353	5	2026-04-11	27.6	\N	\N	\N	\N	\N	23.3	77.8	27.6	\N	\N	19.654	\N	\N	\N	\N	\N	\N	\N	\N
354	5	2026-04-12	26.8	\N	\N	\N	\N	\N	23	79.5	30.3	\N	\N	9.415	\N	\N	\N	\N	\N	\N	\N	\N
355	5	2026-04-13	26.1	\N	\N	\N	\N	\N	23.5	85.9	22.3	\N	\N	2.517	\N	\N	\N	\N	\N	\N	\N	\N
356	5	2026-04-14	27.1	\N	\N	\N	\N	\N	24	83.8	23.3	\N	\N	43.463	\N	\N	\N	\N	\N	\N	\N	\N
357	5	2026-04-15	26.5	\N	\N	\N	\N	\N	24	86.8	15.4	\N	\N	12.277	\N	\N	\N	\N	\N	\N	\N	\N
358	5	2026-04-16	27.4	\N	\N	\N	\N	\N	24.6	85.4	16.5	\N	\N	14.367	\N	\N	\N	\N	\N	\N	\N	\N
359	5	2026-04-17	28.2	\N	\N	\N	\N	\N	24.9	82.8	22.3	\N	\N	11.532	\N	\N	\N	\N	\N	\N	\N	\N
360	5	2026-04-18	26.3	\N	\N	\N	\N	\N	24.9	91.9	18.5	\N	\N	24.998	\N	\N	\N	\N	\N	\N	\N	\N
361	5	2026-04-19	27.1	\N	\N	\N	\N	\N	24.2	84.2	28	\N	\N	4.435	\N	\N	\N	\N	\N	\N	\N	\N
362	5	2026-04-20	28.8	\N	\N	\N	\N	\N	23.7	74.9	25.8	\N	\N	0.094	\N	\N	\N	\N	\N	\N	\N	\N
363	5	2026-04-21	29.1	\N	\N	\N	\N	\N	22.8	69.6	22.4	\N	\N	0.481	\N	\N	\N	\N	\N	\N	\N	\N
364	5	2026-04-22	29.4	\N	\N	\N	\N	\N	23	69.1	25.2	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
365	5	2026-04-23	27.9	\N	\N	\N	\N	\N	23.3	76.6	27.1	\N	\N	2.804	\N	\N	\N	\N	\N	\N	\N	\N
366	5	2026-04-24	27.2	\N	\N	\N	\N	\N	23.4	80.4	25.7	\N	\N	20.774	\N	\N	\N	\N	\N	\N	\N	\N
367	5	2026-04-25	27.5	\N	\N	\N	\N	\N	24.1	82.5	22.7	\N	\N	0.423	\N	\N	\N	\N	\N	\N	\N	\N
368	5	2026-04-26	28.1	\N	\N	\N	\N	\N	23.7	77.7	18.2	\N	\N	5.355	\N	\N	\N	\N	\N	\N	\N	\N
369	5	2026-04-27	28	\N	\N	\N	\N	\N	22.9	74.4	31.9	\N	\N	1.673	\N	\N	\N	\N	\N	\N	\N	\N
370	5	2026-04-28	27.1	\N	\N	\N	\N	\N	23.9	83.6	21.7	\N	\N	24.963	\N	\N	\N	\N	\N	\N	\N	\N
371	5	2026-04-29	27.5	\N	\N	\N	\N	\N	24	81.9	23.2	\N	\N	7.934	\N	\N	\N	\N	\N	\N	\N	\N
372	5	2026-04-30	28	\N	\N	\N	\N	\N	24.3	81.3	19.4	\N	\N	3.445	\N	\N	\N	\N	\N	\N	\N	\N
373	5	2026-05-01	27.8	\N	\N	\N	\N	\N	24.9	84.9	19.4	\N	\N	17.951	\N	\N	\N	\N	\N	\N	\N	\N
374	5	2026-05-02	26.8	\N	\N	\N	\N	\N	24.9	89.6	21.7	\N	\N	31.631	\N	\N	\N	\N	\N	\N	\N	\N
375	5	2026-05-03	27.2	\N	\N	\N	\N	\N	23.9	82.9	24.8	\N	\N	17.956	\N	\N	\N	\N	\N	\N	\N	\N
376	5	2026-05-04	27.2	\N	\N	\N	\N	\N	24.4	84.9	12.4	\N	\N	5.317	\N	\N	\N	\N	\N	\N	\N	\N
377	5	2026-05-05	28.5	\N	\N	\N	\N	\N	23.6	75.9	24.8	\N	\N	1.66	\N	\N	\N	\N	\N	\N	\N	\N
378	5	2026-05-06	29	\N	\N	\N	\N	\N	23.6	73.5	14.9	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
379	5	2026-05-07	29.6	\N	\N	\N	\N	\N	22.6	67.3	21.2	\N	\N	0.004	\N	\N	\N	\N	\N	\N	\N	\N
380	5	2026-05-08	29.1	\N	\N	\N	\N	\N	23.9	74	15.2	\N	\N	0.166	\N	\N	\N	\N	\N	\N	\N	\N
381	5	2026-05-09	28.1	\N	\N	\N	\N	\N	23.2	75.2	29.9	\N	\N	1.244	\N	\N	\N	\N	\N	\N	\N	\N
382	5	2026-05-10	28.2	\N	\N	\N	\N	\N	23.2	75.5	23.4	\N	\N	2.258	\N	\N	\N	\N	\N	\N	\N	\N
383	7	2026-04-11	27.5	\N	\N	\N	\N	\N	23.2	78.3	29	\N	\N	20.69	\N	\N	\N	\N	\N	\N	\N	\N
384	7	2026-04-12	26.9	\N	\N	\N	\N	\N	22.6	77.4	33.3	\N	\N	8.674	\N	\N	\N	\N	\N	\N	\N	\N
385	7	2026-04-13	26	\N	\N	\N	\N	\N	23.4	85.5	22.3	\N	\N	4.972	\N	\N	\N	\N	\N	\N	\N	\N
386	7	2026-04-14	26.9	\N	\N	\N	\N	\N	23.9	83.8	24.1	\N	\N	30.463	\N	\N	\N	\N	\N	\N	\N	\N
387	7	2026-04-15	26.2	\N	\N	\N	\N	\N	24	88	14.2	\N	\N	16.056	\N	\N	\N	\N	\N	\N	\N	\N
388	7	2026-04-16	27.2	\N	\N	\N	\N	\N	24.4	85.6	18.3	\N	\N	17.436	\N	\N	\N	\N	\N	\N	\N	\N
389	7	2026-04-17	28.1	\N	\N	\N	\N	\N	24.7	82.3	22.3	\N	\N	14.944	\N	\N	\N	\N	\N	\N	\N	\N
390	7	2026-04-18	26.3	\N	\N	\N	\N	\N	25	92.9	18.4	\N	\N	24.334	\N	\N	\N	\N	\N	\N	\N	\N
391	7	2026-04-19	27	\N	\N	\N	\N	\N	24.1	84.6	29.4	\N	\N	6.584	\N	\N	\N	\N	\N	\N	\N	\N
392	7	2026-04-20	28.5	\N	\N	\N	\N	\N	23.3	74.6	27.6	\N	\N	0.212	\N	\N	\N	\N	\N	\N	\N	\N
393	7	2026-04-21	28.9	\N	\N	\N	\N	\N	22.4	69.2	25.4	\N	\N	0.961	\N	\N	\N	\N	\N	\N	\N	\N
394	7	2026-04-22	29.2	\N	\N	\N	\N	\N	22.5	68	25.9	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
395	7	2026-04-23	27.5	\N	\N	\N	\N	\N	23.2	77.9	44.8	\N	\N	3.154	\N	\N	\N	\N	\N	\N	\N	\N
396	7	2026-04-24	27	\N	\N	\N	\N	\N	23.1	80.4	27.6	\N	\N	20.942	\N	\N	\N	\N	\N	\N	\N	\N
397	7	2026-04-25	27.2	\N	\N	\N	\N	\N	24	83	24	\N	\N	0.591	\N	\N	\N	\N	\N	\N	\N	\N
398	7	2026-04-26	28.1	\N	\N	\N	\N	\N	23.4	77.1	18.4	\N	\N	7.696	\N	\N	\N	\N	\N	\N	\N	\N
399	7	2026-04-27	27.9	\N	\N	\N	\N	\N	22.6	73.3	33.4	\N	\N	0.791	\N	\N	\N	\N	\N	\N	\N	\N
400	7	2026-04-28	26.9	\N	\N	\N	\N	\N	23.7	83.8	27.2	\N	\N	33.91	\N	\N	\N	\N	\N	\N	\N	\N
401	7	2026-04-29	27.5	\N	\N	\N	\N	\N	23.7	80.4	30.8	\N	\N	12.1	\N	\N	\N	\N	\N	\N	\N	\N
402	7	2026-04-30	28	\N	\N	\N	\N	\N	24	80	18.4	\N	\N	3.087	\N	\N	\N	\N	\N	\N	\N	\N
403	7	2026-05-01	27.7	\N	\N	\N	\N	\N	24.8	84.9	19.4	\N	\N	19.712	\N	\N	\N	\N	\N	\N	\N	\N
404	7	2026-05-02	26.8	\N	\N	\N	\N	\N	24.8	89.4	22.3	\N	\N	33.928	\N	\N	\N	\N	\N	\N	\N	\N
405	7	2026-05-03	27.1	\N	\N	\N	\N	\N	23.7	82.5	27.6	\N	\N	16.73	\N	\N	\N	\N	\N	\N	\N	\N
406	7	2026-05-04	27	\N	\N	\N	\N	\N	24.2	85	14.3	\N	\N	6.004	\N	\N	\N	\N	\N	\N	\N	\N
407	7	2026-05-05	28.5	\N	\N	\N	\N	\N	23.2	74.1	27.6	\N	\N	2.616	\N	\N	\N	\N	\N	\N	\N	\N
408	7	2026-05-06	29.1	\N	\N	\N	\N	\N	23	71.7	18.2	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
409	7	2026-05-07	29.7	\N	\N	\N	\N	\N	21.8	64.5	22.3	\N	\N	0.026	\N	\N	\N	\N	\N	\N	\N	\N
410	7	2026-05-08	29.1	\N	\N	\N	\N	\N	23.4	71.8	14.8	\N	\N	0.076	\N	\N	\N	\N	\N	\N	\N	\N
411	7	2026-05-09	28.1	\N	\N	\N	\N	\N	22.9	74	31.6	\N	\N	2.054	\N	\N	\N	\N	\N	\N	\N	\N
412	7	2026-05-10	28.2	\N	\N	\N	\N	\N	22.9	73.7	22.4	\N	\N	2.97	\N	\N	\N	\N	\N	\N	\N	\N
413	1	2026-04-11	27.7	\N	\N	\N	\N	\N	23.3	77.3	27.5	\N	\N	28.915	\N	\N	\N	\N	\N	\N	\N	\N
414	1	2026-04-12	26.8	\N	\N	\N	\N	\N	23	79.9	28.7	\N	\N	4.051	\N	\N	\N	\N	\N	\N	\N	\N
415	1	2026-04-13	26.1	\N	\N	\N	\N	\N	23.6	86.3	22.2	\N	\N	4.786	\N	\N	\N	\N	\N	\N	\N	\N
416	1	2026-04-14	27.1	\N	\N	\N	\N	\N	24	83.4	23	\N	\N	27.483	\N	\N	\N	\N	\N	\N	\N	\N
417	1	2026-04-15	26.6	\N	\N	\N	\N	\N	24	85.9	18.3	\N	\N	24.309	\N	\N	\N	\N	\N	\N	\N	\N
418	1	2026-04-16	27.3	\N	\N	\N	\N	\N	24.6	85.7	15.5	\N	\N	23.926	\N	\N	\N	\N	\N	\N	\N	\N
419	1	2026-04-17	28.2	\N	\N	\N	\N	\N	24.9	82.8	22.3	\N	\N	6.079	\N	\N	\N	\N	\N	\N	\N	\N
420	1	2026-04-18	26.4	\N	\N	\N	\N	\N	24.8	90.7	18.5	\N	\N	17.068	\N	\N	\N	\N	\N	\N	\N	\N
421	1	2026-04-19	27.2	\N	\N	\N	\N	\N	24.2	83.6	27.1	\N	\N	10.454	\N	\N	\N	\N	\N	\N	\N	\N
422	1	2026-04-20	28.8	\N	\N	\N	\N	\N	23.5	74.1	24.9	\N	\N	0.199	\N	\N	\N	\N	\N	\N	\N	\N
423	1	2026-04-21	29.2	\N	\N	\N	\N	\N	22.7	69.2	22.8	\N	\N	0.997	\N	\N	\N	\N	\N	\N	\N	\N
424	1	2026-04-22	29.5	\N	\N	\N	\N	\N	22.9	68.4	24.8	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
425	1	2026-04-23	28	\N	\N	\N	\N	\N	23.3	75.9	25.9	\N	\N	0.019	\N	\N	\N	\N	\N	\N	\N	\N
426	1	2026-04-24	27.3	\N	\N	\N	\N	\N	23.4	80.1	24.6	\N	\N	20.015	\N	\N	\N	\N	\N	\N	\N	\N
427	1	2026-04-25	27.5	\N	\N	\N	\N	\N	24	81.8	21.9	\N	\N	0.005	\N	\N	\N	\N	\N	\N	\N	\N
428	1	2026-04-26	28.2	\N	\N	\N	\N	\N	23.6	77.1	18.1	\N	\N	6.998	\N	\N	\N	\N	\N	\N	\N	\N
429	1	2026-04-27	28	\N	\N	\N	\N	\N	22.8	74.1	31.1	\N	\N	0.011	\N	\N	\N	\N	\N	\N	\N	\N
430	1	2026-04-28	27.1	\N	\N	\N	\N	\N	23.9	83.4	21.3	\N	\N	46.842	\N	\N	\N	\N	\N	\N	\N	\N
431	1	2026-04-29	27.6	\N	\N	\N	\N	\N	24	81.8	21.8	\N	\N	15.941	\N	\N	\N	\N	\N	\N	\N	\N
432	1	2026-04-30	28	\N	\N	\N	\N	\N	24.3	81.3	22.3	\N	\N	2.804	\N	\N	\N	\N	\N	\N	\N	\N
433	1	2026-05-01	27.8	\N	\N	\N	\N	\N	24.9	84.9	19.3	\N	\N	24.548	\N	\N	\N	\N	\N	\N	\N	\N
434	1	2026-05-02	26.8	\N	\N	\N	\N	\N	25	89.8	21.3	\N	\N	43.307	\N	\N	\N	\N	\N	\N	\N	\N
435	1	2026-05-03	27.3	\N	\N	\N	\N	\N	23.7	81.8	23.3	\N	\N	13.545	\N	\N	\N	\N	\N	\N	\N	\N
436	1	2026-05-04	27.2	\N	\N	\N	\N	\N	24.4	84.8	13	\N	\N	6.989	\N	\N	\N	\N	\N	\N	\N	\N
437	1	2026-05-05	28.5	\N	\N	\N	\N	\N	23.6	75.9	23.3	\N	\N	3.983	\N	\N	\N	\N	\N	\N	\N	\N
438	1	2026-05-06	29	\N	\N	\N	\N	\N	23.6	73.5	18.3	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
439	1	2026-05-07	29.6	\N	\N	\N	\N	\N	22.6	67.5	20.6	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
440	1	2026-05-08	29.1	\N	\N	\N	\N	\N	23.9	73.7	15.5	\N	\N	0.001	\N	\N	\N	\N	\N	\N	\N	\N
441	1	2026-05-09	28.1	\N	\N	\N	\N	\N	23.2	75.3	29	\N	\N	1.007	\N	\N	\N	\N	\N	\N	\N	\N
442	1	2026-05-10	28.1	\N	\N	\N	\N	\N	23.2	75.4	23.9	\N	\N	1.611	\N	\N	\N	\N	\N	\N	\N	\N
443	2	2026-04-11	27.6	\N	\N	\N	\N	\N	23.2	77.6	27.5	\N	\N	23.045	\N	\N	\N	\N	\N	\N	\N	\N
444	2	2026-04-12	26.8	\N	\N	\N	\N	\N	22.9	79.7	28.9	\N	\N	7.443	\N	\N	\N	\N	\N	\N	\N	\N
445	2	2026-04-13	26	\N	\N	\N	\N	\N	23.6	86.4	22.2	\N	\N	4.513	\N	\N	\N	\N	\N	\N	\N	\N
446	2	2026-04-14	27.1	\N	\N	\N	\N	\N	23.9	83.4	23	\N	\N	27.336	\N	\N	\N	\N	\N	\N	\N	\N
447	2	2026-04-15	26.5	\N	\N	\N	\N	\N	23.9	86.3	15.5	\N	\N	19.509	\N	\N	\N	\N	\N	\N	\N	\N
448	2	2026-04-16	27.3	\N	\N	\N	\N	\N	24.6	85.6	15.7	\N	\N	19.868	\N	\N	\N	\N	\N	\N	\N	\N
449	2	2026-04-17	28.2	\N	\N	\N	\N	\N	24.8	82.8	22.3	\N	\N	13.867	\N	\N	\N	\N	\N	\N	\N	\N
450	2	2026-04-18	26.3	\N	\N	\N	\N	\N	24.8	91.5	18.5	\N	\N	21.791	\N	\N	\N	\N	\N	\N	\N	\N
451	2	2026-04-19	27.1	\N	\N	\N	\N	\N	24.1	84	27.3	\N	\N	7.986	\N	\N	\N	\N	\N	\N	\N	\N
452	2	2026-04-20	28.8	\N	\N	\N	\N	\N	23.5	74.5	25	\N	\N	0.167	\N	\N	\N	\N	\N	\N	\N	\N
453	2	2026-04-21	29.1	\N	\N	\N	\N	\N	22.6	69.4	22.7	\N	\N	0.951	\N	\N	\N	\N	\N	\N	\N	\N
454	2	2026-04-22	29.4	\N	\N	\N	\N	\N	22.9	68.5	24.8	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
455	2	2026-04-23	27.8	\N	\N	\N	\N	\N	23.2	76.4	24.8	\N	\N	0.733	\N	\N	\N	\N	\N	\N	\N	\N
456	2	2026-04-24	27.2	\N	\N	\N	\N	\N	23.3	80.2	24.8	\N	\N	21.246	\N	\N	\N	\N	\N	\N	\N	\N
457	2	2026-04-25	27.4	\N	\N	\N	\N	\N	24	82.3	22	\N	\N	0.448	\N	\N	\N	\N	\N	\N	\N	\N
458	2	2026-04-26	28.1	\N	\N	\N	\N	\N	23.5	77.3	18.1	\N	\N	7.975	\N	\N	\N	\N	\N	\N	\N	\N
459	2	2026-04-27	27.9	\N	\N	\N	\N	\N	22.8	74.5	31.3	\N	\N	0.414	\N	\N	\N	\N	\N	\N	\N	\N
460	2	2026-04-28	27	\N	\N	\N	\N	\N	23.8	83.7	21.4	\N	\N	39.376	\N	\N	\N	\N	\N	\N	\N	\N
461	2	2026-04-29	27.5	\N	\N	\N	\N	\N	23.9	81.7	22	\N	\N	13.083	\N	\N	\N	\N	\N	\N	\N	\N
462	2	2026-04-30	27.9	\N	\N	\N	\N	\N	24.3	81.2	20.6	\N	\N	2.873	\N	\N	\N	\N	\N	\N	\N	\N
463	2	2026-05-01	27.7	\N	\N	\N	\N	\N	24.9	84.9	19.3	\N	\N	21.516	\N	\N	\N	\N	\N	\N	\N	\N
464	2	2026-05-02	26.8	\N	\N	\N	\N	\N	24.9	89.7	21.4	\N	\N	38.073	\N	\N	\N	\N	\N	\N	\N	\N
465	2	2026-05-03	27.2	\N	\N	\N	\N	\N	23.8	82.4	23.5	\N	\N	16.514	\N	\N	\N	\N	\N	\N	\N	\N
466	2	2026-05-04	27.1	\N	\N	\N	\N	\N	24.3	84.9	12.9	\N	\N	6.508	\N	\N	\N	\N	\N	\N	\N	\N
467	2	2026-05-05	28.4	\N	\N	\N	\N	\N	23.6	76.3	23.5	\N	\N	3.162	\N	\N	\N	\N	\N	\N	\N	\N
468	2	2026-05-06	28.9	\N	\N	\N	\N	\N	23.5	73.6	17.2	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
469	2	2026-05-07	29.5	\N	\N	\N	\N	\N	22.5	67.4	20.7	\N	\N	0.007	\N	\N	\N	\N	\N	\N	\N	\N
470	2	2026-05-08	29	\N	\N	\N	\N	\N	23.8	73.9	15.4	\N	\N	0.039	\N	\N	\N	\N	\N	\N	\N	\N
471	2	2026-05-09	28	\N	\N	\N	\N	\N	23.2	75.6	29.1	\N	\N	1.915	\N	\N	\N	\N	\N	\N	\N	\N
472	2	2026-05-10	28.1	\N	\N	\N	\N	\N	23.1	75.5	23.8	\N	\N	2.767	\N	\N	\N	\N	\N	\N	\N	\N
473	1	2026-05-11	28.3	\N	\N	\N	\N	\N	23.7	78.2	13.9	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
474	1	2026-05-12	28.3	\N	\N	\N	\N	\N	23.7	78.2	13.9	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
475	1	2026-06-10	28.3	\N	\N	\N	\N	\N	23.7	78.2	13.9	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
476	2	2026-05-11	28.3	\N	\N	\N	\N	\N	23.7	78.2	13.9	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
477	2	2026-05-12	28.3	\N	\N	\N	\N	\N	23.7	78.2	13.9	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
478	2	2026-06-10	28.3	\N	\N	\N	\N	\N	23.7	78.2	13.9	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
479	3	2026-05-11	28.3	\N	\N	\N	\N	\N	23.7	78.2	13.9	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
480	3	2026-05-12	28.3	\N	\N	\N	\N	\N	23.7	78.2	13.9	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
481	3	2026-06-10	28.3	\N	\N	\N	\N	\N	23.7	78.2	13.9	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
482	4	2026-05-11	28.3	\N	\N	\N	\N	\N	23.7	78.2	14	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
483	4	2026-05-12	28.3	\N	\N	\N	\N	\N	23.7	78.2	14	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
484	4	2026-06-10	28.3	\N	\N	\N	\N	\N	23.7	78.2	14	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
485	5	2026-05-11	28.3	\N	\N	\N	\N	\N	23.7	78.3	14.2	\N	\N	0.2	\N	\N	\N	\N	\N	\N	\N	\N
486	5	2026-05-12	28.3	\N	\N	\N	\N	\N	23.7	78.3	14.2	\N	\N	0.2	\N	\N	\N	\N	\N	\N	\N	\N
487	5	2026-06-10	28.3	\N	\N	\N	\N	\N	23.7	78.3	14.2	\N	\N	0.2	\N	\N	\N	\N	\N	\N	\N	\N
488	6	2026-05-11	28.3	\N	\N	\N	\N	\N	23.7	78.3	14.2	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
489	6	2026-05-12	28.3	\N	\N	\N	\N	\N	23.7	78.3	14.2	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
490	6	2026-06-10	28.3	\N	\N	\N	\N	\N	23.7	78.3	14.2	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
491	7	2026-05-11	28.3	\N	\N	\N	\N	\N	23.6	78.5	14.7	\N	\N	0.2	\N	\N	\N	\N	\N	\N	\N	\N
492	7	2026-05-12	28.3	\N	\N	\N	\N	\N	23.6	78.5	14.7	\N	\N	0.2	\N	\N	\N	\N	\N	\N	\N	\N
493	7	2026-06-10	28.3	\N	\N	\N	\N	\N	23.6	78.5	14.7	\N	\N	0.2	\N	\N	\N	\N	\N	\N	\N	\N
494	8	2026-05-11	28.4	\N	\N	\N	\N	\N	23.9	78	12.8	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
495	8	2026-05-12	28.4	\N	\N	\N	\N	\N	23.9	78	12.8	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
496	8	2026-06-10	28.4	\N	\N	\N	\N	\N	23.9	78	12.8	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: weather_pm25actual; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.weather_pm25actual (id, station_id, date, pm25_value) FROM stdin;
1	1	2026-06-10	69
2	2	2026-06-10	57.7
3	3	2026-06-10	65
4	4	2026-06-10	112
5	5	2026-06-10	116
6	6	2026-06-10	77
7	7	2026-06-10	122
8	8	2026-06-10	106
17	4	2026-05-13	33.63157894736842
18	4	2026-05-14	19.214285714285715
19	4	2026-05-15	34.15
20	4	2026-05-22	65.55555555555556
21	4	2026-05-26	37.416666666666664
22	6	2026-05-13	65.26315789473684
23	6	2026-05-14	36.357142857142854
24	6	2026-05-15	36.85
25	6	2026-05-22	82.88888888888889
26	6	2026-05-26	50.666666666666664
27	8	2026-05-13	29.94736842105263
28	8	2026-05-14	20.714285714285715
29	8	2026-05-15	33.3
30	8	2026-05-22	54.22222222222222
31	8	2026-05-26	28.333333333333332
32	5	2026-05-13	38.89473684210526
33	5	2026-05-14	26.928571428571427
34	5	2026-05-15	35.4
35	5	2026-05-22	54.44444444444444
36	5	2026-05-26	38.083333333333336
37	7	2026-05-13	27.57894736842105
38	7	2026-05-14	20.214285714285715
39	7	2026-05-15	20.25
40	7	2026-05-22	29.555555555555557
41	7	2026-05-26	15.5
42	1	2026-05-13	41.7267884065289
43	1	2026-05-14	20.25392416897517
44	1	2026-05-15	41.17394048447169
45	1	2026-05-16	50.51507177736861
46	1	2026-05-17	51.338688332222354
47	1	2026-05-18	46.43179427497893
48	1	2026-05-19	62.58275541586383
49	1	2026-05-20	53.52793332283337
50	1	2026-05-21	56.816269196311914
51	1	2026-05-22	55.36107436628117
52	1	2026-05-23	67.08131869166552
53	1	2026-05-24	62.004489013883905
54	1	2026-05-25	53.755122860330935
55	1	2026-05-26	36.75491822783714
56	2	2026-05-13	19.77693308438089
57	2	2026-05-14	20.969654017438657
58	2	2026-05-15	30.35092280410835
59	2	2026-05-16	34.695295211507705
60	2	2026-05-17	51.60465346187004
61	2	2026-05-18	55.34379285040839
62	2	2026-05-19	57.58536408341855
63	2	2026-05-20	38.936576175902864
64	2	2026-05-21	56.567064321970065
65	2	2026-05-22	54.07193278800469
66	2	2026-05-23	65.19103837882292
67	2	2026-05-24	59.20839327010421
68	2	2026-05-25	55.56845723952468
69	2	2026-05-26	24.084075154742205
70	4	2026-04-11	25.647058823529413
71	4	2026-04-12	17.05
72	4	2026-04-19	31.785714285714285
73	4	2026-04-20	7.611111111111111
74	4	2026-04-21	35.8421052631579
75	4	2026-04-22	41.19047619047619
76	4	2026-04-23	37.73684210526316
77	4	2026-04-24	29.571428571428573
78	4	2026-04-25	31.333333333333332
79	4	2026-04-26	33.1
80	4	2026-04-27	33.63157894736842
81	4	2026-04-28	19.214285714285715
82	4	2026-04-29	34.15
83	4	2026-05-06	65.55555555555556
84	4	2026-05-10	37.416666666666664
85	6	2026-04-11	51.05882352941177
86	6	2026-04-12	32.25
87	6	2026-04-19	53.42857142857143
88	6	2026-04-20	10.944444444444445
89	6	2026-04-21	40.31578947368421
90	6	2026-04-22	47.57142857142857
91	6	2026-04-23	44.63157894736842
92	6	2026-04-24	37.42857142857143
93	6	2026-04-25	48.05555555555556
94	6	2026-04-26	39.45
95	6	2026-04-27	65.26315789473684
96	6	2026-04-28	36.357142857142854
97	6	2026-04-29	36.85
98	6	2026-05-06	82.88888888888889
99	6	2026-05-10	50.666666666666664
100	8	2026-04-11	21.823529411764707
101	8	2026-04-12	20.95
102	8	2026-04-19	41.857142857142854
103	8	2026-04-20	17.22222222222222
104	8	2026-04-21	28.63157894736842
105	8	2026-04-22	34.04761904761905
106	8	2026-04-23	31.05263157894737
107	8	2026-04-24	33.714285714285715
108	8	2026-04-25	34.5
109	8	2026-04-26	37.4
110	8	2026-04-27	29.94736842105263
111	8	2026-04-28	20.714285714285715
112	8	2026-04-29	33.3
113	8	2026-05-06	54.22222222222222
114	8	2026-05-10	28.333333333333332
115	5	2026-04-11	30
116	5	2026-04-12	23.1
117	5	2026-04-19	40.57142857142857
118	5	2026-04-20	13.444444444444445
119	5	2026-04-21	38.89473684210526
120	5	2026-04-22	47.666666666666664
121	5	2026-04-23	51.63157894736842
122	5	2026-04-24	34.76190476190476
123	5	2026-04-25	33.44444444444444
124	5	2026-04-26	39.65
125	5	2026-04-27	38.89473684210526
126	5	2026-04-28	26.928571428571427
127	5	2026-04-29	35.4
128	5	2026-05-06	54.44444444444444
129	5	2026-05-10	38.083333333333336
130	7	2026-04-11	18.41176470588235
131	7	2026-04-12	14.6
132	7	2026-04-19	26.857142857142858
133	7	2026-04-20	7.888888888888889
134	7	2026-04-21	20.210526315789473
135	7	2026-04-22	19.52380952380953
136	7	2026-04-23	20.157894736842103
137	7	2026-04-24	19.095238095238095
138	7	2026-04-25	18.333333333333332
139	7	2026-04-26	16.1
140	7	2026-04-27	27.57894736842105
141	7	2026-04-28	20.214285714285715
142	7	2026-04-29	20.25
143	7	2026-05-06	29.555555555555557
144	7	2026-05-10	15.5
145	1	2026-04-11	29.12695922022424
146	1	2026-04-12	19.28480478939688
147	1	2026-04-13	24.269766781204407
148	1	2026-04-14	26.71264052131873
149	1	2026-04-15	41.33638887363726
150	1	2026-04-16	70.69837491897955
151	1	2026-04-17	77.62320736869196
152	1	2026-04-18	56.82887903896114
153	1	2026-04-19	55.89876975053051
154	1	2026-04-20	28.9056944985455
155	1	2026-04-21	42.188574611061185
156	1	2026-04-22	39.942707193809746
157	1	2026-04-23	47.731386694258674
158	1	2026-04-24	34.29265896402561
159	1	2026-04-26	38.65365747148201
160	1	2026-04-27	41.7267884065289
161	1	2026-04-28	20.25392416897517
162	1	2026-04-29	41.17394048447169
163	1	2026-04-30	50.51507177736861
164	1	2026-05-01	51.338688332222354
165	1	2026-05-02	46.43179427497893
166	1	2026-05-03	62.58275541586383
167	1	2026-05-04	53.52793332283337
168	1	2026-05-05	56.816269196311914
169	1	2026-05-06	55.36107436628117
170	1	2026-05-07	67.08131869166552
171	1	2026-05-08	62.004489013883905
172	1	2026-05-09	53.755122860330935
173	1	2026-05-10	36.75491822783714
174	2	2026-04-11	31.8612852617954
175	2	2026-04-12	26.315913000566496
176	2	2026-04-13	28.001637755280218
177	2	2026-04-14	28.86768664895438
178	2	2026-04-15	40.764172914376424
179	2	2026-04-16	75.60095866714967
180	2	2026-04-17	78.79175308420555
181	2	2026-04-18	59.98046922809894
182	2	2026-04-19	59.78057407584788
183	2	2026-04-20	30.82767849719534
184	2	2026-04-21	46.30486430186491
185	2	2026-04-22	29.32257867110939
186	2	2026-04-23	30.32395833870849
187	2	2026-04-24	20.521195905253816
188	2	2026-04-25	29.320103314247504
189	2	2026-04-26	26.980395422066948
190	2	2026-04-27	19.77693308438089
191	2	2026-04-28	20.969654017438657
192	2	2026-04-29	30.35092280410835
193	2	2026-04-30	34.695295211507705
194	2	2026-05-01	51.60465346187004
195	2	2026-05-02	55.34379285040839
196	2	2026-05-03	57.58536408341855
197	2	2026-05-04	38.936576175902864
198	2	2026-05-05	56.567064321970065
199	2	2026-05-06	54.07193278800469
200	2	2026-05-07	65.19103837882292
201	2	2026-05-08	59.20839327010421
202	2	2026-05-09	55.56845723952468
203	2	2026-05-10	24.084075154742205
204	1	2026-05-11	51.2216059026369
205	1	2026-05-12	51.2216059026369
206	1	2026-05-27	51.2216059026369
207	1	2026-05-28	51.2216059026369
208	1	2026-05-29	51.2216059026369
209	1	2026-05-30	51.2216059026369
210	1	2026-05-31	51.2216059026369
211	1	2026-06-01	51.2216059026369
212	1	2026-06-02	51.2216059026369
213	1	2026-06-03	51.2216059026369
214	1	2026-06-04	51.2216059026369
215	1	2026-06-05	51.2216059026369
216	1	2026-06-06	51.2216059026369
217	1	2026-06-07	51.2216059026369
218	1	2026-06-08	51.2216059026369
219	1	2026-06-09	51.2216059026369
220	2	2026-05-11	45.44361018948029
221	2	2026-05-12	45.44361018948029
222	2	2026-05-27	45.44361018948029
223	2	2026-05-28	45.44361018948029
224	2	2026-05-29	45.44361018948029
225	2	2026-05-30	45.44361018948029
226	2	2026-05-31	45.44361018948029
227	2	2026-06-01	45.44361018948029
228	2	2026-06-02	45.44361018948029
229	2	2026-06-03	45.44361018948029
230	2	2026-06-04	45.44361018948029
231	2	2026-06-05	45.44361018948029
232	2	2026-06-06	45.44361018948029
233	2	2026-06-07	45.44361018948029
234	2	2026-06-08	45.44361018948029
235	2	2026-06-09	45.44361018948029
236	3	2026-05-11	65
237	3	2026-05-12	65
238	3	2026-05-13	65
239	3	2026-05-14	65
240	3	2026-05-15	65
241	3	2026-05-16	65
242	3	2026-05-17	65
243	3	2026-05-18	65
244	3	2026-05-19	65
245	3	2026-05-20	65
246	3	2026-05-21	65
247	3	2026-05-22	65
248	3	2026-05-23	65
249	3	2026-05-24	65
250	3	2026-05-25	65
251	3	2026-05-26	65
252	3	2026-05-27	65
253	3	2026-05-28	65
254	3	2026-05-29	65
255	3	2026-05-30	65
256	3	2026-05-31	65
257	3	2026-06-01	65
258	3	2026-06-02	65
259	3	2026-06-03	65
260	3	2026-06-04	65
261	3	2026-06-05	65
262	3	2026-06-06	65
263	3	2026-06-07	65
264	3	2026-06-08	65
265	3	2026-06-09	65
266	4	2026-05-11	50.32801448064606
267	4	2026-05-12	50.32801448064606
268	4	2026-05-16	50.32801448064606
269	4	2026-05-17	50.32801448064606
270	4	2026-05-18	50.32801448064606
271	4	2026-05-19	50.32801448064606
272	4	2026-05-20	50.32801448064606
273	4	2026-05-21	50.32801448064606
274	4	2026-05-23	50.32801448064606
275	4	2026-05-24	50.32801448064606
276	4	2026-05-25	50.32801448064606
277	4	2026-05-27	50.32801448064606
278	4	2026-05-28	50.32801448064606
279	4	2026-05-29	50.32801448064606
280	4	2026-05-30	50.32801448064606
281	4	2026-05-31	50.32801448064606
282	4	2026-06-01	50.32801448064606
283	4	2026-06-02	50.32801448064606
284	4	2026-06-03	50.32801448064606
285	4	2026-06-04	50.32801448064606
286	4	2026-06-05	50.32801448064606
287	4	2026-06-06	50.32801448064606
288	4	2026-06-07	50.32801448064606
289	4	2026-06-08	50.32801448064606
290	4	2026-06-09	50.32801448064606
291	5	2026-05-11	51.62518100807574
292	5	2026-05-12	51.62518100807574
293	5	2026-05-16	51.62518100807574
294	5	2026-05-17	51.62518100807574
295	5	2026-05-18	51.62518100807574
296	5	2026-05-19	51.62518100807574
297	5	2026-05-20	51.62518100807574
298	5	2026-05-21	51.62518100807574
299	5	2026-05-23	51.62518100807574
300	5	2026-05-24	51.62518100807574
301	5	2026-05-25	51.62518100807574
302	5	2026-05-27	51.62518100807574
303	5	2026-05-28	51.62518100807574
304	5	2026-05-29	51.62518100807574
305	5	2026-05-30	51.62518100807574
306	5	2026-05-31	51.62518100807574
307	5	2026-06-01	51.62518100807574
308	5	2026-06-02	51.62518100807574
309	5	2026-06-03	51.62518100807574
310	5	2026-06-04	51.62518100807574
311	5	2026-06-05	51.62518100807574
312	5	2026-06-06	51.62518100807574
313	5	2026-06-07	51.62518100807574
314	5	2026-06-08	51.62518100807574
315	5	2026-06-09	51.62518100807574
316	6	2026-05-11	58.1709760512392
317	6	2026-05-12	58.1709760512392
318	6	2026-05-16	58.1709760512392
319	6	2026-05-17	58.1709760512392
320	6	2026-05-18	58.1709760512392
321	6	2026-05-19	58.1709760512392
322	6	2026-05-20	58.1709760512392
323	6	2026-05-21	58.1709760512392
324	6	2026-05-23	58.1709760512392
325	6	2026-05-24	58.1709760512392
326	6	2026-05-25	58.1709760512392
327	6	2026-05-27	58.1709760512392
328	6	2026-05-28	58.1709760512392
329	6	2026-05-29	58.1709760512392
330	6	2026-05-30	58.1709760512392
331	6	2026-05-31	58.1709760512392
332	6	2026-06-01	58.1709760512392
333	6	2026-06-02	58.1709760512392
334	6	2026-06-03	58.1709760512392
335	6	2026-06-04	58.1709760512392
336	6	2026-06-05	58.1709760512392
337	6	2026-06-06	58.1709760512392
338	6	2026-06-07	58.1709760512392
339	6	2026-06-08	58.1709760512392
340	6	2026-06-09	58.1709760512392
341	7	2026-05-11	39.18313143971039
342	7	2026-05-12	39.18313143971039
343	7	2026-05-16	39.18313143971039
344	7	2026-05-17	39.18313143971039
345	7	2026-05-18	39.18313143971039
346	7	2026-05-19	39.18313143971039
347	7	2026-05-20	39.18313143971039
348	7	2026-05-21	39.18313143971039
349	7	2026-05-23	39.18313143971039
350	7	2026-05-24	39.18313143971039
351	7	2026-05-25	39.18313143971039
352	7	2026-05-27	39.18313143971039
353	7	2026-05-28	39.18313143971039
354	7	2026-05-29	39.18313143971039
355	7	2026-05-30	39.18313143971039
356	7	2026-05-31	39.18313143971039
357	7	2026-06-01	39.18313143971039
358	7	2026-06-02	39.18313143971039
359	7	2026-06-03	39.18313143971039
360	7	2026-06-04	39.18313143971039
361	7	2026-06-05	39.18313143971039
362	7	2026-06-06	39.18313143971039
363	7	2026-06-07	39.18313143971039
364	7	2026-06-08	39.18313143971039
365	7	2026-06-09	39.18313143971039
366	8	2026-05-11	45.419534948482315
367	8	2026-05-12	45.419534948482315
368	8	2026-05-16	45.419534948482315
369	8	2026-05-17	45.419534948482315
370	8	2026-05-18	45.419534948482315
371	8	2026-05-19	45.419534948482315
372	8	2026-05-20	45.419534948482315
373	8	2026-05-21	45.419534948482315
374	8	2026-05-23	45.419534948482315
375	8	2026-05-24	45.419534948482315
376	8	2026-05-25	45.419534948482315
377	8	2026-05-27	45.419534948482315
378	8	2026-05-28	45.419534948482315
379	8	2026-05-29	45.419534948482315
380	8	2026-05-30	45.419534948482315
381	8	2026-05-31	45.419534948482315
382	8	2026-06-01	45.419534948482315
383	8	2026-06-02	45.419534948482315
384	8	2026-06-03	45.419534948482315
385	8	2026-06-04	45.419534948482315
386	8	2026-06-05	45.419534948482315
387	8	2026-06-06	45.419534948482315
388	8	2026-06-07	45.419534948482315
389	8	2026-06-08	45.419534948482315
390	8	2026-06-09	45.419534948482315
9	1	2026-06-11	93.8
10	2	2026-06-11	133.2
11	3	2026-06-11	133.2
12	4	2026-06-11	93.8
13	5	2026-06-11	93.8
14	6	2026-06-11	133.2
15	7	2026-06-11	133.2
16	8	2026-06-11	133.2
\.


--
-- Data for Name: weather_pm25prediction; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.weather_pm25prediction (id, station_id, date, pm25_value) FROM stdin;
1	1	2026-06-10	52.792978844125614
2	2	2026-06-10	42.972701478027595
3	3	2026-06-10	65.40700861811638
4	4	2026-06-10	52.20896934091099
5	5	2026-06-10	45.405029886298706
6	6	2026-06-10	62.585283486616035
7	7	2026-06-10	31.40978604840206
8	8	2026-06-10	39.26203092980006
\.


--
-- Data for Name: weather_station; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.weather_station (id, name, location) FROM stdin;
1	us_embassy_1	0101000020E6100000603F1FC0FDB45A40667D14BF73B918C0
2	us_embassy_2	0101000020E6100000E1E782BFC3B25A40FFD167AA56F218C0
3	jakarta_gbk	0101000020E610000008AC1C5A64B35A40E9263108ACDC18C0
4	bundaran_hi	0101000020E610000062105839B4B45A40815B77F354C718C0
5	kelapa_gading	0101000020E610000080D6FCF84BBA5A406094FB78439D18C0
6	jagakarsa	0101000020E6100000AFB14B546FB35A405AD8D30E7F6D19C0
7	lubang_buaya	0101000020E61000006AF6402B30BA5A40D690B8C7D22719C0
8	kebun_jeruk	0101000020E61000005C8FC2F528B05A40A3AF20CD58D418C0
\.


--
-- Data for Name: topology; Type: TABLE DATA; Schema: topology; Owner: -
--

COPY topology.topology (id, name, srid, "precision", hasz) FROM stdin;
\.


--
-- Data for Name: layer; Type: TABLE DATA; Schema: topology; Owner: -
--

COPY topology.layer (topology_id, layer_id, schema_name, table_name, feature_column, feature_type, level, child_id) FROM stdin;
\.


--
-- Name: jobid_seq; Type: SEQUENCE SET; Schema: cron; Owner: -
--

SELECT pg_catalog.setval('cron.jobid_seq', 1, false);


--
-- Name: runid_seq; Type: SEQUENCE SET; Schema: cron; Owner: -
--

SELECT pg_catalog.setval('cron.runid_seq', 1, false);


--
-- Name: aod_aerosolopticaldepth_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.aod_aerosolopticaldepth_id_seq', 89, true);


--
-- Name: aod_pm25estimate_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.aod_pm25estimate_id_seq', 1, false);


--
-- Name: aod_pm25polygon_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.aod_pm25polygon_id_seq', 1, false);


--
-- Name: aod_polygon_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.aod_polygon_id_seq', 488, true);


--
-- Name: aod_satellite_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.aod_satellite_id_seq', 1, true);


--
-- Name: weather_data_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.weather_data_id_seq', 496, true);


--
-- Name: weather_pm25actual_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.weather_pm25actual_id_seq', 390, true);


--
-- Name: weather_pm25prediction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.weather_pm25prediction_id_seq', 8, true);


--
-- Name: weather_station_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.weather_station_id_seq', 8, true);


--
-- Name: topology_id_seq; Type: SEQUENCE SET; Schema: topology; Owner: -
--

SELECT pg_catalog.setval('topology.topology_id_seq', 1, false);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: aod_aerosolopticaldepth aod_aerosolopticaldepth_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aod_aerosolopticaldepth
    ADD CONSTRAINT aod_aerosolopticaldepth_pkey PRIMARY KEY (id);


--
-- Name: aod_pm25estimate aod_pm25estimate_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aod_pm25estimate
    ADD CONSTRAINT aod_pm25estimate_pkey PRIMARY KEY (id);


--
-- Name: aod_pm25polygon aod_pm25polygon_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aod_pm25polygon
    ADD CONSTRAINT aod_pm25polygon_pkey PRIMARY KEY (id);


--
-- Name: aod_polygon aod_polygon_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aod_polygon
    ADD CONSTRAINT aod_polygon_pkey PRIMARY KEY (id);


--
-- Name: aod_satellite aod_satellite_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aod_satellite
    ADD CONSTRAINT aod_satellite_pkey PRIMARY KEY (id);


--
-- Name: weather_data weather_data_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.weather_data
    ADD CONSTRAINT weather_data_pkey PRIMARY KEY (id);


--
-- Name: weather_pm25actual weather_pm25actual_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.weather_pm25actual
    ADD CONSTRAINT weather_pm25actual_pkey PRIMARY KEY (id);


--
-- Name: weather_pm25prediction weather_pm25prediction_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.weather_pm25prediction
    ADD CONSTRAINT weather_pm25prediction_pkey PRIMARY KEY (id);


--
-- Name: weather_station weather_station_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.weather_station
    ADD CONSTRAINT weather_station_pkey PRIMARY KEY (id);


--
-- Name: idx_aod_pm25polygon_geom; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_aod_pm25polygon_geom ON public.aod_pm25polygon USING gist (geom);


--
-- Name: idx_aod_polygon_geom; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_aod_polygon_geom ON public.aod_polygon USING gist (geom);


--
-- Name: idx_weather_station_location; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_weather_station_location ON public.weather_station USING gist (location);


--
-- Name: aod_aerosolopticaldepth aod_aerosolopticaldepth_satellite_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aod_aerosolopticaldepth
    ADD CONSTRAINT aod_aerosolopticaldepth_satellite_id_fkey FOREIGN KEY (satellite_id) REFERENCES public.aod_satellite(id);


--
-- Name: aod_pm25estimate aod_pm25estimate_aod_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aod_pm25estimate
    ADD CONSTRAINT aod_pm25estimate_aod_id_fkey FOREIGN KEY (aod_id) REFERENCES public.aod_aerosolopticaldepth(id);


--
-- Name: aod_pm25polygon aod_pm25polygon_pm25_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aod_pm25polygon
    ADD CONSTRAINT aod_pm25polygon_pm25_id_fkey FOREIGN KEY (pm25_id) REFERENCES public.aod_pm25estimate(id);


--
-- Name: aod_polygon aod_polygon_aod_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aod_polygon
    ADD CONSTRAINT aod_polygon_aod_id_fkey FOREIGN KEY (aod_id) REFERENCES public.aod_aerosolopticaldepth(id);


--
-- Name: weather_data weather_data_station_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.weather_data
    ADD CONSTRAINT weather_data_station_id_fkey FOREIGN KEY (station_id) REFERENCES public.weather_station(id);


--
-- Name: weather_pm25actual weather_pm25actual_station_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.weather_pm25actual
    ADD CONSTRAINT weather_pm25actual_station_id_fkey FOREIGN KEY (station_id) REFERENCES public.weather_station(id);


--
-- Name: weather_pm25prediction weather_pm25prediction_station_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.weather_pm25prediction
    ADD CONSTRAINT weather_pm25prediction_station_id_fkey FOREIGN KEY (station_id) REFERENCES public.weather_station(id);


--
-- PostgreSQL database dump complete
--

